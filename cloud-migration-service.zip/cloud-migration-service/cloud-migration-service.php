<?php
/**
 * Plugin Name: Cloud Migration Service
 * Description: Cloud Migrator for FlyingHost.
 * Version: 0.2.0
 * Author: Rajin Sharwar
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/includes/class-cmsvc-transfer.php';
require_once __DIR__ . '/includes/class-cmsvc-queue.php';

define( 'CMSVC_VERSION', '0.2.0' );
define( 'CMSVC_OPTION_SETTINGS', 'cmsvc_settings' );
define( 'CMSVC_OPTION_JOBS', 'cmsvc_jobs' );
define( 'CMSVC_CRON_HOOK', 'cmsvc_process_jobs' );
define( 'CMSVC_KICK_HOOK', 'cmsvc_kick_jobs' );
define( 'CMSVC_EXPORT_QUEUE_GROUP', 'cmsvc_migration' );
define( 'CMSVC_EXPORT_QUEUE_ACTION', 'cmsvc_process_export_task' );
define( 'CMSVC_USER_AGENT', 'CloudMigrationService/0.2.0 (+https://cloud-migration-service.local)' );
define( 'CMSVC_WORKER_LOCK_TTL', defined( 'HOUR_IN_SECONDS' ) ? 12 * HOUR_IN_SECONDS : 43200 );
define( 'CMSVC_EXPORT_STALE_TTL', defined( 'DAY_IN_SECONDS' ) ? DAY_IN_SECONDS : 86400 );
define( 'CMSVC_EXPORT_TASK_MAX_RETRIES', 2147483647 );
define( 'CMSVC_EXPORT_TASK_CHUNK_BYTES', 33554432 );
define( 'CMSVC_EXPORT_TASK_WINDOW_SECONDS', 15 );
define( 'CMSVC_R2_MULTIPART_PART_BYTES', 67108864 );
define( 'CMSVC_R2_DOWNLOAD_CHUNK_BYTES', 67108864 );
define( 'CMSVC_IMPORT_EXTRACT_CHUNK_BYTES', 16777216 );
define( 'CMSVC_IMPORT_SQL_CHUNK_BYTES', 4194304 );
define( 'CMSVC_IMPORT_SQL_CLI_BATCH_BYTES', 134217728 );
define( 'CMSVC_IMPORT_ATTACHMENT_REGEN_BATCH_SIZE', 25 );
define( 'CMSVC_CLI_RETRY_LIMIT', 5 );
define( 'CMSVC_CLI_RETRY_DELAY_SECONDS', 5 );
define( 'CMSVC_GZIP_STREAM_CHUNK_BYTES', 1048576 );

class CMSVC_Cancelled_Exception extends Exception {}

final class CMSVC_Plugin {
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		CMSVC_Queue::init();

		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_post_cmsvc_save_settings', array( $this, 'save_settings' ) );
		add_action( 'admin_post_cmsvc_cancel_job', array( $this, 'cancel_job' ) );
		add_action( 'wp_ajax_cmsvc_tick', array( $this, 'ajax_tick' ) );
		add_action( CMSVC_CRON_HOOK, array( $this, 'process_jobs' ) );
		add_action( CMSVC_KICK_HOOK, array( $this, 'process_jobs' ) );
		add_action( CMSVC_EXPORT_QUEUE_ACTION, array( $this, 'process_export_queue_task' ) );
		add_action( 'rest_api_init', array( $this, 'rest_routes' ) );
	}

	public static function activate() {
		$settings = get_option( CMSVC_OPTION_SETTINGS );
		if ( ! is_array( $settings ) ) {
			update_option( CMSVC_OPTION_SETTINGS, self::default_settings(), false );
		}

		if ( ! wp_next_scheduled( CMSVC_CRON_HOOK ) ) {
			wp_schedule_event( time() + 30, 'minute', CMSVC_CRON_HOOK );
		}

		CMSVC_Queue::maybe_create_table();
		CMSVC_Queue::setup_watchdog();
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( CMSVC_CRON_HOOK );
		wp_clear_scheduled_hook( CMSVC_KICK_HOOK );
		CMSVC_Queue::clear_watchdog();
	}

	private static function default_settings() {
		return array(
			'site_key'           => wp_generate_password( 32, false, false ),
			'exclude_paths'      => "wp-content/cache\nwp-content/ai1wm-backups\nwp-content/updraft\nwp-content/uploads/cmsvc\nwp-content/uploads/backup*\nwp-content/object-cache.php\nnode_modules\ncpmove-*",
			'exclude_file_types' => 'log,tmp,zip,gz,bak,tar,wpress',
		);
	}

	public function admin_menu() {
		add_management_page(
			'Cloud Migration',
			'Cloud Migration',
			'manage_options',
			'cmsvc',
			array( $this, 'admin_page' )
		);
	}

	public function admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings       = $this->settings();
		$jobs           = $this->jobs();
		$has_active_job = false;

		foreach ( $jobs as $job ) {
			if ( in_array( $job['status'], array( 'queued', 'running' ), true ) ) {
				$has_active_job = true;
				break;
			}
		}
		?>
		<div class="wrap">
			<h1>Cloud Migration Service</h1>
			<?php settings_errors( 'cmsvc' ); ?>

			<style>
				.cmsvc-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(320px,420px);gap:20px;max-width:1180px}
				.cmsvc-card{background:#fff;border:1px solid #dcdcde;border-radius:4px;padding:18px}
				.cmsvc-card h2{margin-top:0}
				.cmsvc-card input[type=text],.cmsvc-card textarea{width:100%}
				.cmsvc-job{border-top:1px solid #dcdcde;padding:12px 0}
				.cmsvc-muted{color:#646970}
				.cmsvc-code{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:13px;word-break:break-all}
				@media(max-width:900px){.cmsvc-grid{grid-template-columns:1fr}}
			</style>

			<div class="cmsvc-grid">
				<div class="cmsvc-card">
					<h2>Worker Settings</h2>
					<p>This plugin is now a helper for the Node SSH worker. It exposes a source export API and WP-CLI import commands for the destination server.</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="cmsvc_save_settings">
						<?php wp_nonce_field( 'cmsvc_save_settings' ); ?>
						<table class="form-table" role="presentation">
							<tr>
								<th scope="row">This site's worker key</th>
								<td>
									<input type="text" readonly value="<?php echo esc_attr( $settings['site_key'] ); ?>">
									<p class="description">Use this as the source key in the Node worker.</p>
								</td>
							</tr>
							<tr>
								<th scope="row">Excluded paths</th>
								<td>
									<textarea name="exclude_paths" rows="8"><?php echo esc_textarea( $settings['exclude_paths'] ); ?></textarea>
									<p class="description">One path or glob per line, relative to the WordPress root when possible.</p>
								</td>
							</tr>
							<tr>
								<th scope="row">Excluded file extensions</th>
								<td>
									<input name="exclude_file_types" type="text" value="<?php echo esc_attr( $settings['exclude_file_types'] ); ?>">
									<p class="description">Comma-separated. Example: <span class="cmsvc-code">log,tmp,zip,gz,bak</span></p>
								</td>
							</tr>
						</table>
						<?php submit_button( 'Save Settings' ); ?>
					</form>
				</div>

				<div class="cmsvc-card">
					<h2>Jobs</h2>
					<?php if ( empty( $jobs ) ) : ?>
						<p>No jobs yet.</p>
					<?php else : ?>
						<?php foreach ( array_reverse( $jobs ) as $job ) : ?>
							<div class="cmsvc-job">
								<strong><?php echo esc_html( $job['id'] ); ?></strong>
								<div>Status: <?php echo esc_html( $job['status'] ); ?> / <?php echo esc_html( $job['stage'] ); ?></div>
								<div><?php echo esc_html( $job['message'] ); ?></div>
								<div class="cmsvc-muted">Updated: <?php echo esc_html( date_i18n( 'Y-m-d H:i:s', (int) $job['updated_at'] ) ); ?></div>
							</div>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php if ( $has_active_job ) : ?>
			<script>
				(function () {
					var nonce = <?php echo wp_json_encode( wp_create_nonce( 'cmsvc_tick' ) ); ?>;
					var busy = false;
					function escapeHtml(value) {
						return String(value).replace(/[&<>"']/g, function (char) {
							return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
						});
					}
					function formatDate(timestamp) {
						var date = new Date(Number(timestamp || 0) * 1000);
						if (Number.isNaN(date.getTime())) {
							return '';
						}
						return date.toLocaleString();
					}
					function renderJobs(jobs) {
						var list = document.querySelector('.cmsvc-card:last-of-type');
						if (!list) {
							return;
						}
						var items = Object.keys(jobs || {}).map(function (id) {
							return jobs[id];
						}).sort(function (a, b) {
							return Number(b.updated_at || 0) - Number(a.updated_at || 0);
						});
						var html = '<h2>Jobs</h2>';
						if (!items.length) {
							html += '<p>No jobs yet.</p>';
						} else {
							html += items.map(function (job) {
								return '<div class="cmsvc-job">'
									+ '<strong>' + escapeHtml(job.id || '') + '</strong>'
									+ '<div>Status: ' + escapeHtml(job.status || '') + ' / ' + escapeHtml(job.stage || '') + '</div>'
									+ '<div>' + escapeHtml(job.message || '') + '</div>'
									+ '<div class="cmsvc-muted">Updated: ' + escapeHtml(formatDate(job.updated_at)) + '</div>'
									+ '</div>';
							}).join('');
						}
						list.innerHTML = html;
					}
					function tick() {
						if (busy) {
							return;
						}
						busy = true;
						var data = new window.FormData();
						data.append('action', 'cmsvc_tick');
						data.append('_ajax_nonce', nonce);
						window.fetch(window.ajaxurl, {
							method: 'POST',
							credentials: 'same-origin',
							body: data
						}).then(function (response) {
							return response.json();
						}).then(function (response) {
							if (response && response.success && response.data && response.data.jobs) {
								renderJobs(response.data.jobs);
							}
						}).catch(function () {
						}).finally(function () {
							busy = false;
							window.setTimeout(tick, 5000);
						});
					}
					window.setTimeout(tick, 5000);
				}());
			</script>
		<?php endif; ?>
		<?php
	}

	public function save_settings() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'cmsvc_save_settings' ) ) {
			wp_die( 'Not allowed.' );
		}

		$current                       = $this->settings();
		$current['exclude_paths']      = isset( $_POST['exclude_paths'] ) ? trim( (string) wp_unslash( $_POST['exclude_paths'] ) ) : '';
		$current['exclude_file_types'] = isset( $_POST['exclude_file_types'] ) ? sanitize_text_field( wp_unslash( $_POST['exclude_file_types'] ) ) : '';

		update_option( CMSVC_OPTION_SETTINGS, $current, false );
		add_settings_error( 'cmsvc', 'saved', 'Settings saved.', 'updated' );
		set_transient( 'settings_errors', get_settings_errors(), 30 );
		wp_safe_redirect( admin_url( 'tools.php?page=cmsvc' ) );
		exit;
	}

	public function cancel_job() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'cmsvc_cancel_job' ) ) {
			wp_die( 'Not allowed.' );
		}

		$job_id = isset( $_POST['job_id'] ) ? sanitize_text_field( wp_unslash( $_POST['job_id'] ) ) : '';
		$this->cancel_job_by_id( $job_id, 'Cancelled by an administrator.' );

		wp_safe_redirect( admin_url( 'tools.php?page=cmsvc' ) );
		exit;
	}

	public function ajax_tick() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'cmsvc_tick', false, false ) ) {
			wp_send_json_error( array( 'message' => 'Not allowed.' ), 403 );
		}

		$this->process_jobs();
		wp_send_json_success( array( 'jobs' => $this->public_jobs() ) );
	}

	public function rest_routes() {
		register_rest_route(
			'cmsvc/v1',
			'/agent/export',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'rest_agent_export' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'cmsvc/v1',
			'/agent/import',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'rest_agent_import' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'cmsvc/v1',
			'/agent/job/(?P<id>[a-zA-Z0-9_\-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'rest_agent_job' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'cmsvc/v1',
			'/agent/cleanup/(?P<id>[a-zA-Z0-9_\-]+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'rest_agent_cleanup' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'cmsvc/v1',
			'/agent/cancel/(?P<id>[a-zA-Z0-9_\-]+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'rest_agent_cancel' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	public function rest_agent_export( WP_REST_Request $request ) {
		$auth = $this->rest_agent_authorize( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$params = $request->get_json_params();
		$job_id = isset( $params['job_id'] ) ? sanitize_text_field( $params['job_id'] ) : '';
		if ( '' === $job_id ) {
			$job_id = 'agent_' . gmdate( 'Ymd_His' ) . '_' . wp_generate_password( 8, false, false );
		}

		$jobs = $this->jobs();
		foreach ( $jobs as $existing_id => $existing_job ) {
			if ( $existing_id !== $job_id && in_array( $existing_job['status'] ?? '', array( 'queued', 'running' ), true ) ) {
				return new WP_Error( 'cmsvc_export_running', 'A source export is already running. Cancel it before starting another migration.', array( 'status' => 409 ) );
			}
		}

		$r2_key = sanitize_text_field( $params['r2_key'] ?? '' );
		if ( '' === $r2_key ) {
			return new WP_Error( 'cmsvc_bad_request', 'Missing R2 key.', array( 'status' => 400 ) );
		}

		$r2 = array(
			'account_id' => sanitize_text_field( $params['r2']['account_id'] ?? '' ),
			'access_key' => sanitize_text_field( $params['r2']['access_key'] ?? '' ),
			'secret_key' => sanitize_text_field( $params['r2']['secret_key'] ?? '' ),
			'bucket'     => sanitize_text_field( $params['r2']['bucket'] ?? '' ),
		);

		foreach ( array( 'account_id', 'access_key', 'secret_key', 'bucket' ) as $required ) {
			if ( '' === $r2[ $required ] ) {
				return new WP_Error( 'cmsvc_missing_r2', 'Missing R2 handoff value: ' . $required, array( 'status' => 400 ) );
			}
		}

		$job               = $this->new_job( $job_id, 'agent_export' );
		$job['source_url'] = home_url();
		$job['r2_key']     = $r2_key;
		$job['r2']         = $r2;
		$job['message']    = 'Queued export and direct R2 upload.';

		$jobs[ $job_id ] = $job;
		$this->save_jobs( $jobs );
		$this->enqueue_export_job( $job_id, true );

		return rest_ensure_response(
			array(
				'ok'     => true,
				'job_id' => $job_id,
			)
		);
	}

	public function rest_agent_import( WP_REST_Request $request ) {
		$auth = $this->rest_agent_authorize( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$params = $request->get_json_params();
		$job_id = isset( $params['job_id'] ) ? sanitize_text_field( $params['job_id'] ) : '';
		if ( '' === $job_id ) {
			$job_id = 'agent_import_' . gmdate( 'Ymd_His' ) . '_' . wp_generate_password( 8, false, false );
		}

		$jobs = $this->jobs();
		foreach ( $jobs as $existing_id => $existing_job ) {
			if ( $existing_id !== $job_id && in_array( $existing_job['status'] ?? '', array( 'queued', 'running' ), true ) ) {
				return new WP_Error( 'cmsvc_import_running', 'A destination import is already running. Cancel it before starting another migration.', array( 'status' => 409 ) );
			}
		}

		$r2_key = sanitize_text_field( $params['r2_key'] ?? '' );
		if ( '' === $r2_key ) {
			return new WP_Error( 'cmsvc_bad_request', 'Missing R2 key.', array( 'status' => 400 ) );
		}

		$r2 = array(
			'account_id' => sanitize_text_field( $params['r2']['account_id'] ?? '' ),
			'access_key' => sanitize_text_field( $params['r2']['access_key'] ?? '' ),
			'secret_key' => sanitize_text_field( $params['r2']['secret_key'] ?? '' ),
			'bucket'     => sanitize_text_field( $params['r2']['bucket'] ?? '' ),
		);

		foreach ( array( 'account_id', 'access_key', 'secret_key', 'bucket' ) as $required ) {
			if ( '' === $r2[ $required ] ) {
				return new WP_Error( 'cmsvc_missing_r2', 'Missing R2 handoff value: ' . $required, array( 'status' => 400 ) );
			}
		}

		$source_context = is_array( $params['source_context'] ?? null ) ? $params['source_context'] : array();
		$source_context = array(
			'source_url'         => isset( $source_context['source_url'] ) ? esc_url_raw( (string) $source_context['source_url'] ) : '',
			'source_site_url'    => isset( $source_context['source_site_url'] ) ? esc_url_raw( (string) $source_context['source_site_url'] ) : '',
			'source_home_url'    => isset( $source_context['source_home_url'] ) ? esc_url_raw( (string) $source_context['source_home_url'] ) : '',
			'source_abspath'     => isset( $source_context['source_abspath'] ) ? wp_normalize_path( (string) $source_context['source_abspath'] ) : '',
			'source_content_dir' => isset( $source_context['source_content_dir'] ) ? wp_normalize_path( (string) $source_context['source_content_dir'] ) : '',
			'source_uploads_dir' => isset( $source_context['source_uploads_dir'] ) ? wp_normalize_path( (string) $source_context['source_uploads_dir'] ) : '',
			'source_uploads_url' => isset( $source_context['source_uploads_url'] ) ? esc_url_raw( (string) $source_context['source_uploads_url'] ) : '',
			'source_table_prefix' => isset( $source_context['source_table_prefix'] ) ? sanitize_text_field( (string) $source_context['source_table_prefix'] ) : '',
			'source_wp_config_defines' => is_array( $source_context['source_wp_config_defines'] ?? null ) ? $source_context['source_wp_config_defines'] : array(),
		);

		if ( '' === $source_context['source_url'] ) {
			return new WP_Error( 'cmsvc_bad_request', 'Missing source URL.', array( 'status' => 400 ) );
		}

		$job                           = $this->new_job( $job_id, 'destination_download' );
		$job['r2_key']                 = $r2_key;
		$job['r2']                     = $r2;
		$job['source_context']         = $source_context;
		$job['auth_site_key']          = $this->rest_agent_request_key( $request );
		$job['do_not_replace_emails']  = ! isset( $params['skip_email_domains'] ) || ! empty( $params['skip_email_domains'] );
		$job['cleanup_after_complete'] = ! isset( $params['cleanup_after_complete'] ) || ! empty( $params['cleanup_after_complete'] );
		$job['message']                = 'Queued destination import from R2.';

		$jobs[ $job_id ] = $job;
		$this->save_jobs( $jobs );
		$this->enqueue_export_job( $job_id, true );

		return rest_ensure_response(
			array(
				'ok'     => true,
				'job_id' => $job_id,
			)
		);
	}

	public function rest_agent_job( WP_REST_Request $request ) {
		$auth = $this->rest_agent_authorize( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$id  = sanitize_text_field( $request['id'] );
		$job = $this->job_by_id( $id );
		if ( empty( $job ) ) {
			return new WP_Error( 'cmsvc_not_found', 'Job not found.', array( 'status' => 404 ) );
		}

		if ( in_array( $job['status'], array( 'queued', 'running' ), true ) && empty( $job['async_runner_active'] ) && empty( $job['cancelled'] ) ) {
			$this->enqueue_export_job( $id );
		}

		$job = $this->public_job( $job );
		if ( ! empty( $job['archive_path'] ) && file_exists( $job['archive_path'] ) ) {
			clearstatcache( true, $job['archive_path'] );
			$job['archive_ready'] = $this->archive_is_complete( $job['archive_path'] );
			$job['archive_size']  = filesize( $job['archive_path'] );
		}
		$job['r2_uploaded'] = ! empty( $job['r2_uploaded'] );
		if ( ! empty( $job['manifest'] ) && is_array( $job['manifest'] ) ) {
			$job = array_merge( $job, $job['manifest'] );
		}

		return rest_ensure_response( $job );
	}

	public function rest_agent_cleanup( WP_REST_Request $request ) {
		$auth = $this->rest_agent_authorize( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$id  = sanitize_text_field( $request['id'] );
		$job = $this->job_by_id( $id );
		if ( empty( $job ) ) {
			return new WP_Error( 'cmsvc_not_found', 'Job not found.', array( 'status' => 404 ) );
		}

		$this->cleanup_job_artifacts( $job );
		if ( ! empty( $job['cancelled'] ) || 'cancelled' === ( $job['status'] ?? '' ) ) {
			$job = $this->finalize_job_cancellation( $job );
		} else {
			$job = $this->mark_job( $job, 'complete', 'agent_cleaned', 'Agent temporary files cleaned.' );
		}
		$this->save_job( $job );

		$cleanup = $this->cleanup_job_artifact_status( $job );

		return rest_ensure_response(
			array(
				'ok'      => true,
				'job_id'  => $id,
				'cleanup' => $cleanup,
			)
		);
	}

	public function rest_agent_cancel( WP_REST_Request $request ) {
		$auth = $this->rest_agent_authorize( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$id      = sanitize_text_field( $request['id'] );
		$params  = $request->get_json_params();
		$message = is_array( $params ) && ! empty( $params['message'] )
			? sanitize_text_field( (string) $params['message'] )
			: 'Cancelled by user.';

		$job = $this->cancel_job_by_id( $id, $message );
		if ( empty( $job ) ) {
			return new WP_Error( 'cmsvc_not_found', 'Job not found.', array( 'status' => 404 ) );
		}

		return rest_ensure_response(
			array(
				'ok'  => true,
				'job' => $this->public_job( $job ),
			)
		);
	}

	public function process_jobs() {
		$jobs = $this->jobs();
		foreach ( $jobs as $job_id => $job ) {
			if ( ! empty( $job['manual_only'] ) || ! empty( $job['async_runner_active'] ) ) {
				continue;
			}

			if ( in_array( $job['status'] ?? '', array( 'queued', 'running' ), true ) && empty( $job['cancelled'] ) ) {
				$this->enqueue_export_job( $job_id );
			}
		}
	}

	public function process_export_queue_task( $task_data ) {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 );
		}

		$job_id = sanitize_text_field( (string) ( $task_data['job_id'] ?? '' ) );
		if ( '' === $job_id ) {
			return;
		}

		$jobs = $this->jobs();
		if ( ! isset( $jobs[ $job_id ] ) ) {
			return;
		}

		$job = $jobs[ $job_id ];
		if ( ! in_array( $job['status'] ?? '', array( 'queued', 'running' ), true ) ) {
			return;
		}

		if ( ! empty( $job['cancelled'] ) ) {
			$jobs[ $job_id ] = $this->finalize_job_cancellation( $job );
			$this->save_jobs( $jobs );
			return;
		}

		try {
			$job = $this->run_export_queue_step( $job );
		} catch ( CMSVC_Cancelled_Exception $e ) {
			$latest_job      = $this->job_by_id( $job_id );
			$latest_job      = empty( $latest_job ) ? $job : $latest_job;
			$jobs[ $job_id ] = $this->finalize_job_cancellation( $latest_job, $e->getMessage() );
			$this->save_jobs( $jobs );
			return;
		} catch ( Exception $e ) {
			$latest_job = $this->job_by_id( $job_id );
			if ( ! empty( $latest_job ) && ! empty( $latest_job['cancelled'] ) ) {
				$jobs[ $job_id ] = $this->finalize_job_cancellation( $latest_job, (string) ( $latest_job['cancel_message'] ?? $e->getMessage() ) );
				$this->save_jobs( $jobs );
				return;
			}

			$job = $this->mark_job( $job, 'running', $job['stage'], 'Retrying after export error: ' . $e->getMessage() );
			$this->save_job( $job );
			throw $e;
		}

		$latest_job = $this->job_by_id( $job_id );
		if ( ! empty( $latest_job ) && ! empty( $latest_job['cancelled'] ) ) {
			$jobs[ $job_id ] = $this->finalize_job_cancellation( $latest_job, (string) ( $latest_job['cancel_message'] ?? '' ) );
			$this->save_jobs( $jobs );
			return;
		}

		$this->save_job( $job );

		$latest_job = $this->job_by_id( $job_id );
		if (
			! empty( $latest_job )
			&& in_array( $latest_job['status'] ?? '', array( 'queued', 'running' ), true )
			&& empty( $latest_job['cancelled'] )
		) {
			$this->enqueue_export_job( $job_id, true );
		}
	}

	private function run_export_queue_step( array $job ) {
		$job['status']     = 'running';
		$job['updated_at'] = time();

		switch ( $job['stage'] ) {
			case 'agent_export':
				return $this->prepare_agent_export_archive( $job );

			case 'agent_exporting':
				if ( ! empty( $job['index_state'] ) ) {
					return $this->process_agent_index_batch( $job );
				}

				if ( ! empty( $job['archive_state'] ) ) {
					return $this->process_agent_archive_batch( $job );
				}

				if ( ! empty( $job['archive_path'] ) && $this->archive_is_complete( $job['archive_path'] ) ) {
					$job['archive_size'] = filesize( $job['archive_path'] );
					$job['manifest']     = $this->source_manifest();
					unset( $job['stage_started_at'] );
					return $this->mark_job( $job, 'running', 'agent_r2_upload', 'Archive created. Uploading directly to R2.' );
				}

				return $this->recover_agent_export_preparation( $job );

			case 'agent_indexing':
				return $this->process_agent_index_batch( $job );

			case 'agent_archiving':
				return $this->process_agent_archive_batch( $job );

			case 'agent_r2_upload':
				return $this->process_agent_r2_upload_batch( $job );

			case 'destination_download':
				return $this->process_destination_download_batch( $job );

			case 'destination_extract':
				return $this->process_destination_extract_batch( $job );

			case 'destination_db_expand':
				return $this->process_destination_database_expand_batch( $job );

			case 'destination_db_import':
				return $this->process_destination_database_import_batch( $job );

			case 'destination_media_regenerate':
				return $this->process_destination_attachment_metadata_batch( $job );

			case 'destination_finalize':
				return $this->finalize_destination_import( $job );
		}

		throw new Exception( 'Unknown job stage: ' . $job['stage'] );
	}

	private function run_job_step( array $job ) {
		return $this->run_export_queue_step( $job );
	}

	private function create_archive( array $job ) {
		$dir = $this->work_dir( $job['id'] );
		wp_mkdir_p( $dir );

		$db_path       = $dir . '/database.sql';
		$manifest_path = $dir . '/manifest.json';
		$archive_path  = $this->archive_path_for_job( $job['id'] );

		foreach ( array( $db_path, $manifest_path, $archive_path ) as $path ) {
			if ( file_exists( $path ) ) {
				wp_delete_file( $path );
				clearstatcache( true, $path );
				if ( file_exists( $path ) ) {
					throw new Exception( 'Unable to remove previous export artifact: ' . basename( $path ) );
				}
			}
		}

		$this->export_database( $db_path, $job['id'] );
		file_put_contents( $manifest_path, wp_json_encode( $this->source_manifest(), JSON_PRETTY_PRINT ) );

		$archive = new CMSVC_Compressor( $archive_path );
		$archive->add_file( $db_path, 'database.sql' );
		$archive->add_file( $manifest_path, 'manifest.json' );
		$this->add_directory_to_archive( $archive, ABSPATH, 'site', array( $this->base_work_dir() ) );
		$archive->close( true );
		clearstatcache( true, $archive_path );

		return $archive_path;
	}

	private function prepare_agent_export_archive( array $job ) {
		$paths = $this->export_artifact_paths( $job['id'] );
		wp_mkdir_p( $paths['dir'] );

		foreach ( array( $paths['db'], $paths['db_gzip'], $paths['manifest'], $paths['list'], $paths['archive'] ) as $path ) {
			if ( file_exists( $path ) ) {
				wp_delete_file( $path );
				clearstatcache( true, $path );
				if ( file_exists( $path ) ) {
					throw new Exception( 'Unable to remove previous export artifact: ' . basename( $path ) );
				}
			}
		}

		$job['archive_path']     = $paths['archive'];
		$job['stage_started_at'] = time();
		$job['index_state']      = array(
			'db_path'          => $paths['db'],
			'manifest_path'    => $paths['manifest'],
			'list_path'        => $paths['list'],
			'indexed_files'    => 0,
			'database_ready'   => false,
			'manifest_ready'   => false,
			'initial_entries'  => false,
			'scan_stack'       => $this->initial_archive_scan_stack(),
		);
		$job                     = $this->mark_job( $job, 'running', 'agent_exporting', 'Exporting database and indexing files.' );
		$this->save_job( $job );

		return $this->process_agent_index_batch( $job );
	}

	private function recover_agent_export_preparation( array $job ) {
		$paths = $this->export_artifact_paths( $job['id'] );

		if ( file_exists( $paths['db'] ) && file_exists( $paths['manifest'] ) && file_exists( $paths['list'] ) ) {
			$indexed_files      = $this->count_archive_file_list_entries( $paths['list'], true );
			$job['archive_path'] = $paths['archive'];
			$job['index_state'] = array(
				'db_path'          => $paths['db'],
				'manifest_path'    => $paths['manifest'],
				'list_path'        => $paths['list'],
				'indexed_files'    => 0,
				'database_ready'   => true,
				'manifest_ready'   => true,
				'initial_entries'  => false,
				'scan_stack'       => $this->initial_archive_scan_stack(),
			);
			$job                 = $this->mark_job( $job, 'running', 'agent_indexing', 'Recovering file index without re-exporting the database.' );
			$this->save_job( $job );

			return $this->process_agent_index_batch( $job );
		}

		$job['stage'] = 'agent_export';
		return $this->prepare_agent_export_archive( $job );
	}

	private function process_agent_index_batch( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$state = is_array( $job['index_state'] ?? null ) ? $job['index_state'] : array();
		$paths = $this->export_artifact_paths( $job['id'] );

		$db_path       = (string) ( $state['db_path'] ?? $paths['db'] );
		$db_gzip_path  = (string) ( $state['db_gzip_path'] ?? $paths['db_gzip'] );
		$manifest_path = (string) ( $state['manifest_path'] ?? $paths['manifest'] );
		$list_path     = (string) ( $state['list_path'] ?? $paths['list'] );

		if ( empty( $state['database_ready'] ) || ! file_exists( $db_path ) ) {
			if ( file_exists( $db_path ) ) {
				wp_delete_file( $db_path );
			}
			if ( file_exists( $manifest_path ) ) {
				wp_delete_file( $manifest_path );
			}
			if ( file_exists( $list_path ) ) {
				wp_delete_file( $list_path );
			}

			$job = $this->mark_job( $job, 'running', 'agent_exporting', 'Exporting database.' );
			$this->save_job( $job );
			$this->export_database( $db_path, $job['id'] );

			$state['database_ready'] = true;
			$state['db_gzip_path']   = $db_gzip_path;
			$state['indexed_files']  = 0;
			$state['scan_stack']     = $this->initial_archive_scan_stack();
			$job['index_state']      = $state;
			$this->save_job( $job );
		}

		if ( ! empty( $state['database_ready'] ) ) {
			$this->assert_job_not_cancelled( $job );
			$state['db_gzip_path'] = $this->prepare_database_archive_artifact( $db_path, $db_gzip_path, $job['id'] ) ? $db_gzip_path : '';
			$job['index_state']    = $state;
			$this->save_job( $job );
		}

		$database_entry = $this->database_archive_entry( $db_path, (string) ( $state['db_gzip_path'] ?? '' ) );

		if ( empty( $state['manifest_ready'] ) || ! file_exists( $manifest_path ) ) {
			$manifest = $this->source_manifest();
			file_put_contents( $manifest_path, wp_json_encode( $manifest, JSON_PRETTY_PRINT ) );
			$job['manifest']          = $manifest;
			$state['manifest_ready']  = true;
			$job['index_state']       = $state;
			$this->save_job( $job );
		} elseif ( empty( $job['manifest'] ) ) {
			$manifest = json_decode( (string) file_get_contents( $manifest_path ), true );
			if ( is_array( $manifest ) ) {
				$job['manifest'] = $manifest;
			}
		}

		if ( empty( $state['initial_entries'] ) || ! file_exists( $list_path ) ) {
			$handle = fopen( $list_path, 'wb' );
			if ( ! $handle ) {
				throw new Exception( 'Unable to write archive file list.' );
			}

			$count  = 0;
			$count += $this->write_archive_file_entry( $handle, $database_entry['source'], $database_entry['archive'] );
			$count += $this->write_archive_file_entry( $handle, $manifest_path, 'manifest.json' );
			fclose( $handle );

			$state['indexed_files']   = $count;
			$state['initial_entries'] = true;
			$state['scan_stack']      = $this->initial_archive_scan_stack();
			$job['index_state']       = $state;
			$this->save_job( $job );
		}

		if ( empty( $state['scan_stack'] ) || ! is_array( $state['scan_stack'] ) ) {
			$existing_count = $this->count_archive_file_list_entries( $list_path, true );
			if ( $existing_count > 2 ) {
				$handle = fopen( $list_path, 'wb' );
				if ( ! $handle ) {
					throw new Exception( 'Unable to reset archive file list for cursor recovery.' );
				}

				$count  = 0;
				$count += $this->write_archive_file_entry( $handle, $database_entry['source'], $database_entry['archive'] );
				$count += $this->write_archive_file_entry( $handle, $manifest_path, 'manifest.json' );
				fclose( $handle );

				$state['indexed_files'] = $count;
			}

			$state['scan_stack']  = $this->initial_archive_scan_stack();
			$job['index_state']   = $state;
			$job                  = $this->mark_job( $job, 'running', 'agent_indexing', 'Recovering file index cursor.' );
			$this->save_job( $job );
		}

		$indexed_files          = max( 0, (int) ( $state['indexed_files'] ?? 0 ) );
		$state['indexed_files'] = $indexed_files;
		if ( $indexed_files < 2 ) {
			$state['initial_entries'] = false;
			$job['index_state']       = $state;
			$this->save_job( $job );
			return $this->process_agent_index_batch( $job );
		}
		$job['index_state']     = $state;
		$job                    = $this->mark_job( $job, 'running', 'agent_indexing', $this->index_progress_message( $state['indexed_files'] ) );
		$this->save_job( $job );

		$handle = fopen( $list_path, 'ab' );
		if ( ! $handle ) {
			throw new Exception( 'Unable to append archive file list.' );
		}

		$deadline          = microtime( true ) + CMSVC_EXPORT_TASK_WINDOW_SECONDS;
		$progress_callback = function ( $indexed_files, $scan_stack = null ) use ( &$job, &$state ) {
			$state['indexed_files'] = $indexed_files;
			if ( is_array( $scan_stack ) ) {
				$state['scan_stack'] = $scan_stack;
			}
			$job['index_state']     = $state;
			$job                    = $this->mark_job( $job, 'running', 'agent_indexing', $this->index_progress_message( $indexed_files ) );
			$this->save_job( $job );
		};

		$result = $this->append_directory_archive_file_entries_from_stack(
			$handle,
			array( $this->base_work_dir() ),
			(array) $state['scan_stack'],
			$deadline,
			$progress_callback,
			(int) $state['indexed_files'],
			$job['id']
		);
		fclose( $handle );

		$state['indexed_files'] = (int) ( $result['indexed_files'] ?? $state['indexed_files'] );
		$state['scan_stack']    = $result['scan_stack'] ?? array();
		$job['index_state']     = $state;

		if ( ! empty( $result['complete'] ) ) {
			$total_files          = $this->count_archive_file_list_entries( $list_path, true );
			$state['indexed_files'] = $total_files;
			$job['archive_size']  = 0;
			$job['archive_state'] = array(
				'list_path'      => $list_path,
				'file_index'     => 0,
				'file_offset'    => 0,
				'archive_offset' => 0,
				'total_files'    => $total_files,
				'list_byte_offset' => 0,
			);
			unset( $job['index_state'] );

			return $this->mark_job( $job, 'running', 'agent_archiving', $this->archive_progress_message( 0, $total_files, 0 ) );
		}

		return $this->mark_job( $job, 'running', 'agent_indexing', $this->index_progress_message( $state['indexed_files'] ) );
	}

	private function export_artifact_paths( $job_id ) {
		$dir = $this->work_dir( $job_id );

		return array(
			'dir'      => $dir,
			'db'       => $dir . '/database.sql',
			'db_gzip'  => $dir . '/database.sql.gz',
			'manifest' => $dir . '/manifest.json',
			'list'     => $dir . '/archive-files.jsonl',
			'archive'  => $this->archive_path_for_job( $job_id ),
		);
	}

	private function prepare_database_archive_artifact( $db_path, $db_gzip_path, $job_id = '' ) {
		if ( ! file_exists( $db_path ) || ! is_readable( $db_path ) || ! function_exists( 'gzopen' ) ) {
			return false;
		}

		clearstatcache( true, $db_path );
		clearstatcache( true, $db_gzip_path );

		if ( file_exists( $db_gzip_path ) && max( 0, (int) filesize( $db_gzip_path ) ) > 0 && filemtime( $db_gzip_path ) >= filemtime( $db_path ) ) {
			return true;
		}

		if ( file_exists( $db_gzip_path ) ) {
			wp_delete_file( $db_gzip_path );
		}

		$input  = @fopen( $db_path, 'rb' );
		$output = @gzopen( $db_gzip_path, 'wb6' );
		if ( false === $input || false === $output ) {
			if ( false !== $input ) {
				@fclose( $input );
			}
			if ( false !== $output ) {
				@gzclose( $output );
			}

			return false;
		}

		try {
			while ( ! feof( $input ) ) {
				$this->assert_job_not_cancelled( $job_id );
				$chunk = @fread( $input, CMSVC_GZIP_STREAM_CHUNK_BYTES );
				if ( false === $chunk ) {
					throw new Exception( 'Unable to read database export for gzip compression.' );
				}

				if ( '' === $chunk ) {
					continue;
				}

				if ( false === @gzwrite( $output, $chunk ) ) {
					throw new Exception( 'Unable to write compressed database export.' );
				}
			}
		} catch ( Exception $e ) {
			@fclose( $input );
			@gzclose( $output );
			if ( file_exists( $db_gzip_path ) ) {
				wp_delete_file( $db_gzip_path );
			}
			return false;
		}

		@fclose( $input );
		@gzclose( $output );
		clearstatcache( true, $db_gzip_path );

		return file_exists( $db_gzip_path ) && max( 0, (int) filesize( $db_gzip_path ) ) > 0;
	}

	private function database_archive_entry( $db_path, $db_gzip_path ) {
		if ( ! empty( $db_gzip_path ) && file_exists( $db_gzip_path ) && is_readable( $db_gzip_path ) ) {
			return array(
				'source'  => $db_gzip_path,
				'archive' => 'database.sql.gz',
			);
		}

		return array(
			'source'  => $db_path,
			'archive' => 'database.sql',
		);
	}

	private function process_agent_archive_batch( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$state        = is_array( $job['archive_state'] ?? null ) ? $job['archive_state'] : array();
		$list_path    = (string) ( $state['list_path'] ?? '' );
		$archive_path = (string) ( $job['archive_path'] ?? '' );

		if ( '' === $list_path || ! file_exists( $list_path ) ) {
			$job['stage'] = 'agent_export';
			return $this->prepare_agent_export_archive( $job );
		}

		if ( '' === $archive_path ) {
			$archive_path         = $this->archive_path_for_job( $job['id'] );
			$job['archive_path'] = $archive_path;
		}

		$file_index     = max( 0, (int) ( $state['file_index'] ?? 0 ) );
		$file_offset    = max( 0, (int) ( $state['file_offset'] ?? 0 ) );
		$archive_offset = max( 0, (int) ( $state['archive_offset'] ?? 0 ) );
		$total_files    = max( 0, (int) ( $state['total_files'] ?? 0 ) );
		$list_byte_offset = isset( $state['list_byte_offset'] )
			? max( 0, (int) $state['list_byte_offset'] )
			: $this->archive_file_list_offset_for_index( $list_path, $file_index );
		$started_at     = microtime( true );

		$this->truncate_file_to_offset( $archive_path, $archive_offset );

		$archive = new CMSVC_Compressor( $archive_path );
		try {
			while ( microtime( true ) - $started_at < CMSVC_EXPORT_TASK_WINDOW_SECONDS && $file_index < $total_files ) {
				$this->assert_job_not_cancelled( $job );

				$entry_result = $this->archive_file_entry_at_offset( $list_path, $list_byte_offset );
				$entry        = $entry_result['entry'] ?? null;
				$next_offset  = (int) ( $entry_result['next_offset'] ?? $list_byte_offset );

				if ( empty( $entry_result ) ) {
					$file_index = $total_files;
					break;
				}

				if ( empty( $entry ) || empty( $entry['source'] ) || empty( $entry['archive'] ) || ! is_file( $entry['source'] ) || ! is_readable( $entry['source'] ) ) {
					$file_index++;
					$file_offset = 0;
					$list_byte_offset = $next_offset;
					$state       = array_merge(
						$state,
						array(
							'file_index'     => $file_index,
							'file_offset'    => $file_offset,
							'archive_offset' => $archive->get_file_pointer(),
							'total_files'    => $total_files,
							'list_byte_offset' => $list_byte_offset,
						)
					);
					$job['archive_state'] = $state;
					$this->save_job( $job );
					continue;
				}

				$result = $archive->add_file_chunk( $entry['source'], $entry['archive'], $file_offset, CMSVC_EXPORT_TASK_CHUNK_BYTES );
				if ( false === $result ) {
					$file_index++;
					$file_offset = 0;
					continue;
				}

				$file_offset    = (int) $result['source_offset'];
				$archive_offset = (int) $result['archive_offset'];

				if ( ! empty( $result['complete'] ) ) {
					$file_index++;
					$file_offset = 0;
					$list_byte_offset = $next_offset;
				}

				$state = array_merge(
					$state,
					array(
						'file_index'     => $file_index,
						'file_offset'    => $file_offset,
						'archive_offset' => $archive_offset,
						'total_files'    => $total_files,
						'list_byte_offset' => $list_byte_offset,
					)
				);

				$job['archive_size']  = $archive_offset;
				$job['archive_state'] = $state;
				$job                  = $this->mark_job( $job, 'running', 'agent_archiving', $this->archive_progress_message( $file_index, $total_files, $archive_offset ) );
				$this->save_job( $job );
			}

			if ( $file_index >= $total_files ) {
				$archive->close( true );
				clearstatcache( true, $archive_path );

				$job['archive_size'] = file_exists( $archive_path ) ? filesize( $archive_path ) : 0;
				$job['manifest']     = $this->source_manifest();
				unset( $job['archive_state'], $job['stage_started_at'] );
				return $this->mark_job( $job, 'running', 'agent_r2_upload', 'Archive created. Uploading directly to R2.' );
			}

			$archive->close( false );
		} catch ( Exception $e ) {
			try {
				$archive->close( false );
			} catch ( Exception $close_exception ) {
				// Keep the original export error; the next queue attempt will reopen the archive.
			}
			throw $e;
		}

		return $this->mark_job( $job, 'running', 'agent_archiving', $this->archive_progress_message( $file_index, $total_files, $archive_offset ) );
	}

	private function write_archive_file_entry( $handle, $source, $archive ) {
		$source = wp_normalize_path( $source );
		if ( ! is_file( $source ) || ! is_readable( $source ) ) {
			return 0;
		}

		fwrite(
			$handle,
			wp_json_encode(
				array(
					'source'  => $source,
					'archive' => ltrim( wp_normalize_path( $archive ), '/' ),
				)
			) . "\n"
		);

		return 1;
	}

	private function initial_archive_scan_stack() {
		return array(
			array(
				'dir'    => wp_normalize_path( ABSPATH ),
				'target' => 'site',
				'offset' => 0,
			),
		);
	}

	private function append_directory_archive_file_entries_from_stack( $handle, array $excluded_roots, array $scan_stack, $deadline, callable $progress_callback, $indexed_files, $job_id = '' ) {
		$excluded_roots      = array_map( 'wp_normalize_path', $excluded_roots );
		$excluded_root_globs = $this->settings_excluded_paths();
		$excluded_extensions = $this->settings_excluded_extensions();
		$indexed_files       = max( 0, (int) $indexed_files );
		$written_since_save  = 0;

		if ( empty( $scan_stack ) ) {
			$scan_stack = $this->initial_archive_scan_stack();
		}

		while ( ! empty( $scan_stack ) ) {
			$frame  = array_pop( $scan_stack );
			$dir    = wp_normalize_path( (string) ( $frame['dir'] ?? '' ) );
			$target = ltrim( wp_normalize_path( (string) ( $frame['target'] ?? 'site' ) ), '/' );
			$offset = max( 0, (int) ( $frame['offset'] ?? 0 ) );

			if ( '' === $dir || ! is_dir( $dir ) || ! is_readable( $dir ) ) {
				continue;
			}

			$entries = @scandir( $dir );
			if ( ! is_array( $entries ) ) {
				continue;
			}

			$total_entries = count( $entries );
			for ( $index = $offset; $index < $total_entries; $index++ ) {
				if ( '' !== $job_id ) {
					$this->assert_job_not_cancelled( $job_id );
				}

				if ( microtime( true ) >= $deadline ) {
					$frame['offset'] = $index;
					$scan_stack[]    = $frame;
					fflush( $handle );
					$progress_callback( $indexed_files, $scan_stack );

					return array(
						'complete'      => false,
						'indexed_files' => $indexed_files,
						'scan_stack'    => $scan_stack,
					);
				}

				$name = $entries[ $index ];
				if ( '.' === $name || '..' === $name ) {
					continue;
				}

				$path = wp_normalize_path( trailingslashit( $dir ) . $name );
				if ( 'wp-config.php' === basename( $path ) ) {
					continue;
				}

				foreach ( $excluded_roots as $excluded ) {
					if ( 0 === strpos( $path, $excluded ) ) {
						continue 2;
					}
				}

				$root     = wp_normalize_path( ABSPATH );
				$relative = ltrim( str_replace( $root, '', $path ), '/' );
				if ( '' !== $relative && $this->path_should_be_skipped_for_migration( $relative, $excluded_root_globs, $excluded_extensions ) ) {
					continue;
				}

				if ( ! is_readable( $path ) ) {
					continue;
				}

				if ( is_dir( $path ) ) {
					$frame['offset'] = $index + 1;
					$scan_stack[]    = $frame;
					$scan_stack[]    = array(
						'dir'    => $path,
						'target' => trailingslashit( $target ) . $name,
						'offset' => 0,
					);

					continue 2;
				}

				if ( is_file( $path ) ) {
					$indexed_files     += $this->write_archive_file_entry( $handle, $path, trailingslashit( $target ) . $name );
					$written_since_save++;

					if ( $written_since_save >= 100 ) {
						$frame['offset'] = $index + 1;
						$saved_stack     = $scan_stack;
						$saved_stack[]   = $frame;
						fflush( $handle );
						$progress_callback( $indexed_files, $saved_stack );
						$written_since_save = 0;
					}
				}
			}
		}

		fflush( $handle );
		$progress_callback( $indexed_files, array() );

		return array(
			'complete'      => true,
			'indexed_files' => $indexed_files,
			'scan_stack'    => array(),
		);
	}

	private function append_directory_archive_file_entries( $handle, $source, $target, array $excluded_roots, $skip_entries, $deadline, callable $progress_callback, $indexed_files ) {
		$source              = wp_normalize_path( $source );
		$excluded_roots      = array_map( 'wp_normalize_path', $excluded_roots );
		$excluded_root_globs = $this->settings_excluded_paths();
		$excluded_extensions = $this->settings_excluded_extensions();
		$skip_entries        = max( 0, (int) $skip_entries );
		$indexed_files       = max( 0, (int) $indexed_files );
		$seen_entries        = 0;
		$written_since_save  = 0;
		$directory_iterator  = new RecursiveDirectoryIterator(
			$source,
			FilesystemIterator::SKIP_DOTS | FilesystemIterator::CURRENT_AS_FILEINFO | FilesystemIterator::KEY_AS_PATHNAME
		);
		$filter              = new RecursiveCallbackFilterIterator(
			$directory_iterator,
			function ( $current ) use ( $source, $excluded_roots, $excluded_root_globs, $excluded_extensions ) {
				$path = wp_normalize_path( $current->getPathname() );

				if ( 'wp-config.php' === basename( $path ) ) {
					return false;
				}

				foreach ( $excluded_roots as $excluded ) {
					if ( 0 === strpos( $path, $excluded ) ) {
						return false;
					}
				}

				$relative = ltrim( str_replace( $source, '', $path ), '/' );
				if ( '' !== $relative && $this->path_should_be_skipped_for_migration( $relative, $excluded_root_globs, $excluded_extensions ) ) {
					return false;
				}

				return $current->isReadable();
			}
		);
		$files               = new RecursiveIteratorIterator(
			$filter,
			RecursiveIteratorIterator::SELF_FIRST,
			RecursiveIteratorIterator::CATCH_GET_CHILD
		);

		foreach ( $files as $file ) {
			$path = wp_normalize_path( $file->getPathname() );

			if ( $file->isDir() || 'wp-config.php' === basename( $path ) ) {
				continue;
			}

			foreach ( $excluded_roots as $excluded ) {
				if ( 0 === strpos( $path, $excluded ) ) {
					continue 2;
				}
			}

			$relative = ltrim( str_replace( $source, '', $path ), '/' );
			if ( '' === $relative || $this->path_should_be_skipped_for_migration( $relative, $excluded_root_globs, $excluded_extensions ) ) {
				continue;
			}

			if ( $seen_entries < $skip_entries ) {
				$seen_entries++;
				continue;
			}

			$indexed_files      += $this->write_archive_file_entry( $handle, $path, trailingslashit( $target ) . $relative );
			$seen_entries++;
			$written_since_save++;

			if ( $written_since_save >= 100 ) {
				fflush( $handle );
				$progress_callback( $indexed_files );
				$written_since_save = 0;
			}

			if ( microtime( true ) >= $deadline ) {
				fflush( $handle );
				$progress_callback( $indexed_files );
				return array(
					'complete'      => false,
					'indexed_files' => $indexed_files,
				);
			}
		}

		fflush( $handle );
		$progress_callback( $indexed_files );

		return array(
			'complete'      => true,
			'indexed_files' => $indexed_files,
		);
	}

	private function count_archive_file_list_entries( $list_path, $truncate_invalid = false ) {
		if ( ! file_exists( $list_path ) ) {
			return 0;
		}

		$handle = fopen( $list_path, 'rb' );
		if ( ! $handle ) {
			return 0;
		}

		$count            = 0;
		$last_good_offset = 0;

		while ( ! feof( $handle ) ) {
			$line = fgets( $handle );
			if ( false === $line ) {
				break;
			}

			$trimmed = trim( $line );
			if ( '' === $trimmed ) {
				$last_good_offset = ftell( $handle );
				continue;
			}

			$entry = json_decode( $trimmed, true );
			if ( ! is_array( $entry ) || empty( $entry['source'] ) || empty( $entry['archive'] ) ) {
				break;
			}

			$count++;
			$last_good_offset = ftell( $handle );
		}

		fclose( $handle );

		if ( $truncate_invalid ) {
			$current_size = filesize( $list_path );
			if ( false !== $current_size && $last_good_offset < $current_size ) {
				$write_handle = fopen( $list_path, 'c+b' );
				if ( $write_handle ) {
					ftruncate( $write_handle, $last_good_offset );
					fclose( $write_handle );
				}
			}
		}

		return $count;
	}

	private function archive_file_entry_at_offset( $list_path, $offset ) {
		if ( ! file_exists( $list_path ) ) {
			return null;
		}

		$handle = fopen( $list_path, 'rb' );
		if ( ! $handle ) {
			return null;
		}

		$offset = max( 0, (int) $offset );
		if ( $offset > 0 && -1 === fseek( $handle, $offset, SEEK_SET ) ) {
			fclose( $handle );
			return null;
		}

		$line = fgets( $handle );
		if ( false === $line ) {
			fclose( $handle );
			return null;
		}

		$next_offset = ftell( $handle );
		fclose( $handle );

		$entry = json_decode( trim( $line ), true );
		if ( ! is_array( $entry ) ) {
			$entry = null;
		}

		return array(
			'entry'       => $entry,
			'next_offset' => false === $next_offset ? $offset + strlen( $line ) : $next_offset,
		);
	}

	private function archive_file_list_offset_for_index( $list_path, $index ) {
		if ( ! file_exists( $list_path ) ) {
			return 0;
		}

		$handle = fopen( $list_path, 'rb' );
		if ( ! $handle ) {
			return 0;
		}

		$index  = max( 0, (int) $index );
		$offset = 0;
		for ( $line_index = 0; $line_index < $index; $line_index++ ) {
			if ( false === fgets( $handle ) ) {
				break;
			}

			$current = ftell( $handle );
			if ( false === $current ) {
				break;
			}

			$offset = $current;
		}

		fclose( $handle );

		return $offset;
	}

	private function archive_file_entry_at( $list_path, $index ) {
		$file = new SplFileObject( $list_path, 'rb' );
		$file->seek( max( 0, (int) $index ) );

		if ( $file->eof() ) {
			return null;
		}

		$line = trim( (string) $file->current() );
		if ( '' === $line ) {
			return null;
		}

		$entry = json_decode( $line, true );
		return is_array( $entry ) ? $entry : null;
	}

	private function truncate_file_to_offset( $path, $offset ) {
		$offset = max( 0, (int) $offset );
		wp_mkdir_p( dirname( $path ) );

		$handle = fopen( $path, 'c+b' );
		if ( ! $handle ) {
			throw new Exception( 'Unable to open archive for resume.' );
		}

		if ( ! ftruncate( $handle, $offset ) ) {
			fclose( $handle );
			throw new Exception( 'Unable to truncate partial archive write.' );
		}

		fclose( $handle );
	}

	private function archive_progress_message( $file_index, $total_files, $archive_size ) {
		$total_files = max( 1, (int) $total_files );
		$percent     = min( 99.9, round( ( max( 0, (int) $file_index ) / $total_files ) * 100, 2 ) );

		return sprintf(
			'Building source archive: %s%% (%d/%d files, %s MB).',
			number_format_i18n( $percent, 2 ),
			(int) $file_index,
			$total_files,
			number_format_i18n( $archive_size / 1048576, 2 )
		);
	}

	private function index_progress_message( $indexed_files ) {
		return sprintf(
			'Indexing source files: %d files queued for archive.',
			max( 0, (int) $indexed_files )
		);
	}

	public function import_archive_from_cli( $archive_path, array $source_context, $skip_email_domains ) {
		$archive_path = wp_normalize_path( $archive_path );
		$job_id       = $this->cli_job_id( 'archive_import', $archive_path . '|' . (string) ( $source_context['source_url'] ?? '' ) );

		$this->upsert_cli_job(
			$job_id,
			'destination_extract',
			array(
				'archive_path'          => $archive_path,
				'source_context'        => $source_context,
				'do_not_replace_emails' => $skip_email_domains,
			)
		);

		$this->run_cli_job_until_complete( $job_id );
	}

	public function import_r2_from_cli( $r2_key, array $r2, array $source_context, $skip_email_domains ) {
		$job_id = $this->cli_job_id(
			'r2_import',
			implode(
				'|',
				array(
					(string) ( $r2['account_id'] ?? '' ),
					(string) ( $r2['bucket'] ?? '' ),
					(string) $r2_key,
					(string) ( $source_context['source_url'] ?? '' ),
				)
			)
		);

		$this->upsert_cli_job(
			$job_id,
			'destination_download',
			array(
				'r2_key'                 => $r2_key,
				'r2'                     => $r2,
				'source_context'         => $source_context,
				'do_not_replace_emails'  => $skip_email_domains,
				'cleanup_after_complete' => true,
			)
		);

		$this->run_cli_job_until_complete( $job_id );
	}

	private function source_manifest() {
		global $wpdb;

		$uploads = wp_get_upload_dir();

		return array(
			'version'            => CMSVC_VERSION,
			'created_at'         => gmdate( 'c' ),
			'source_url'         => home_url(),
			'source_site_url'    => site_url(),
			'source_home_url'    => home_url(),
			'source_abspath'     => ABSPATH,
			'source_content_dir' => WP_CONTENT_DIR,
			'source_uploads_url' => $uploads['baseurl'] ?? '',
			'source_uploads_dir' => $uploads['basedir'] ?? '',
			'source_table_prefix' => isset( $wpdb->prefix ) ? (string) $wpdb->prefix : '',
			'source_wp_config_defines' => $this->supported_wp_config_defines(),
		);
	}

	private function process_agent_r2_upload_batch( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$archive_path = (string) ( $job['archive_path'] ?? '' );
		if ( '' === $archive_path || ! file_exists( $archive_path ) ) {
			throw new Exception( 'Archive not found for R2 upload.' );
		}

		clearstatcache( true, $archive_path );
		$file_size = max( 0, (int) filesize( $archive_path ) );
		$state     = is_array( $job['r2_upload_state'] ?? null ) ? $job['r2_upload_state'] : array();

		if ( empty( $state['upload_id'] ) ) {
			$state = array(
				'upload_id'     => $this->r2_create_multipart_upload( $job['r2'], $job['r2_key'] ),
				'file_size'     => $file_size,
				'source_offset' => 0,
				'part_number'   => 1,
				'parts'         => array(),
			);
		}

		$started_at    = microtime( true );
		$source_offset = max( 0, (int) ( $state['source_offset'] ?? 0 ) );
		$part_number   = max( 1, (int) ( $state['part_number'] ?? 1 ) );
		$parts         = is_array( $state['parts'] ?? null ) ? $state['parts'] : array();

		while ( microtime( true ) - $started_at < CMSVC_EXPORT_TASK_WINDOW_SECONDS && $source_offset < $file_size ) {
			$this->assert_job_not_cancelled( $job );
			$part_size = min( CMSVC_R2_MULTIPART_PART_BYTES, $file_size - $source_offset );
			$etag      = $this->r2_upload_part( $job['r2'], $job['r2_key'], $state['upload_id'], $part_number, $archive_path, $source_offset, $part_size );

			$parts[]       = array(
				'part_number' => $part_number,
				'etag'        => $etag,
			);
			$source_offset += $part_size;
			$part_number++;

			$state['source_offset'] = $source_offset;
			$state['part_number']   = $part_number;
			$state['parts']         = $parts;
			$state['file_size']     = $file_size;
			$job['r2_upload_state'] = $state;
			$job['r2_uploaded']     = $source_offset >= $file_size;
			$job['archive_size']    = $file_size;
			$job                    = $this->mark_job( $job, 'running', 'agent_r2_upload', $this->r2_upload_progress_message( $source_offset, $file_size ) );
			$this->save_job( $job );
		}

		if ( $source_offset >= $file_size ) {
			try {
				$this->r2_complete_multipart_upload( $job['r2'], $job['r2_key'], $state['upload_id'], $parts );
			} catch ( Exception $e ) {
				if ( $this->r2_remote_object_matches_size( $job['r2'], $job['r2_key'], $file_size ) ) {
					$job['r2_uploaded'] = true;
					unset( $job['archive_state'], $job['r2_upload_state'] );
					return $this->mark_job( $job, 'complete', 'agent_complete', 'Archive uploaded to R2 and ready for SSH import.' );
				}

				if ( 'NoSuchUpload' === $this->r2_error_code_from_exception( $e ) ) {
					unset( $job['r2_upload_state'] );
					$job['r2_uploaded'] = false;
					return $this->mark_job( $job, 'running', 'agent_r2_upload', 'R2 upload session expired while finalizing. Restarting multipart upload.' );
				}

				throw $e;
			}

			$job['r2_uploaded'] = true;
			unset( $job['archive_state'], $job['r2_upload_state'] );
			return $this->mark_job( $job, 'complete', 'agent_complete', 'Archive uploaded to R2 and ready for SSH import.' );
		}

		return $this->mark_job( $job, 'running', 'agent_r2_upload', $this->r2_upload_progress_message( $source_offset, $file_size ) );
	}

	private function process_destination_download_batch( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$archive_path = (string) ( $job['archive_path'] ?? '' );
		if ( '' === $archive_path ) {
			$archive_path         = $this->work_dir( $job['id'] ) . '/' . sanitize_file_name( basename( (string) ( $job['r2_key'] ?? 'archive.wpress' ) ) );
			$job['archive_path'] = $archive_path;
		}

		wp_mkdir_p( dirname( $archive_path ) );

		$state = is_array( $job['download_state'] ?? null ) ? $job['download_state'] : array();
		if ( empty( $state['file_size'] ) ) {
			$remote            = $this->r2_head_object( $job['r2'], $job['r2_key'] );
			$existing_size     = file_exists( $archive_path ) ? max( 0, (int) filesize( $archive_path ) ) : 0;
			$state['file_size'] = max( 0, (int) ( $remote['content_length'] ?? 0 ) );
			$state['offset']    = min( $existing_size, $state['file_size'] );
			if ( $existing_size > $state['offset'] ) {
				$this->truncate_file_to_offset( $archive_path, $state['offset'] );
			}
		}

		$file_size = max( 0, (int) ( $state['file_size'] ?? 0 ) );
		$offset    = max( 0, (int) ( $state['offset'] ?? 0 ) );
		$started_at = microtime( true );

		while ( microtime( true ) - $started_at < CMSVC_EXPORT_TASK_WINDOW_SECONDS && $offset < $file_size ) {
			$this->assert_job_not_cancelled( $job );
			$chunk_size = min( CMSVC_R2_DOWNLOAD_CHUNK_BYTES, $file_size - $offset );
			$this->r2_download_part( $job['r2'], $job['r2_key'], $archive_path, $offset, $chunk_size );
			$offset += $chunk_size;

			$state['offset']       = $offset;
			$job['download_state'] = $state;
			$job['archive_size']   = $offset;
			$job                   = $this->mark_job( $job, 'running', 'destination_download', $this->destination_download_progress_message( $offset, $file_size ) );
			$this->save_job( $job );
		}

		if ( $offset >= $file_size ) {
			unset( $job['download_state'] );
			return $this->mark_job( $job, 'running', 'destination_extract', 'Archive downloaded from R2. Extracting files.' );
		}

		return $this->mark_job( $job, 'running', 'destination_download', $this->destination_download_progress_message( $offset, $file_size ) );
	}

	private function process_destination_extract_batch( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$archive_path = (string) ( $job['archive_path'] ?? '' );
		if ( '' === $archive_path || ! file_exists( $archive_path ) ) {
			throw new Exception( 'Archive not found on destination.' );
		}

		$extract_dir = $this->work_dir( $job['id'] ) . '/extract';
		wp_mkdir_p( $extract_dir );

		$state = is_array( $job['extract_state'] ?? null ) ? $job['extract_state'] : array();
		if ( empty( $state['validated'] ) ) {
			$extractor = new CMSVC_Extractor( $archive_path );
			$is_valid  = $extractor->is_valid();
			$extractor->close();
			if ( ! $is_valid ) {
				throw new Exception( 'Archive format is invalid.' );
			}

			$state = array(
				'validated'       => true,
				'archive_offset'  => 0,
				'file_offset'     => 0,
				'extracted_files' => 0,
			);
		}

		$extractor     = new CMSVC_Extractor( $archive_path );
		$archive_offset = max( 0, (int) ( $state['archive_offset'] ?? 0 ) );
		$file_offset    = max( 0, (int) ( $state['file_offset'] ?? 0 ) );
		$extracted_files = max( 0, (int) ( $state['extracted_files'] ?? 0 ) );
		$started_at     = microtime( true );

		try {
			while ( microtime( true ) - $started_at < CMSVC_EXPORT_TASK_WINDOW_SECONDS ) {
				$this->assert_job_not_cancelled( $job );
				$entry = $extractor->entry_at_offset( $archive_offset );
				if ( empty( $entry ) ) {
					break;
				}

				$target = $this->import_extract_target( $entry, $extract_dir );
				if ( false === $target ) {
					$archive_offset = (int) $entry['next_offset'];
					$file_offset    = 0;
					$state          = array(
						'validated'       => true,
						'archive_offset'  => $archive_offset,
						'file_offset'     => $file_offset,
						'extracted_files' => $extracted_files,
					);
					$job['extract_state'] = $state;
					$this->save_job( $job );
					continue;
				}

				$result = $extractor->extract_entry_chunk( $entry, $target, $file_offset, CMSVC_IMPORT_EXTRACT_CHUNK_BYTES );
				$file_offset = max( 0, (int) ( $result['source_offset'] ?? 0 ) );
				if ( ! empty( $result['complete'] ) ) {
					$archive_offset = (int) ( $result['next_offset'] ?? $entry['next_offset'] );
					$file_offset    = 0;
					$extracted_files++;
				}

				$state = array(
					'validated'       => true,
					'archive_offset'  => $archive_offset,
					'file_offset'     => $file_offset,
					'extracted_files' => $extracted_files,
				);
				$job['extract_state'] = $state;
				$job                  = $this->mark_job( $job, 'running', 'destination_extract', $this->destination_extract_progress_message( $extracted_files ) );
				$this->save_job( $job );
			}
		} finally {
			$extractor->close();
		}

		$db_path      = $extract_dir . '/database.sql';
		$db_gzip_path = $extract_dir . '/database.sql.gz';
		if ( ! file_exists( $db_path ) && ! file_exists( $db_gzip_path ) ) {
			throw new Exception( 'Archive is missing database.sql or database.sql.gz.' );
		}

		$next_entry = $this->archive_next_entry_at_offset( $archive_path, $archive_offset );
		if ( null === $next_entry && 0 === $file_offset ) {
			unset( $job['extract_state'] );
			if ( ! file_exists( $db_path ) && file_exists( $db_gzip_path ) ) {
				return $this->mark_job( $job, 'running', 'destination_db_expand', 'Archive extracted. Expanding compressed database export.' );
			}
			return $this->mark_job( $job, 'running', 'destination_db_import', 'Archive extracted. Importing database.' );
		}

		return $this->mark_job( $job, 'running', 'destination_extract', $this->destination_extract_progress_message( $extracted_files ) );
	}

	private function process_destination_database_import_batch( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$extract_dir = $this->work_dir( $job['id'] ) . '/extract';
		$db_path     = $extract_dir . '/database.sql';
		if ( ! file_exists( $db_path ) ) {
			throw new Exception( 'Database export was not extracted.' );
		}

		$source_context = $this->import_source_context( $job, $extract_dir );
		$skip_emails    = ! empty( $job['do_not_replace_emails'] );
		$state          = is_array( $job['db_import_state'] ?? null ) ? $job['db_import_state'] : array();

		if ( empty( $job['destination_settings_snapshot'] ) ) {
			$job['destination_settings_snapshot'] = $this->settings();
		}

		if ( $this->can_use_async_database_import_runner() ) {
			if ( empty( $state['async_runner_started'] ) ) {
				$state['async_runner_started'] = true;
				$state['runner_status']        = 'starting';
				$state['file_size']           = max( 0, (int) filesize( $db_path ) );
				$state['bytes_imported']      = max( 0, (int) ( $state['bytes_imported'] ?? 0 ) );
				$job['db_import_state']       = $state;
				$job['async_runner_active']   = true;
				$job                          = $this->mark_job( $job, 'running', 'destination_db_import', 'Starting detached database import runner.' );
				$this->save_job( $job );
				try {
					$this->launch_async_database_import_runner( $job['id'] );
				} catch ( Exception $e ) {
					$job['async_runner_active'] = false;
					$state['runner_status']     = 'failed';
					$job['db_import_state']     = $state;
					$this->save_job( $job );
					throw $e;
				}
				return $job;
			}

			$latest_jobs = $this->jobs();
			$latest_job  = $latest_jobs[ $job['id'] ] ?? $job;

			if ( 'failed' === ( $latest_job['status'] ?? '' ) ) {
				throw new Exception( (string) ( $latest_job['message'] ?? 'Database import failed.' ) );
			}

			return $latest_job;
		}

		if ( empty( $state['mode'] ) ) {
			$uploads = wp_get_upload_dir();
			$state = array(
				'mode'          => $this->can_use_native_mysql_import() ? 'mysql' : 'php',
				'offset'        => 0,
				'query_buffer'  => '',
				'started'       => false,
				'bytes_imported' => 0,
				'target_context' => array(
					'site_url'   => site_url(),
					'home_url'   => home_url(),
					'abspath'    => ABSPATH,
					'content_dir' => WP_CONTENT_DIR,
					'uploads'    => array(
						'basedir' => $uploads['basedir'] ?? '',
						'baseurl' => $uploads['baseurl'] ?? '',
					),
				),
			);
		}

		$rewrite_context                     = $source_context;
		$rewrite_context['__target_context'] = $state['target_context'] ?? array();

		if ( 'mysql' === $state['mode'] ) {
			$result = $this->import_database_sql_batch_with_mysql_client( $job, $db_path, $rewrite_context, $skip_emails, $state );
		} else {
			$result = $this->import_database_sql_batch_with_php( $job, $db_path, $rewrite_context, $skip_emails, $state );
		}

		$job['db_import_state'] = $result['state'];
		$job                    = $this->mark_job(
			$job,
			'running',
			'destination_db_import',
			$this->destination_database_progress_message( (int) $result['state']['bytes_imported'], (int) $result['state']['file_size'] )
		);
		$this->save_job( $job );

		if ( empty( $result['complete'] ) ) {
			return $job;
		}

		unset( $job['db_import_state'] );
		return $this->mark_job( $job, 'running', 'destination_finalize', 'Database imported. Finalizing destination state.' );
	}

	private function process_destination_database_expand_batch( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$extract_dir  = $this->work_dir( $job['id'] ) . '/extract';
		$db_gzip_path = $extract_dir . '/database.sql.gz';
		$db_path      = $extract_dir . '/database.sql';

		if ( ! file_exists( $db_gzip_path ) ) {
			if ( file_exists( $db_path ) ) {
				return $this->mark_job( $job, 'running', 'destination_db_import', 'Compressed database already expanded. Importing database.' );
			}

			throw new Exception( 'Compressed database export was not extracted.' );
		}

		if ( ! function_exists( 'gzopen' ) ) {
			throw new Exception( 'PHP zlib support is required to expand database.sql.gz on the destination.' );
		}

		$compressed_size = max( 0, (int) filesize( $db_gzip_path ) );
		$state           = is_array( $job['db_expand_state'] ?? null ) ? $job['db_expand_state'] : array();
		$offset          = max( 0, (int) ( $state['offset'] ?? 0 ) );
		$started_at      = microtime( true );
		$complete        = false;

		$gzip_handle = @gzopen( $db_gzip_path, 'rb' );
		if ( false === $gzip_handle ) {
			throw new Exception( 'Unable to open compressed database export.' );
		}

		$target_handle = @fopen( $db_path, $offset > 0 ? 'c+b' : 'wb' );
		if ( false === $target_handle ) {
			@gzclose( $gzip_handle );
			throw new Exception( 'Unable to expand database export to database.sql.' );
		}

		try {
			if ( $offset > 0 ) {
				if ( -1 === @fseek( $target_handle, $offset, SEEK_SET ) ) {
					throw new Exception( 'Unable to resume expanded database.sql.' );
				}

				if ( 0 !== @gzseek( $gzip_handle, $offset ) ) {
					throw new Exception( 'Unable to resume compressed database expansion.' );
				}
			}

			while ( microtime( true ) - $started_at < CMSVC_EXPORT_TASK_WINDOW_SECONDS && ! gzeof( $gzip_handle ) ) {
				$this->assert_job_not_cancelled( $job );
				$chunk = @gzread( $gzip_handle, CMSVC_GZIP_STREAM_CHUNK_BYTES );
				if ( false === $chunk ) {
					throw new Exception( 'Unable to read compressed database export.' );
				}

				if ( '' === $chunk ) {
					break;
				}

				$written = @fwrite( $target_handle, $chunk );
				if ( false === $written || strlen( $chunk ) !== $written ) {
					throw new Exception( 'Unable to write expanded database export.' );
				}

				$offset += strlen( $chunk );
				$job['db_expand_state'] = array(
					'offset'          => $offset,
					'compressed_size' => $compressed_size,
				);
				$job = $this->mark_job( $job, 'running', 'destination_db_expand', $this->destination_database_expand_progress_message( $offset, $compressed_size ) );
				$this->save_job( $job );
			}

			$complete = gzeof( $gzip_handle );
		} finally {
			@fclose( $target_handle );
			@gzclose( $gzip_handle );
		}

		if ( $complete ) {
			unset( $job['db_expand_state'] );
			wp_delete_file( $db_gzip_path );
			return $this->mark_job( $job, 'running', 'destination_db_import', 'Compressed database expanded. Importing database.' );
		}

		return $this->mark_job( $job, 'running', 'destination_db_expand', $this->destination_database_expand_progress_message( $offset, $compressed_size ) );
	}

	public function run_async_database_import_job( $job_id ) {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 );
		}

		$job_id = sanitize_text_field( (string) $job_id );
		if ( '' === $job_id ) {
			throw new Exception( 'Missing import job ID.' );
		}

		$jobs = $this->jobs();
		if ( ! isset( $jobs[ $job_id ] ) ) {
			throw new Exception( 'Import job could not be found.' );
		}

		$job = $jobs[ $job_id ];
		if ( 'destination_db_import' !== ( $job['stage'] ?? '' ) ) {
			return;
		}

		try {
			$this->perform_async_database_import_job( $job );
		} catch ( CMSVC_Cancelled_Exception $e ) {
			$jobs = $this->jobs();
			$job  = $jobs[ $job_id ] ?? $job;
			$job  = $this->finalize_job_cancellation( $job, $e->getMessage() );
			$this->save_job( $job );
			return;
		} catch ( Exception $e ) {
			$jobs = $this->jobs();
			$job  = $jobs[ $job_id ] ?? $job;
			$state = is_array( $job['db_import_state'] ?? null ) ? $job['db_import_state'] : array();
			$state['runner_status'] = 'failed';
			$job['db_import_state'] = $state;
			$job['async_runner_active'] = false;
			$job = $this->mark_job( $job, 'failed', $job['stage'] ?? 'destination_db_import', $e->getMessage() );
			$this->save_job( $job );
			throw $e;
		}
	}

	private function perform_async_database_import_job( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$extract_dir     = $this->work_dir( $job['id'] ) . '/extract';
		$db_path         = $extract_dir . '/database.sql';
		$source_context  = $this->import_source_context( $job, $extract_dir );
		$skip_emails     = ! empty( $job['do_not_replace_emails'] );
		$state           = is_array( $job['db_import_state'] ?? null ) ? $job['db_import_state'] : array();
		$state['runner_status']   = 'running';
		$state['file_size']       = max( 0, (int) filesize( $db_path ) );
		$state['bytes_imported']  = max( 0, (int) ( $state['bytes_imported'] ?? 0 ) );
		$job['db_import_state']   = $state;
		$job['async_runner_active'] = true;
		$job = $this->mark_job(
			$job,
			'running',
			'destination_db_import',
			$this->destination_database_progress_message( (int) $state['bytes_imported'], (int) $state['file_size'] )
		);
		$this->save_job( $job );

		$this->clear_destination_database_for_import( $job );
		$this->assert_job_not_cancelled( $job );
		$job = $this->import_database_sql_with_database_client_batches( $job, $db_path );
		$this->assert_job_not_cancelled( $job );
		$job = $this->normalize_destination_table_prefix( $job, $source_context );
		$this->assert_job_not_cancelled( $job );
		$job = $this->run_destination_url_search_replace( $job, $source_context, $skip_emails );

		$state = is_array( $job['db_import_state'] ?? null ) ? $job['db_import_state'] : array();
		$state['runner_status'] = 'complete';
		$job['db_import_state'] = $state;
		$job = $this->mark_job( $job, 'running', 'destination_finalize', 'Database imported. Finalizing destination state.' );
		$this->save_job( $job );

		$job = $this->finalize_destination_import( $job );
		unset( $job['db_import_state'] );
		$job['async_runner_active'] = false;
		$this->save_job( $job );
	}

	private function finalize_destination_import( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$source_context = $this->import_source_context( $job, $this->work_dir( $job['id'] ) . '/extract' );

		if ( ! empty( $job['destination_settings_snapshot'] ) && is_array( $job['destination_settings_snapshot'] ) ) {
			update_option( CMSVC_OPTION_SETTINGS, $job['destination_settings_snapshot'], false );
		}

		$this->apply_destination_wp_config_overrides( $source_context, $job['id'] );
		$this->assert_job_not_cancelled( $job );
		$this->finalize_import_state();
		$this->assert_job_not_cancelled( $job );

		$job = $this->prepare_destination_attachment_metadata_regeneration( $job );
		if ( 'destination_media_regenerate' === ( $job['stage'] ?? '' ) ) {
			return $job;
		}

		return $this->complete_destination_import( $job, $source_context );
	}

	private function complete_destination_import( array $job, array $source_context ) {
		$this->run_post_import_actions( $source_context );

		if ( ! empty( $job['cleanup_after_complete'] ) ) {
			$this->cleanup_job_artifacts( $job );
		}

		unset( $job['destination_settings_snapshot'] );
		return $this->mark_job( $job, 'complete', 'destination_complete', 'Archive imported successfully.' );
	}

	private function prepare_destination_attachment_metadata_regeneration( array $job ) {
		$state = is_array( $job['attachment_regen_state'] ?? null ) ? $job['attachment_regen_state'] : array();
		if ( empty( $state ) ) {
			$state = array(
				'last_attachment_id' => 0,
				'processed'          => 0,
				'updated'            => 0,
				'recovered_paths'    => 0,
				'missing_files'      => 0,
				'total'              => $this->destination_attachment_regeneration_candidate_count(),
			);
		}

		if ( empty( $state['total'] ) ) {
			unset( $job['attachment_regen_state'] );
			return $job;
		}

		$job['attachment_regen_state'] = $state;
		return $this->mark_job(
			$job,
			'running',
			'destination_media_regenerate',
			$this->destination_attachment_regenerate_progress_message(
				(int) $state['processed'],
				(int) $state['total'],
				(int) $state['updated'],
				(int) $state['recovered_paths']
			)
		);
	}

	private function process_destination_attachment_metadata_batch( array $job ) {
		global $wpdb;

		$this->assert_job_not_cancelled( $job );

		$state = is_array( $job['attachment_regen_state'] ?? null ) ? $job['attachment_regen_state'] : array();
		if ( empty( $state ) ) {
			$job = $this->prepare_destination_attachment_metadata_regeneration( $job );
			if ( 'destination_media_regenerate' !== ( $job['stage'] ?? '' ) ) {
				$source_context = $this->import_source_context( $job, $this->work_dir( $job['id'] ) . '/extract' );
				return $this->complete_destination_import( $job, $source_context );
			}
			$state = $job['attachment_regen_state'];
		}

		$started_at = microtime( true );
		$complete   = false;

		while ( microtime( true ) - $started_at < CMSVC_EXPORT_TASK_WINDOW_SECONDS ) {
			$this->assert_job_not_cancelled( $job );

			$attachment_ids = $this->next_attachment_regeneration_candidate_batch(
				(int) $state['last_attachment_id'],
				CMSVC_IMPORT_ATTACHMENT_REGEN_BATCH_SIZE
			);

			if ( empty( $attachment_ids ) ) {
				$complete = true;
				break;
			}

			foreach ( $attachment_ids as $attachment_id ) {
				$this->assert_job_not_cancelled( $job );

				$attachment_id               = (int) $attachment_id;
				$state['last_attachment_id'] = $attachment_id;
				$state['processed']          = (int) $state['processed'] + 1;

				$result = $this->repair_attachment_metadata( $attachment_id );
				if ( ! empty( $result['updated'] ) ) {
					$state['updated'] = (int) $state['updated'] + 1;
				}
				if ( ! empty( $result['recovered_path'] ) ) {
					$state['recovered_paths'] = (int) $state['recovered_paths'] + 1;
				}
				if ( ! empty( $result['missing_file'] ) ) {
					$state['missing_files'] = (int) $state['missing_files'] + 1;
				}
			}

			if ( count( $attachment_ids ) < CMSVC_IMPORT_ATTACHMENT_REGEN_BATCH_SIZE ) {
				$complete = true;
				break;
			}
		}

		$job['attachment_regen_state'] = $state;
		$job                           = $this->mark_job(
			$job,
			'running',
			'destination_media_regenerate',
			$this->destination_attachment_regenerate_progress_message(
				(int) $state['processed'],
				(int) $state['total'],
				(int) $state['updated'],
				(int) $state['recovered_paths']
			)
		);
		$this->save_job( $job );

		if ( ! $complete ) {
			return $job;
		}

		unset( $job['attachment_regen_state'] );
		$source_context = $this->import_source_context( $job, $this->work_dir( $job['id'] ) . '/extract' );
		return $this->complete_destination_import( $job, $source_context );
	}

	private function cli_job_id( $prefix, $fingerprint ) {
		return 'cli_' . sanitize_key( $prefix ) . '_' . substr( hash( 'sha256', (string) $fingerprint ), 0, 16 );
	}

	private function upsert_cli_job( $job_id, $stage, array $attributes ) {
		$jobs = $this->jobs();
		$job  = $jobs[ $job_id ] ?? $this->new_job( $job_id, $stage );

		if ( in_array( $job['status'] ?? '', array( 'complete', 'cancelled' ), true ) ) {
			$job = $this->new_job( $job_id, $stage );
		}

		$job['stage']      = $job['stage'] ?? $stage;
		$job['status']     = in_array( $job['status'] ?? '', array( 'running', 'queued' ), true ) ? $job['status'] : 'queued';
		$job['updated_at'] = time();

		foreach ( $attributes as $key => $value ) {
			$job[ $key ] = $value;
		}
		$job['manual_only'] = true;

		$this->save_job( $job );
		return $job;
	}

	private function run_cli_job_until_complete( $job_id ) {
		$retries = 0;

		while ( true ) {
			$jobs = $this->jobs();
			if ( ! isset( $jobs[ $job_id ] ) ) {
				throw new Exception( 'Import job could not be found.' );
			}

			$job = $jobs[ $job_id ];
			if ( 'complete' === ( $job['status'] ?? '' ) ) {
				return;
			}

			if ( 'cancelled' === ( $job['status'] ?? '' ) ) {
				throw new Exception( 'Import job was cancelled.' );
			}

			if ( 'failed' === ( $job['status'] ?? '' ) ) {
				throw new Exception( (string) ( $job['message'] ?? 'Import job failed.' ) );
			}

			if ( ! empty( $job['async_runner_active'] ) ) {
				sleep( 2 );
				continue;
			}

			try {
				$job = $this->run_export_queue_step( $job );
				$this->save_job( $job );
				$retries = 0;
			} catch ( CMSVC_Cancelled_Exception $e ) {
				$job = $this->finalize_job_cancellation( $job, $e->getMessage() );
				$this->save_job( $job );
				throw new Exception( 'Import job was cancelled.' );
			} catch ( Exception $e ) {
				$retries++;
				$job = $this->mark_job( $job, 'running', $job['stage'], 'Retrying after import error: ' . $e->getMessage() );
				$this->save_job( $job );

				if ( $retries >= CMSVC_CLI_RETRY_LIMIT ) {
					$job = $this->mark_job( $job, 'failed', $job['stage'], $e->getMessage() );
					$this->save_job( $job );
					throw $e;
				}

				sleep( CMSVC_CLI_RETRY_DELAY_SECONDS );
			}
		}
	}

	private function export_database( $path, $job_id = '' ) {
		if ( $this->can_use_mysqldump() ) {
			$this->export_database_with_mysqldump( $path, $job_id );
			return;
		}

		$this->export_database_with_php( $path, $job_id );
	}

	private function export_database_with_mysqldump( $path, $job_id = '' ) {
		$defaults_file = $this->create_mysql_defaults_file();
		$parts         = $this->mysql_connection_parts();
		$tables        = $this->database_tables();

		$command = array(
			'mysqldump',
			'--defaults-extra-file=' . $defaults_file,
			'--single-transaction',
			'--quick',
			'--skip-lock-tables',
			'--no-tablespaces',
			'--default-character-set=utf8mb4',
			'--skip-comments',
			'--result-file=' . $path,
		);

		if ( ! empty( $parts['host'] ) ) {
			$command[] = '--host=' . $parts['host'];
		}
		if ( ! empty( $parts['port'] ) ) {
			$command[] = '--port=' . $parts['port'];
		}
		if ( ! empty( $parts['socket'] ) ) {
			$command[] = '--socket=' . $parts['socket'];
		}

		$command[] = DB_NAME;
		$command   = array_merge( $command, $tables );

		try {
			$this->run_shell_command( $command, null, $job_id );
		} catch ( Exception $e ) {
			@unlink( $defaults_file );
			throw $e;
		}

		@unlink( $defaults_file );

		if ( ! file_exists( $path ) || 0 === filesize( $path ) ) {
			throw new Exception( 'mysqldump did not produce a database export.' );
		}
	}

	private function export_database_with_php( $path, $job_id = '' ) {
		global $wpdb;

		$handle = fopen( $path, 'wb' );
		if ( ! $handle ) {
			throw new Exception( 'Unable to write database export.' );
		}

		fwrite( $handle, "-- Cloud Migration Service database export\nSET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\nSET UNIQUE_CHECKS=0;\n\n" );
		$tables = $wpdb->get_col( 'SHOW TABLES' );

		foreach ( $tables as $table ) {
			$this->assert_job_not_cancelled( $job_id );
			$create = $wpdb->get_row( 'SHOW CREATE TABLE `' . esc_sql( $table ) . '`', ARRAY_N );
			fwrite( $handle, "DROP TABLE IF EXISTS `{$table}`;\n" . $create[1] . ";\n\n" );

			$columns    = $wpdb->get_col( 'SHOW COLUMNS FROM `' . esc_sql( $table ) . '`', 0 );
			$primary    = $this->table_primary_key( $table );
			$batch_size = 500;

			if ( $primary ) {
				$last_value = null;
				do {
					$this->assert_job_not_cancelled( $job_id );
					if ( null === $last_value ) {
						$query = $wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY `{$primary}` ASC LIMIT %d", $batch_size );
					} else {
						$query = $wpdb->prepare( "SELECT * FROM `{$table}` WHERE `{$primary}` > %s ORDER BY `{$primary}` ASC LIMIT %d", $last_value, $batch_size );
					}

					$rows = $wpdb->get_results( $query, ARRAY_A );
					$this->write_sql_insert_batch( $handle, $table, $columns, $rows );
					if ( ! empty( $rows ) ) {
						$last_value = $rows[ count( $rows ) - 1 ][ $primary ];
					}
				} while ( count( $rows ) === $batch_size );
			} else {
				$offset = 0;
				do {
					$this->assert_job_not_cancelled( $job_id );
					$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` LIMIT %d OFFSET %d", $batch_size, $offset ), ARRAY_A );
					$this->write_sql_insert_batch( $handle, $table, $columns, $rows );
					$offset += $batch_size;
				} while ( count( $rows ) === $batch_size );
			}

			fwrite( $handle, "\n" );
		}

		fwrite( $handle, "SET FOREIGN_KEY_CHECKS=1;\nSET UNIQUE_CHECKS=1;\n" );
		fclose( $handle );
	}

	private function write_sql_insert_batch( $handle, $table, array $columns, array $rows ) {
		if ( empty( $rows ) ) {
			return;
		}

		$values_sql = array();
		foreach ( $rows as $row ) {
			$values = array();
			foreach ( $columns as $column ) {
				$value    = $row[ $column ] ?? null;
				$values[] = null === $value ? 'NULL' : "'" . $this->escape_sql_export_value( $value ) . "'";
			}
			$values_sql[] = '(' . implode( ',', $values ) . ')';
		}

		fwrite( $handle, 'INSERT INTO `' . $table . '` (`' . implode( '`,`', $columns ) . '`) VALUES ' . implode( ',', $values_sql ) . ";\n" );
	}

	private function table_primary_key( $table ) {
		global $wpdb;

		$table = esc_sql( $table );
		$index = $wpdb->get_results( "SHOW KEYS FROM `{$table}` WHERE Key_name = 'PRIMARY'", ARRAY_A );
		if ( empty( $index ) ) {
			return '';
		}

		usort(
			$index,
			static function ( $left, $right ) {
				return (int) ( $left['Seq_in_index'] ?? 0 ) <=> (int) ( $right['Seq_in_index'] ?? 0 );
			}
		);

		if ( empty( $index[0]['Column_name'] ) ) {
			return '';
		}

		return (string) $index[0]['Column_name'];
	}

	private function import_source_context( array $job, $extract_dir ) {
		$manifest      = array();
		$manifest_path = trailingslashit( $extract_dir ) . 'manifest.json';

		if ( file_exists( $manifest_path ) ) {
			$manifest = json_decode( (string) file_get_contents( $manifest_path ), true );
			if ( ! is_array( $manifest ) ) {
				$manifest = array();
			}
		}

		return array_merge( $manifest, $job['source_context'] ?? array() );
	}

	private function import_extract_target( array $entry, $extract_dir ) {
		$entry_name = ltrim( wp_normalize_path( $entry['filename'] ?? '' ), '/' );

		if ( 'database.sql' === $entry_name || 'database.sql.gz' === $entry_name || 'manifest.json' === $entry_name ) {
			return $extract_dir . '/' . basename( $entry_name );
		}

		if ( 0 === strpos( $entry_name, 'site/' ) ) {
			$relative = substr( $entry_name, 5 );
			if ( '' === $relative || $this->path_is_protected_for_migration( $relative ) ) {
				return false;
			}

			return trailingslashit( ABSPATH ) . str_replace( '/', DIRECTORY_SEPARATOR, $relative );
		}

		return false;
	}

	private function archive_next_entry_at_offset( $archive_path, $offset ) {
		$extractor = new CMSVC_Extractor( $archive_path );
		try {
			return $extractor->entry_at_offset( $offset );
		} finally {
			$extractor->close();
		}
	}

	private function import_database_sql_batch_with_mysql_client( array $job, $path, array $source_context, $skip_email_domains, array $state ) {
		$batch = $this->read_sql_import_batch(
			$path,
			(int) ( $state['offset'] ?? 0 ),
			(string) ( $state['query_buffer'] ?? '' ),
			$source_context,
			$skip_email_domains,
			CMSVC_IMPORT_SQL_CHUNK_BYTES
		);

		$chunk_path = $this->work_dir( $job['id'] ) . '/db-import-chunk.sql';
		$contents   = '';

		if ( empty( $state['started'] ) ) {
			$contents .= "SET FOREIGN_KEY_CHECKS=0;\nSET UNIQUE_CHECKS=0;\n";
		}

		if ( ! empty( $batch['queries'] ) ) {
			$contents .= implode( "\n", $batch['queries'] ) . "\n";
		}

		if ( ! empty( $batch['complete'] ) ) {
			$contents .= "SET FOREIGN_KEY_CHECKS=1;\nSET UNIQUE_CHECKS=1;\n";
		}

		if ( '' !== $contents ) {
			file_put_contents( $chunk_path, $contents );
			$this->import_sql_file_with_mysql_client( $chunk_path, $job['id'] );
		}

		$state['started']        = true;
		$state['offset']         = (int) $batch['offset'];
		$state['query_buffer']   = (string) $batch['query_buffer'];
		$state['bytes_imported'] = (int) $batch['offset'];
		$state['file_size']      = (int) $batch['file_size'];

		return array(
			'state'    => $state,
			'complete' => ! empty( $batch['complete'] ),
		);
	}

	private function import_database_sql_batch_with_php( array $job, $path, array $source_context, $skip_email_domains, array $state ) {
		global $wpdb;

		$this->assert_job_not_cancelled( $job );

		$batch = $this->read_sql_import_batch(
			$path,
			(int) ( $state['offset'] ?? 0 ),
			(string) ( $state['query_buffer'] ?? '' ),
			$source_context,
			$skip_email_domains,
			CMSVC_IMPORT_SQL_CHUNK_BYTES
		);

		if ( empty( $state['started'] ) ) {
			$wpdb->query( 'SET FOREIGN_KEY_CHECKS=0' );
			$wpdb->query( 'SET UNIQUE_CHECKS=0' );
		}

		foreach ( $batch['queries'] as $query ) {
			$this->assert_job_not_cancelled( $job );
			$wpdb->query( $query );
		}

		$state['started']        = true;
		$state['offset']         = (int) $batch['offset'];
		$state['query_buffer']   = (string) $batch['query_buffer'];
		$state['bytes_imported'] = (int) $batch['offset'];
		$state['file_size']      = (int) $batch['file_size'];

		if ( ! empty( $batch['complete'] ) ) {
			$wpdb->query( 'SET FOREIGN_KEY_CHECKS=1' );
			$wpdb->query( 'SET UNIQUE_CHECKS=1' );
		}

		return array(
			'state'    => $state,
			'complete' => ! empty( $batch['complete'] ),
		);
	}

	private function read_sql_import_batch( $path, $offset, $query_buffer, array $source_context, $skip_email_domains, $max_bytes, $rewrite_queries = true ) {
		$handle = fopen( $path, 'rb' );
		if ( ! $handle ) {
			throw new Exception( 'Unable to read database import.' );
		}

		$offset       = max( 0, (int) $offset );
		$query_buffer = (string) $query_buffer;
		$rewriter = null;
		if ( $rewrite_queries ) {
			$target_context = is_array( $source_context['__target_context'] ?? null ) ? $source_context['__target_context'] : array();
			$target_site    = (string) ( $target_context['site_url'] ?? site_url() );
			$target_home    = (string) ( $target_context['home_url'] ?? home_url() );
			$rewriter       = CMSVC_SQL_Rewriter::build( $source_context, $target_site, $target_home, $skip_email_domains, $target_context );
		}
		$queries      = array();
		$batch_bytes  = 0;
		$file_size    = max( 0, (int) filesize( $path ) );

		if ( $offset > 0 && -1 === fseek( $handle, $offset, SEEK_SET ) ) {
			fclose( $handle );
			throw new Exception( 'Unable to resume database import.' );
		}

		while ( false !== ( $line = fgets( $handle ) ) ) {
			$offset  = (int) ftell( $handle );
			$trimmed = trim( $line );
			if ( '' === $trimmed || 0 === strpos( $trimmed, '--' ) ) {
				continue;
			}

			$query_buffer .= $line;
			if ( ';' !== substr( rtrim( $line ), -1 ) ) {
				continue;
			}

			$query         = $rewriter ? $rewriter->rewrite_query( $query_buffer ) : $query_buffer;
			$queries[]     = $query;
			$batch_bytes  += strlen( $query );
			$query_buffer  = '';

			if ( $batch_bytes >= $max_bytes ) {
				break;
			}
		}

		if ( feof( $handle ) && '' !== trim( $query_buffer ) ) {
			$query         = $rewriter ? $rewriter->rewrite_query( $query_buffer ) : $query_buffer;
			$queries[]     = $query;
			$batch_bytes  += strlen( $query );
			$query_buffer  = '';
		}

		$complete = feof( $handle ) && '' === trim( $query_buffer );
		fclose( $handle );

		return array(
			'queries'      => $queries,
			'offset'       => $offset,
			'query_buffer' => $query_buffer,
			'complete'     => $complete,
			'file_size'    => $file_size,
		);
	}

	private function can_use_async_database_import_runner() {
		return $this->can_run_shell_commands()
			&& $this->shell_binary_exists( 'wp' )
			&& '' !== $this->database_client_binary()
			&& $this->shell_binary_exists( 'sh' );
	}

	private function launch_async_database_import_runner( $job_id ) {
		$pid = $this->run_detached_shell_command(
			$this->wp_cli_command(
				array(
					'cmsvc',
					'run_async_db_import',
					$job_id,
					'--allow-root',
				),
				true
			),
			ABSPATH
		);

		$jobs = $this->jobs();
		if ( ! isset( $jobs[ $job_id ] ) ) {
			return;
		}

		$job  = $jobs[ $job_id ];
		$state = is_array( $job['db_import_state'] ?? null ) ? $job['db_import_state'] : array();
		$state['runner_pid'] = $pid;
		$job['db_import_state'] = $state;
		$this->save_job( $job );
	}

	private function clear_destination_database_for_import( array $job ) {
		$this->assert_job_not_cancelled( $job );
		$job = $this->mark_job( $job, 'running', 'destination_db_import', 'Clearing destination database before import.' );
		$this->save_job( $job );

		$statements = array( 'SET FOREIGN_KEY_CHECKS=0;' );

		foreach ( $this->database_views() as $view ) {
			$statements[] = 'DROP VIEW IF EXISTS `' . str_replace( '`', '``', $view ) . '`;';
		}

		foreach ( $this->database_base_tables() as $table ) {
			$statements[] = 'DROP TABLE IF EXISTS `' . str_replace( '`', '``', $table ) . '`;';
		}

		$statements[] = 'SET FOREIGN_KEY_CHECKS=1;';
		$this->run_database_client_sql( implode( "\n", $statements ), $job['id'] );
	}

	private function import_database_sql_with_database_client_batches( array $job, $db_path ) {
		$state = is_array( $job['db_import_state'] ?? null ) ? $job['db_import_state'] : array();
		$state['offset']        = max( 0, (int) ( $state['offset'] ?? 0 ) );
		$state['query_buffer']  = (string) ( $state['query_buffer'] ?? '' );
		$state['bytes_imported'] = max( 0, (int) ( $state['bytes_imported'] ?? 0 ) );
		$state['file_size']     = max( 0, (int) ( $state['file_size'] ?? filesize( $db_path ) ) );
		$state['started']       = ! empty( $state['started'] );
		$chunk_path             = $this->work_dir( $job['id'] ) . '/db-import-cli-chunk.sql';

		do {
			$batch = $this->read_sql_import_batch(
				$db_path,
				(int) $state['offset'],
				(string) $state['query_buffer'],
				array(),
				false,
				CMSVC_IMPORT_SQL_CLI_BATCH_BYTES,
				false
			);

			$contents = '';
			$contents .= $this->database_client_import_session_preamble();

			if ( ! empty( $batch['queries'] ) ) {
				$contents .= implode( "\n", $batch['queries'] ) . "\n";
			}

			if ( ! empty( $batch['complete'] ) ) {
				$contents .= $this->database_client_import_session_epilogue();
			}

			if ( '' !== $contents ) {
				file_put_contents( $chunk_path, $contents );
				$this->import_sql_file_with_mysql_client( $chunk_path, $job['id'] );
			}

			$state['started']        = true;
			$state['offset']         = (int) $batch['offset'];
			$state['query_buffer']   = (string) $batch['query_buffer'];
			$state['bytes_imported'] = (int) $batch['offset'];
			$state['file_size']      = (int) $batch['file_size'];
			$state['runner_status']  = 'running';
			$job['db_import_state']  = $state;
			$job = $this->mark_job(
				$job,
				'running',
				'destination_db_import',
				$this->destination_database_progress_message( (int) $state['bytes_imported'], (int) $state['file_size'] )
			);
			$this->save_job( $job );
			$this->assert_job_not_cancelled( $job );
		} while ( empty( $batch['complete'] ) );

		return $job;
	}

	private function database_client_import_session_preamble() {
		return "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\nSET UNIQUE_CHECKS=0;\n";
	}

	private function database_client_import_session_epilogue() {
		return "SET FOREIGN_KEY_CHECKS=1;\nSET UNIQUE_CHECKS=1;\n";
	}

	private function normalize_destination_table_prefix( array $job, array $source_context ) {
		global $wpdb;

		$target_prefix = isset( $wpdb->prefix ) ? (string) $wpdb->prefix : 'wp_';
		$source_prefix = isset( $source_context['source_table_prefix'] ) ? (string) $source_context['source_table_prefix'] : '';

		if ( '' === $source_prefix || $source_prefix === $target_prefix ) {
			return $job;
		}

		$job = $this->mark_job(
			$job,
			'running',
			'destination_prefix_normalize',
			sprintf( 'Renaming imported database tables from %s to %s.', $source_prefix, $target_prefix )
		);
		$this->save_job( $job );

		$existing_tables = $this->database_base_tables();
		$tables = array_filter(
			$existing_tables,
			static function ( $table ) use ( $source_prefix ) {
				return 0 === strpos( $table, $source_prefix );
			}
		);

		if ( ! empty( $tables ) ) {
			$statements = array( 'SET FOREIGN_KEY_CHECKS=0;' );
			$existing_lookup = array_fill_keys( $existing_tables, true );

			foreach ( $tables as $table ) {
				$new_table = $target_prefix . substr( $table, strlen( $source_prefix ) );
				if ( isset( $existing_lookup[ $new_table ] ) ) {
					$statements[] = 'DROP TABLE IF EXISTS `' . str_replace( '`', '``', $new_table ) . '`;';
					unset( $existing_lookup[ $new_table ] );
				}
			}

			foreach ( $tables as $table ) {
				$new_table    = $target_prefix . substr( $table, strlen( $source_prefix ) );
				$statements[] = 'RENAME TABLE `' . str_replace( '`', '``', $table ) . '` TO `' . str_replace( '`', '``', $new_table ) . '`;';
			}
			$statements[] = 'SET FOREIGN_KEY_CHECKS=1;';
			$this->run_database_client_sql( implode( "\n", $statements ), $job['id'] );
		}

		if ( $source_prefix !== $target_prefix ) {
			$this->assert_job_not_cancelled( $job );
			$this->run_shell_command(
				$this->wp_cli_command(
					array(
						'search-replace',
						$source_prefix,
						$target_prefix,
						'--all-tables',
						'--report-changed-only',
						'--precise',
						'--allow-root',
					)
				),
				ABSPATH,
				$job['id']
			);
		}

		return $job;
	}

	private function run_destination_url_search_replace( array $job, array $source_context, $skip_email_domains ) {
		$job = $this->mark_job( $job, 'running', 'destination_search_replace', 'Running URL and path search replace on the destination database.' );
		$this->save_job( $job );

		$this->run_search_replace_commands(
			$source_context,
			$skip_email_domains,
			function ( $current, $total ) use ( &$job ) {
				$job = $this->mark_job(
					$job,
					'running',
					'destination_search_replace',
					sprintf( 'Running search replace %d of %d.', $current, $total )
				);
				$this->save_job( $job );
			},
			$job['id']
		);

		return $job;
	}

	private function import_database_sql_with_mysql_client( $path ) {
		$this->import_sql_file_with_mysql_client( $path );
	}

	private function import_database_sql( $path, array $source_context = array(), $skip_email_domains = false ) {
		$state = array(
			'offset'       => 0,
			'query_buffer' => '',
			'started'      => false,
		);

		do {
			$result = $this->import_database_sql_batch_with_php( $this->new_job( 'manual_import', 'destination_db_import' ), $path, $source_context, $skip_email_domains, $state );
			$state  = $result['state'];
		} while ( empty( $result['complete'] ) );
	}

	private function import_sql_file_with_mysql_client( $path, $job_id = '' ) {
		$this->assert_job_not_cancelled( $job_id );

		$defaults_file = $this->create_mysql_defaults_file();
		$parts         = $this->mysql_connection_parts();
		$binary        = $this->database_client_binary();
		if ( '' === $binary ) {
			@unlink( $defaults_file );
			throw new Exception( 'MariaDB/MySQL client is not available on the destination.' );
		}

		$command       = array(
			$binary,
			'--defaults-extra-file=' . $defaults_file,
			'--default-character-set=utf8mb4',
		);

		if ( ! empty( $parts['host'] ) ) {
			$command[] = '--host=' . $parts['host'];
		}
		if ( ! empty( $parts['port'] ) ) {
			$command[] = '--port=' . $parts['port'];
		}
		if ( ! empty( $parts['socket'] ) ) {
			$command[] = '--socket=' . $parts['socket'];
		}

		$command[] = DB_NAME;
		$command[] = '--execute=SOURCE ' . addcslashes( $path, '\\' ) . ';';

		try {
			$this->run_shell_command( $command, null, $job_id );
		} catch ( Exception $e ) {
			@unlink( $defaults_file );
			throw $e;
		}

		@unlink( $defaults_file );
	}

	private function r2_upload_progress_message( $uploaded_bytes, $total_bytes ) {
		$total_bytes = max( 1, (int) $total_bytes );
		$percent     = min( 100, round( ( max( 0, (int) $uploaded_bytes ) / $total_bytes ) * 100, 2 ) );

		return sprintf(
			'Uploading archive to R2: %s%% (%s / %s MB).',
			number_format_i18n( $percent, 2 ),
			number_format_i18n( max( 0, (int) $uploaded_bytes ) / 1048576, 2 ),
			number_format_i18n( $total_bytes / 1048576, 2 )
		);
	}

	private function destination_download_progress_message( $downloaded_bytes, $total_bytes ) {
		$total_bytes = max( 1, (int) $total_bytes );
		$percent     = min( 100, round( ( max( 0, (int) $downloaded_bytes ) / $total_bytes ) * 100, 2 ) );

		return sprintf(
			'Downloading archive from R2: %s%% (%s / %s MB).',
			number_format_i18n( $percent, 2 ),
			number_format_i18n( max( 0, (int) $downloaded_bytes ) / 1048576, 2 ),
			number_format_i18n( $total_bytes / 1048576, 2 )
		);
	}

	private function destination_extract_progress_message( $extracted_files ) {
		return sprintf(
			'Extracting archive contents: %d files restored.',
			max( 0, (int) $extracted_files )
		);
	}

	private function destination_database_progress_message( $imported_bytes, $total_bytes ) {
		$total_bytes = max( 1, (int) $total_bytes );
		$percent     = min( 100, round( ( max( 0, (int) $imported_bytes ) / $total_bytes ) * 100, 2 ) );

		return sprintf(
			'Importing database: %s%% (%s / %s MB).',
			number_format_i18n( $percent, 2 ),
			number_format_i18n( max( 0, (int) $imported_bytes ) / 1048576, 2 ),
			number_format_i18n( $total_bytes / 1048576, 2 )
		);
	}

	private function destination_database_expand_progress_message( $expanded_bytes, $compressed_bytes ) {
		return sprintf(
			'Expanding compressed database export: %s MB restored from %s MB gzip.',
			number_format_i18n( max( 0, (int) $expanded_bytes ) / 1048576, 2 ),
			number_format_i18n( max( 0, (int) $compressed_bytes ) / 1048576, 2 )
		);
	}

	private function destination_attachment_regenerate_progress_message( $processed, $total, $updated, $recovered_paths ) {
		return sprintf(
			'Repairing media records: %d of %d candidates processed, %d regenerated, %d paths repaired.',
			max( 0, (int) $processed ),
			max( 0, (int) $total ),
			max( 0, (int) $updated ),
			max( 0, (int) $recovered_paths )
		);
	}

	private function run_search_replace_commands( array $source_context, $skip_email_domains, callable $progress_callback = null, $job_id = '' ) {
		$pairs = $this->search_replace_pairs( $source_context, $skip_email_domains );
		if ( empty( $pairs ) ) {
			return;
		}

		$total   = count( $pairs );
		$current = 0;

		foreach ( $pairs as $pair ) {
			if ( '' !== $job_id ) {
				$this->assert_job_not_cancelled( $job_id );
			}

			$current++;
			if ( $progress_callback ) {
				$progress_callback( $current, $total, $pair );
			}

			$command = $this->wp_cli_command(
				array(
					'search-replace',
					$pair['from'],
					$pair['to'],
					'--all-tables',
					'--report-changed-only',
					'--precise',
					'--allow-root',
				)
			);

			$this->run_shell_command( $command, ABSPATH, $job_id );
		}
	}

	private function search_replace_pairs( array $source_context, $skip_email_domains ) {
		$uploads = wp_get_upload_dir();
		$pairs   = array();

		$this->append_search_replace_pair( $pairs, $source_context['source_site_url'] ?? $source_context['source_url'] ?? '', site_url() );
		$this->append_search_replace_pair( $pairs, $source_context['source_home_url'] ?? $source_context['source_url'] ?? '', home_url() );
		$this->append_search_replace_pair( $pairs, $source_context['source_abspath'] ?? '', ABSPATH );
		$this->append_search_replace_pair( $pairs, $source_context['source_content_dir'] ?? '', WP_CONTENT_DIR );
		$this->append_search_replace_pair( $pairs, $source_context['source_uploads_dir'] ?? '', $uploads['basedir'] ?? '' );
		$this->append_search_replace_pair( $pairs, $source_context['source_uploads_url'] ?? '', $uploads['baseurl'] ?? '' );

		if ( ! $skip_email_domains ) {
			$old_host = wp_parse_url( $source_context['source_home_url'] ?? $source_context['source_url'] ?? '', PHP_URL_HOST );
			$new_host = wp_parse_url( home_url(), PHP_URL_HOST );
			if ( $old_host && $new_host ) {
				$this->append_search_replace_pair( $pairs, '@' . $old_host, '@' . str_ireplace( 'www.', '', $new_host ) );
			}
		}

		return $pairs;
	}

	private function append_search_replace_pair( array &$pairs, $from, $to ) {
		$from = (string) $from;
		$to   = (string) $to;

		if ( '' === $from || $from === $to ) {
			return;
		}

		$key = $from . "\n" . $to;
		if ( isset( $pairs[ $key ] ) ) {
			return;
		}

		$pairs[ $key ] = array(
			'from' => $from,
			'to'   => $to,
		);
	}

	private function escape_sql_export_value( $value ) {
		global $wpdb;

		$value = $wpdb->_real_escape( $value );
		if ( method_exists( $wpdb, 'remove_placeholder_escape' ) ) {
			$value = $wpdb->remove_placeholder_escape( $value );
		}

		return $value;
	}

	private function destination_attachment_regeneration_candidate_count() {
		global $wpdb;

		return max(
			0,
			(int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(DISTINCT p.ID)
					FROM {$wpdb->posts} p
					LEFT JOIN {$wpdb->postmeta} attached_file
						ON attached_file.post_id = p.ID
						AND attached_file.meta_key = %s
					LEFT JOIN {$wpdb->postmeta} attachment_meta
						ON attachment_meta.post_id = p.ID
						AND attachment_meta.meta_key = %s
					WHERE p.post_type = %s
						AND (
							attached_file.meta_id IS NULL
							OR attached_file.meta_value = ''
							OR attachment_meta.meta_id IS NULL
							OR attachment_meta.meta_value = ''
						)",
					'_wp_attached_file',
					'_wp_attachment_metadata',
					'attachment'
				)
			)
		);
	}

	private function next_attachment_regeneration_candidate_batch( $after_id, $limit ) {
		global $wpdb;

		$rows = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT p.ID
				FROM {$wpdb->posts} p
				LEFT JOIN {$wpdb->postmeta} attached_file
					ON attached_file.post_id = p.ID
					AND attached_file.meta_key = %s
				LEFT JOIN {$wpdb->postmeta} attachment_meta
					ON attachment_meta.post_id = p.ID
					AND attachment_meta.meta_key = %s
				WHERE p.post_type = %s
					AND p.ID > %d
					AND (
						attached_file.meta_id IS NULL
						OR attached_file.meta_value = ''
						OR attachment_meta.meta_id IS NULL
						OR attachment_meta.meta_value = ''
					)
				ORDER BY p.ID ASC
				LIMIT %d",
				'_wp_attached_file',
				'_wp_attachment_metadata',
				'attachment',
				max( 0, (int) $after_id ),
				max( 1, (int) $limit )
			)
		);

		return array_map( 'intval', array_values( array_filter( (array) $rows, 'is_numeric' ) ) );
	}

	private function repair_attachment_metadata( $attachment_id ) {
		$file = $this->resolve_attachment_file_for_regeneration( $attachment_id, $recovered_path );
		if ( '' === $file || ! file_exists( $file ) ) {
			return array(
				'updated'        => false,
				'recovered_path' => ! empty( $recovered_path ),
				'missing_file'   => true,
			);
		}

		if ( ! $this->attachment_metadata_needs_regeneration( $attachment_id, $file, ! empty( $recovered_path ) ) ) {
			return array(
				'updated'        => false,
				'recovered_path' => ! empty( $recovered_path ),
				'missing_file'   => false,
			);
		}

		if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}

		$metadata = wp_generate_attachment_metadata( $attachment_id, $file );
		if ( is_wp_error( $metadata ) || ! is_array( $metadata ) || empty( $metadata ) ) {
			return array(
				'updated'        => false,
				'recovered_path' => ! empty( $recovered_path ),
				'missing_file'   => false,
			);
		}

		wp_update_attachment_metadata( $attachment_id, $metadata );

		return array(
			'updated'        => true,
			'recovered_path' => ! empty( $recovered_path ),
			'missing_file'   => false,
		);
	}

	private function attachment_metadata_needs_regeneration( $attachment_id, $file, $recovered_path ) {
		if ( ! wp_attachment_is_image( $attachment_id ) ) {
			return false;
		}

		if ( $recovered_path ) {
			return true;
		}

		$metadata = wp_get_attachment_metadata( $attachment_id );
		if ( ! is_array( $metadata ) || empty( $metadata ) ) {
			return true;
		}

		$metadata_file = isset( $metadata['file'] ) ? wp_normalize_path( (string) $metadata['file'] ) : '';
		if ( '' === $metadata_file ) {
			return true;
		}

		$expected_relative = $this->relative_attachment_file_path_from_absolute( $file );
		if ( '' !== $expected_relative && $metadata_file !== wp_normalize_path( $expected_relative ) ) {
			return true;
		}

		return empty( $metadata['width'] ) || empty( $metadata['height'] );
	}

	private function resolve_attachment_file_for_regeneration( $attachment_id, &$recovered_path = false ) {
		$recovered_path = false;

		$attached_file = get_attached_file( $attachment_id, true );
		if ( is_string( $attached_file ) && '' !== $attached_file && file_exists( $attached_file ) ) {
			return $attached_file;
		}

		$relative = (string) get_post_meta( $attachment_id, '_wp_attached_file', true );
		if ( '' !== $relative ) {
			$candidate = $this->absolute_attachment_file_path( $relative );
			if ( '' !== $candidate && file_exists( $candidate ) ) {
				return $candidate;
			}
		}

		$relative = $this->recover_attachment_relative_path_from_guid( $attachment_id );
		if ( '' === $relative ) {
			return '';
		}

		$candidate = $this->absolute_attachment_file_path( $relative );
		if ( '' === $candidate || ! file_exists( $candidate ) ) {
			return '';
		}

		update_post_meta( $attachment_id, '_wp_attached_file', $relative );
		$recovered_path = true;
		return $candidate;
	}

	private function recover_attachment_relative_path_from_guid( $attachment_id ) {
		$guid    = (string) get_post_field( 'guid', $attachment_id );
		$uploads = wp_get_upload_dir();
		$baseurl = (string) ( $uploads['baseurl'] ?? '' );

		if ( '' === $guid || '' === $baseurl ) {
			return '';
		}

		$guid_path = wp_parse_url( $guid, PHP_URL_PATH );
		$base_path = wp_parse_url( $baseurl, PHP_URL_PATH );
		if ( ! is_string( $guid_path ) || ! is_string( $base_path ) ) {
			return '';
		}

		$base_path = untrailingslashit( $base_path );
		if ( '' === $base_path || 0 !== strpos( $guid_path, $base_path . '/' ) ) {
			return '';
		}

		return ltrim( str_replace( '\\', '/', rawurldecode( substr( $guid_path, strlen( $base_path ) + 1 ) ) ), '/' );
	}

	private function absolute_attachment_file_path( $relative_path ) {
		$relative_path = trim( (string) $relative_path );
		if ( '' === $relative_path ) {
			return '';
		}

		if ( preg_match( '#^[A-Za-z]:[\\\\/]#', $relative_path ) || 0 === strpos( $relative_path, '/' ) ) {
			return $relative_path;
		}

		$uploads = wp_get_upload_dir();
		$basedir = (string) ( $uploads['basedir'] ?? '' );
		if ( '' === $basedir ) {
			return '';
		}

		return trailingslashit( $basedir ) . ltrim( str_replace( array( '\\', '/' ), DIRECTORY_SEPARATOR, $relative_path ), DIRECTORY_SEPARATOR );
	}

	private function relative_attachment_file_path_from_absolute( $absolute_path ) {
		$absolute_path = wp_normalize_path( (string) $absolute_path );
		if ( '' === $absolute_path ) {
			return '';
		}

		$uploads = wp_get_upload_dir();
		$basedir = wp_normalize_path( (string) ( $uploads['basedir'] ?? '' ) );
		if ( '' === $basedir ) {
			return '';
		}

		$prefix = trailingslashit( $basedir );
		if ( 0 !== strpos( $absolute_path, $prefix ) ) {
			return '';
		}

		return ltrim( substr( $absolute_path, strlen( $prefix ) ), '/' );
	}

	private function finalize_import_state() {
		global $wp_rewrite;

		wp_cache_flush();

		delete_post_meta_by_key( '_elementor_css' );
		delete_post_meta_by_key( '_elementor_element_cache' );
		delete_post_meta_by_key( '_elementor_page_assets' );

		delete_option( '_elementor_global_css' );
		delete_option( '_elementor_assets_data' );
		delete_option( 'elementor-custom-breakpoints-files' );
		delete_option( 'rewrite_rules' );

		if ( $wp_rewrite instanceof WP_Rewrite ) {
			$wp_rewrite->init();
			$wp_rewrite->set_permalink_structure( (string) get_option( 'permalink_structure', '' ) );
			$wp_rewrite->flush_rules( false );
		} else {
			flush_rewrite_rules( false );
		}
	}

	private function run_post_import_actions( array $source_context ) {
		/**
		 * Fires after the destination import is complete and the destination wp-config
		 * overrides have been applied.
		 *
		 * This is the extension point for site-specific post-migration tasks such as
		 * regenerating builder signatures or clearing plugin caches.
		 */
		do_action( 'cmsvc_after_import', $source_context );
	}

	private function apply_destination_wp_config_overrides( array $source_context, $job_id = '' ) {
		$this->assert_job_not_cancelled( $job_id );

		$defines = $source_context['source_wp_config_defines'] ?? array();
		if ( ! is_array( $defines ) || empty( $defines ) ) {
			return;
		}

		$wp_config_path = $this->locate_wp_config_path();
		if ( '' === $wp_config_path || ! file_exists( $wp_config_path ) || ! is_readable( $wp_config_path ) || ! is_writable( $wp_config_path ) ) {
			return;
		}

		$contents = file_get_contents( $wp_config_path );
		if ( false === $contents ) {
			return;
		}

		$updated = false;
		foreach ( array( 'WP_CONTENT_DIR', 'WP_CONTENT_URL', 'UPLOADS' ) as $name ) {
			if ( empty( $defines[ $name ] ) || ! is_string( $defines[ $name ] ) ) {
				continue;
			}

			$contents = $this->upsert_wp_config_define( $contents, $name, $defines[ $name ], $updated );
		}

		if ( ! $updated ) {
			return;
		}

		file_put_contents( $wp_config_path, $contents );
		$this->refresh_destination_paths_after_wp_config_update( $job_id );
	}

	private function refresh_destination_paths_after_wp_config_update( $job_id = '' ) {
		$this->assert_job_not_cancelled( $job_id );

		if ( ! $this->can_run_shell_commands() || ! $this->shell_binary_exists( 'wp' ) ) {
			return;
		}

		$current_uploads = wp_get_upload_dir();
		$current         = array(
			'content_dir'  => WP_CONTENT_DIR,
			'content_url'  => defined( 'WP_CONTENT_URL' ) ? WP_CONTENT_URL : '',
			'uploads_dir'  => $current_uploads['basedir'] ?? '',
			'uploads_url'  => $current_uploads['baseurl'] ?? '',
		);
		$fresh           = $this->destination_runtime_context_from_wp_cli();

		if ( empty( $fresh ) ) {
			return;
		}

		$pairs = array();
		$this->append_search_replace_pair( $pairs, $current['content_dir'], $fresh['content_dir'] ?? '' );
		$this->append_search_replace_pair( $pairs, $current['content_url'], $fresh['content_url'] ?? '' );
		$this->append_search_replace_pair( $pairs, $current['uploads_dir'], $fresh['uploads_dir'] ?? '' );
		$this->append_search_replace_pair( $pairs, $current['uploads_url'], $fresh['uploads_url'] ?? '' );

		if ( empty( $pairs ) ) {
			return;
		}

		foreach ( $pairs as $pair ) {
			$this->assert_job_not_cancelled( $job_id );
			$command = $this->wp_cli_command(
				array(
					'search-replace',
					$pair['from'],
					$pair['to'],
					'--all-tables',
					'--report-changed-only',
					'--precise',
					'--allow-root',
				)
			);

			$this->run_shell_command( $command, ABSPATH, $job_id );
		}
	}

	private function destination_runtime_context_from_wp_cli() {
		$json = $this->run_shell_command(
			$this->wp_cli_command(
				array(
					'eval',
					'echo wp_json_encode(array('
					. '\'content_dir\' => WP_CONTENT_DIR,'
					. '\'content_url\' => defined(\'WP_CONTENT_URL\') ? WP_CONTENT_URL : \'\','
					. '\'uploads_dir\' => wp_get_upload_dir()[\'basedir\'] ?? \'\','
					. '\'uploads_url\' => wp_get_upload_dir()[\'baseurl\'] ?? \'\','
					. '));',
					'--allow-root',
				)
			),
			ABSPATH
		);

		$data = json_decode( (string) $json, true );
		return is_array( $data ) ? $data : array();
	}

	private function wp_cli_command( array $args, $keep_current_plugin_loaded = false ) {
		$command = array( 'wp' );

		if ( $keep_current_plugin_loaded ) {
			$skip_plugins = $this->wp_cli_skip_plugins_except_current();
			if ( '' !== $skip_plugins ) {
				$command[] = '--skip-plugins=' . $skip_plugins;
			}
		} else {
			$command[] = '--skip-plugins';
		}

		$command[] = '--skip-themes';

		return array_merge( $command, $args );
	}

	private function wp_cli_skip_plugins_except_current() {
		if ( ! defined( 'WP_PLUGIN_DIR' ) || ! is_dir( WP_PLUGIN_DIR ) ) {
			return '';
		}

		$current_plugin_dir = basename( dirname( __FILE__ ) );
		$entries            = @scandir( WP_PLUGIN_DIR );
		if ( false === $entries ) {
			return '';
		}

		$skip = array();
		foreach ( $entries as $entry ) {
			if ( '.' === $entry || '..' === $entry || $current_plugin_dir === $entry ) {
				continue;
			}

			$full_path = WP_PLUGIN_DIR . '/' . $entry;
			if ( is_dir( $full_path ) || preg_match( '/\.php$/i', $entry ) ) {
				$skip[] = $entry;
			}
		}

		sort( $skip, SORT_STRING );
		return implode( ',', $skip );
	}

	private function supported_wp_config_defines() {
		$wp_config_path = $this->locate_wp_config_path();
		if ( '' === $wp_config_path || ! file_exists( $wp_config_path ) || ! is_readable( $wp_config_path ) ) {
			return array();
		}

		$contents = file_get_contents( $wp_config_path );
		if ( false === $contents ) {
			return array();
		}

		return $this->extract_wp_config_defines( $contents, array( 'WP_CONTENT_DIR', 'WP_CONTENT_URL', 'UPLOADS' ) );
	}

	private function locate_wp_config_path() {
		$candidates = array(
			trailingslashit( ABSPATH ) . 'wp-config.php',
			dirname( untrailingslashit( ABSPATH ) ) . '/wp-config.php',
		);

		foreach ( $candidates as $candidate ) {
			if ( file_exists( $candidate ) ) {
				return wp_normalize_path( $candidate );
			}
		}

		return '';
	}

	private function extract_wp_config_defines( $contents, array $names ) {
		$wanted  = array_fill_keys( $names, true );
		$results = array();
		$tokens  = token_get_all( $contents );
		$count   = count( $tokens );

		for ( $index = 0; $index < $count; $index++ ) {
			$token = $tokens[ $index ];
			if ( ! is_array( $token ) || T_STRING !== $token[0] || 'define' !== strtolower( $token[1] ) ) {
				continue;
			}

			$index = $this->skip_non_code_tokens( $tokens, $index + 1, $count );
			if ( $index >= $count || '(' !== $this->token_text( $tokens[ $index ] ) ) {
				continue;
			}

			$index = $this->skip_non_code_tokens( $tokens, $index + 1, $count );
			if ( $index >= $count || ! is_array( $tokens[ $index ] ) || T_CONSTANT_ENCAPSED_STRING !== $tokens[ $index ][0] ) {
				continue;
			}

			$name = trim( $tokens[ $index ][1], '\'"' );
			if ( ! isset( $wanted[ $name ] ) || isset( $results[ $name ] ) ) {
				continue;
			}

			$index = $this->skip_non_code_tokens( $tokens, $index + 1, $count );
			if ( $index >= $count || ',' !== $this->token_text( $tokens[ $index ] ) ) {
				continue;
			}

			$expression = '';
			$depth      = 0;
			for ( $index = $index + 1; $index < $count; $index++ ) {
				$text = $this->token_text( $tokens[ $index ] );

				if ( '(' === $text ) {
					$depth++;
				} elseif ( ')' === $text ) {
					if ( 0 === $depth ) {
						break;
					}
					$depth--;
				}

				$expression .= $text;
			}

			$expression = trim( $expression );
			if ( '' !== $expression ) {
				$results[ $name ] = $expression;
			}
		}

		return $results;
	}

	private function skip_non_code_tokens( array $tokens, $index, $count ) {
		while ( $index < $count ) {
			$token = $tokens[ $index ];
			if ( is_array( $token ) && in_array( $token[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) {
				$index++;
				continue;
			}

			break;
		}

		return $index;
	}

	private function token_text( $token ) {
		return is_array( $token ) ? $token[1] : $token;
	}

	private function upsert_wp_config_define( $contents, $name, $expression, &$updated ) {
		$define_line = "define( '" . $name . "', " . trim( $expression ) . ' );';
		$pattern     = '/^[ \t]*define\s*\(\s*([\'"])' . preg_quote( $name, '/' ) . '\1\s*,.*?\)\s*;\s*$/mi';

		if ( preg_match( $pattern, $contents ) ) {
			$replaced = preg_replace( $pattern, $define_line, $contents, 1 );
			if ( is_string( $replaced ) && $replaced !== $contents ) {
				$updated  = true;
				$contents = $replaced;
			}

			return $contents;
		}

		$markers = array(
			"/* That's all, stop editing! Happy publishing. */",
			"require_once ABSPATH . 'wp-settings.php';",
			'require_once ABSPATH . "wp-settings.php";',
		);

		foreach ( $markers as $marker ) {
			$position = strpos( $contents, $marker );
			if ( false === $position ) {
				continue;
			}

			$updated = true;
			return substr( $contents, 0, $position ) . $define_line . "\n" . substr( $contents, $position );
		}

		$updated = true;
		return rtrim( $contents ) . "\n" . $define_line . "\n";
	}

	private function download_destination_archive( array $job ) {
		$path = $this->work_dir( $job['id'] ) . '/' . sanitize_file_name( basename( $job['r2_key'] ) );
		wp_mkdir_p( dirname( $path ) );
		$this->r2_get_file( $job['r2'], $job['r2_key'], $path );
		return $path;
	}

	private function r2_put_file( array $settings, $key, $path ) {
		$upload_id  = $this->r2_create_multipart_upload( $settings, $key );
		$file_size  = max( 0, (int) filesize( $path ) );
		$offset     = 0;
		$part       = 1;
		$parts      = array();

		while ( $offset < $file_size ) {
			$part_size = min( CMSVC_R2_MULTIPART_PART_BYTES, $file_size - $offset );
			$parts[]   = array(
				'part_number' => $part,
				'etag'        => $this->r2_upload_part( $settings, $key, $upload_id, $part, $path, $offset, $part_size ),
			);
			$offset += $part_size;
			$part++;
		}

		$this->r2_complete_multipart_upload( $settings, $key, $upload_id, $parts );
	}

	private function r2_get_file( array $settings, $key, $path ) {
		$remote = $this->r2_head_object( $settings, $key );
		$size   = max( 0, (int) ( $remote['content_length'] ?? 0 ) );
		$offset = 0;
		$this->truncate_file_to_offset( $path, 0 );

		while ( $offset < $size ) {
			$chunk_size = min( CMSVC_R2_DOWNLOAD_CHUNK_BYTES, $size - $offset );
			$this->r2_download_part( $settings, $key, $path, $offset, $chunk_size );
			$offset += $chunk_size;
		}
	}

	private function r2_create_multipart_upload( array $settings, $key ) {
		$url      = $this->r2_url( $settings, $key, array( 'uploads' => '' ) );
		$headers  = $this->r2_signed_headers( $settings, 'POST', $url, 0 );
		$response = wp_remote_request(
			$url,
			array(
				'method'     => 'POST',
				'timeout'    => 300,
				'headers'    => $headers,
				'user-agent' => CMSVC_USER_AGENT,
			)
		);

		$this->assert_r2_response( $response, 'multipart upload init' );
		$body = (string) wp_remote_retrieve_body( $response );
		if ( ! preg_match( '/<UploadId>([^<]+)<\/UploadId>/', $body, $matches ) ) {
			throw new Exception( 'R2 multipart upload init failed: missing UploadId.' );
		}

		return html_entity_decode( $matches[1], ENT_QUOTES, 'UTF-8' );
	}

	private function r2_upload_part( array $settings, $key, $upload_id, $part_number, $path, $offset, $length ) {
		$body = file_get_contents( $path, false, null, $offset, $length );
		if ( false === $body ) {
			throw new Exception( 'Unable to read archive part for upload.' );
		}

		$url      = $this->r2_url(
			$settings,
			$key,
			array(
				'partNumber' => (string) (int) $part_number,
				'uploadId'   => (string) $upload_id,
			)
		);
		$headers  = $this->r2_signed_headers( $settings, 'PUT', $url, strlen( $body ) );
		$response = wp_remote_request(
			$url,
			array(
				'method'     => 'PUT',
				'timeout'    => 300,
				'headers'    => $headers,
				'user-agent' => CMSVC_USER_AGENT,
				'body'       => $body,
			)
		);

		$this->assert_r2_response( $response, 'multipart upload part' );
		$etag = trim( (string) wp_remote_retrieve_header( $response, 'etag' ), '"' );
		if ( '' === $etag ) {
			throw new Exception( 'R2 multipart upload part failed: missing ETag.' );
		}

		return $etag;
	}

	private function r2_complete_multipart_upload( array $settings, $key, $upload_id, array $parts ) {
		usort(
			$parts,
			static function ( $left, $right ) {
				return (int) ( $left['part_number'] ?? 0 ) <=> (int) ( $right['part_number'] ?? 0 );
			}
		);

		$xml = "<CompleteMultipartUpload>\n";
		foreach ( $parts as $part ) {
			$xml .= "<Part><PartNumber>" . (int) $part['part_number'] . "</PartNumber><ETag>" . htmlspecialchars( '"' . (string) $part['etag'] . '"', ENT_XML1 | ENT_QUOTES, 'UTF-8' ) . "</ETag></Part>\n";
		}
		$xml .= "</CompleteMultipartUpload>";

		$url      = $this->r2_url(
			$settings,
			$key,
			array(
				'uploadId' => (string) $upload_id,
			)
		);
		$headers  = $this->r2_signed_headers( $settings, 'POST', $url, strlen( $xml ), array( 'content-type' => 'application/xml' ) );
		$response = wp_remote_request(
			$url,
			array(
				'method'     => 'POST',
				'timeout'    => 300,
				'headers'    => $headers,
				'user-agent' => CMSVC_USER_AGENT,
				'body'       => $xml,
			)
		);

		$this->assert_r2_response( $response, 'multipart upload completion' );
	}

	private function r2_head_object( array $settings, $key ) {
		$url      = $this->r2_url( $settings, $key );
		$headers  = $this->r2_signed_headers( $settings, 'HEAD', $url, 0 );
		$response = wp_remote_request(
			$url,
			array(
				'method'     => 'HEAD',
				'timeout'    => 300,
				'headers'    => $headers,
				'user-agent' => CMSVC_USER_AGENT,
			)
		);

		$this->assert_r2_response( $response, 'head object' );

		return array(
			'content_length' => (int) wp_remote_retrieve_header( $response, 'content-length' ),
			'etag'           => (string) wp_remote_retrieve_header( $response, 'etag' ),
		);
	}

	private function r2_remote_object_matches_size( array $settings, $key, $expected_size ) {
		try {
			$remote_size = (int) ( $this->r2_head_object( $settings, $key )['content_length'] ?? -1 );
		} catch ( Exception $e ) {
			return false;
		}

		return $remote_size === max( 0, (int) $expected_size );
	}

	private function r2_download_part( array $settings, $key, $path, $offset, $length ) {
		$url     = $this->r2_url( $settings, $key );
		$headers = $this->r2_signed_headers(
			$settings,
			'GET',
			$url,
			0,
			array(
				'range' => 'bytes=' . (int) $offset . '-' . (int) ( $offset + $length - 1 ),
			)
		);

		$response = wp_remote_request(
			$url,
			array(
				'method'     => 'GET',
				'timeout'    => 300,
				'headers'    => $headers,
				'user-agent' => CMSVC_USER_AGENT,
			)
		);

		$this->assert_r2_response( $response, 'download part' );
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 206 !== $code ) {
			throw new Exception( 'R2 download failed: expected HTTP 206 for ranged download, got ' . $code . '.' );
		}
		$body = wp_remote_retrieve_body( $response );
		if ( '' === $body && $length > 0 ) {
			throw new Exception( 'R2 download failed: empty body.' );
		}

		$handle = fopen( $path, 'c+b' );
		if ( ! $handle ) {
			throw new Exception( 'Unable to open archive for download.' );
		}

		try {
			if ( -1 === fseek( $handle, max( 0, (int) $offset ), SEEK_SET ) ) {
				throw new Exception( 'Unable to seek destination archive offset.' );
			}

			$written = fwrite( $handle, $body );
			if ( false === $written || strlen( $body ) !== $written ) {
				throw new Exception( 'Unable to write downloaded archive chunk.' );
			}
		} finally {
			fclose( $handle );
		}
	}

	private function r2_url( array $settings, $key, array $query_args = array() ) {
		$account = $this->r2_value( $settings, 'account_id' );
		$bucket  = $this->r2_value( $settings, 'bucket' );
		if ( '' === $account || '' === $bucket ) {
			throw new Exception( 'Missing R2 account ID or bucket.' );
		}

		$url = 'https://' . rawurlencode( $account ) . '.r2.cloudflarestorage.com/' . rawurlencode( $bucket ) . '/' . str_replace( '%2F', '/', rawurlencode( $key ) );
		if ( empty( $query_args ) ) {
			return $url;
		}

		$query = array();
		foreach ( $query_args as $query_key => $query_value ) {
			$query[] = rawurlencode( (string) $query_key ) . '=' . rawurlencode( (string) $query_value );
		}

		return $url . '?' . implode( '&', $query );
	}

	private function r2_signed_headers( array $settings, $method, $url, $content_length, array $extra_headers = array() ) {
		$parsed       = wp_parse_url( $url );
		$host         = $parsed['host'];
		$path         = $parsed['path'];
		$query        = $parsed['query'] ?? '';
		$date         = gmdate( 'Ymd\THis\Z' );
		$short_date   = gmdate( 'Ymd' );
		$payload_hash = 'UNSIGNED-PAYLOAD';
		$region       = 'auto';
		$service      = 's3';
		$scope        = "{$short_date}/{$region}/{$service}/aws4_request";
		$access_key   = $this->r2_value( $settings, 'access_key' );
		$secret_key   = $this->r2_value( $settings, 'secret_key' );

		if ( '' === $access_key || '' === $secret_key ) {
			throw new Exception( 'Missing R2 access key or secret key.' );
		}

		$headers = array(
			'host'                 => $host,
			'x-amz-content-sha256' => $payload_hash,
			'x-amz-date'           => $date,
		);
		foreach ( $extra_headers as $name => $value ) {
			$headers[ strtolower( $name ) ] = (string) $value;
		}
		if ( $content_length > 0 ) {
			$headers['content-length'] = (string) $content_length;
		}

		ksort( $headers );
		$canonical_headers = '';
		foreach ( $headers as $name => $value ) {
			$canonical_headers .= strtolower( $name ) . ':' . trim( $value ) . "\n";
		}

		$signed_headers = implode( ';', array_keys( $headers ) );
		$canonical      = strtoupper( $method ) . "\n" . $path . "\n" . $this->r2_canonical_query_string( $query ) . "\n" . $canonical_headers . "\n" . $signed_headers . "\n" . $payload_hash;
		$string_to_sign = "AWS4-HMAC-SHA256\n{$date}\n{$scope}\n" . hash( 'sha256', $canonical );
		$signing_key    = $this->aws_signing_key( $secret_key, $short_date, $region, $service );
		$signature      = hash_hmac( 'sha256', $string_to_sign, $signing_key );

		$headers['Authorization'] = 'AWS4-HMAC-SHA256 Credential=' . $access_key . '/' . $scope . ', SignedHeaders=' . $signed_headers . ', Signature=' . $signature;
		unset( $headers['host'] );

		return $headers;
	}

	private function r2_canonical_query_string( $query ) {
		$query = (string) $query;
		if ( '' === $query ) {
			return '';
		}

		$pairs = array();
		foreach ( explode( '&', $query ) as $part ) {
			if ( '' === $part ) {
				continue;
			}

			$segments = explode( '=', $part, 2 );
			$key      = rawurldecode( $segments[0] );
			$value    = isset( $segments[1] ) ? rawurldecode( $segments[1] ) : '';
			$pairs[]  = array(
				'key'   => rawurlencode( $key ),
				'value' => rawurlencode( $value ),
			);
		}

		usort(
			$pairs,
			static function ( $left, $right ) {
				$key_compare = strcmp( $left['key'], $right['key'] );
				if ( 0 !== $key_compare ) {
					return $key_compare;
				}

				return strcmp( $left['value'], $right['value'] );
			}
		);

		$normalized = array();
		foreach ( $pairs as $pair ) {
			$normalized[] = $pair['key'] . '=' . $pair['value'];
		}

		return implode( '&', $normalized );
	}

	private function r2_value( array $settings, $name ) {
		$source_key = 'r2_' . $name;
		if ( isset( $settings[ $source_key ] ) && '' !== $settings[ $source_key ] ) {
			return trim( (string) $settings[ $source_key ] );
		}

		if ( isset( $settings[ $name ] ) && '' !== $settings[ $name ] ) {
			return trim( (string) $settings[ $name ] );
		}

		return '';
	}

	private function aws_signing_key( $secret, $date, $region, $service ) {
		$key = hash_hmac( 'sha256', $date, 'AWS4' . $secret, true );
		$key = hash_hmac( 'sha256', $region, $key, true );
		$key = hash_hmac( 'sha256', $service, $key, true );
		return hash_hmac( 'sha256', 'aws4_request', $key, true );
	}

	private function assert_r2_response( $response, $action ) {
		if ( is_wp_error( $response ) ) {
			throw new Exception( 'R2 ' . $action . ' failed: ' . $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			throw new Exception( 'R2 ' . $action . ' failed: HTTP ' . $code . ' ' . wp_remote_retrieve_body( $response ) );
		}
	}

	private function r2_error_code_from_exception( Exception $exception ) {
		$message = $exception->getMessage();
		if ( preg_match( '/<Code>([^<]+)<\/Code>/', $message, $matches ) ) {
			return (string) $matches[1];
		}

		return '';
	}

	private function add_directory_to_archive( CMSVC_Compressor $archive, $source, $target, array $excluded_roots ) {
		$source               = wp_normalize_path( $source );
		$excluded_roots       = array_map( 'wp_normalize_path', $excluded_roots );
		$excluded_root_globs  = $this->settings_excluded_paths();
		$excluded_extensions  = $this->settings_excluded_extensions();
		$directory_iterator   = new RecursiveDirectoryIterator(
			$source,
			FilesystemIterator::SKIP_DOTS | FilesystemIterator::CURRENT_AS_FILEINFO | FilesystemIterator::KEY_AS_PATHNAME
		);
		$filter = new RecursiveCallbackFilterIterator(
			$directory_iterator,
			function ( $current ) use ( $source, $excluded_roots, $excluded_root_globs, $excluded_extensions ) {
				$path = wp_normalize_path( $current->getPathname() );

				if ( 'wp-config.php' === basename( $path ) ) {
					return false;
				}

				foreach ( $excluded_roots as $excluded ) {
					if ( 0 === strpos( $path, $excluded ) ) {
						return false;
					}
				}

				$relative = ltrim( str_replace( $source, '', $path ), '/' );
				if ( '' !== $relative && $this->path_should_be_skipped_for_migration( $relative, $excluded_root_globs, $excluded_extensions ) ) {
					return false;
				}

				// Skip unreadable directories and files instead of aborting the whole export.
				if ( ! $current->isReadable() ) {
					return false;
				}

				return true;
			}
		);
		$files = new RecursiveIteratorIterator(
			$filter,
			RecursiveIteratorIterator::SELF_FIRST,
			RecursiveIteratorIterator::CATCH_GET_CHILD
		);

		foreach ( $files as $file ) {
			$path = wp_normalize_path( $file->getPathname() );

			if ( 'wp-config.php' === basename( $path ) ) {
				continue;
			}

			foreach ( $excluded_roots as $excluded ) {
				if ( 0 === strpos( $path, $excluded ) ) {
					continue 2;
				}
			}

			$relative = ltrim( str_replace( $source, '', $path ), '/' );
			if ( '' === $relative ) {
				continue;
			}

			if ( $this->path_should_be_skipped_for_migration( $relative, $excluded_root_globs, $excluded_extensions ) ) {
				continue;
			}

			if ( ! $file->isDir() ) {
				$archive->add_file( $path, trailingslashit( $target ) . $relative );
			}
		}
	}

	private function path_should_be_skipped_for_migration( $relative, array $excluded_paths, array $excluded_extensions ) {
		$normalized = trim( wp_normalize_path( $relative ), '/' );
		if ( '' === $normalized ) {
			return false;
		}

		return $this->path_is_protected_for_migration( $normalized ) || $this->path_matches_exclusions( $normalized, $excluded_paths, $excluded_extensions );
	}

	private function path_is_protected_for_migration( $relative ) {
		$normalized = trim( wp_normalize_path( $relative ), '/' );
		if ( '' === $normalized ) {
			return false;
		}

		$basename = strtolower( basename( $normalized ) );
		if ( 'wp-config.php' === $basename || '.user.ini' === $basename ) {
			return true;
		}

		if ( preg_match( '/^php(?:[0-9]+(?:\.[0-9]+)*)?\.ini$/i', $basename ) ) {
			return true;
		}

		return $this->path_matches_exclusions( $normalized, array( 'wp-content/object-cache.php' ), array() );
	}

	private function path_matches_exclusions( $relative, array $excluded_paths, array $excluded_extensions ) {
		$normalized = wp_normalize_path( $relative );

		foreach ( $excluded_paths as $pattern ) {
			$pattern = wp_normalize_path( $pattern );
			if ( '' === $pattern ) {
				continue;
			}

			if ( false !== strpos( $pattern, '*' ) ) {
				$regex = '#^' . str_replace( '\*', '.*', preg_quote( trim( $pattern, '/' ), '#' ) ) . '$#i';
				if ( preg_match( $regex, trim( $normalized, '/' ) ) ) {
					return true;
				}
			} elseif ( 0 === strpos( trim( $normalized, '/' ), trim( $pattern, '/' ) ) ) {
				return true;
			}
		}

		$extension = strtolower( pathinfo( $normalized, PATHINFO_EXTENSION ) );
		if ( $extension && in_array( $extension, $excluded_extensions, true ) ) {
			return true;
		}

		return false;
	}

	private function settings_excluded_paths() {
		$settings = $this->settings();
		$lines    = preg_split( '/\r?\n/', (string) $settings['exclude_paths'] );
		$paths    = array();

		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( '' !== $line ) {
				$paths[] = ltrim( $line, '/' );
			}
		}

		$base_work_dir = wp_normalize_path( $this->base_work_dir() );
		$root          = wp_normalize_path( ABSPATH );
		if ( 0 === strpos( $base_work_dir, $root ) ) {
			$paths[] = ltrim( substr( $base_work_dir, strlen( $root ) ), '/' );
		}

		$paths[] = 'wp-content/uploads/cmsvc';

		return array_values( array_unique( $paths ) );
	}

	private function settings_excluded_extensions() {
		$settings   = $this->settings();
		$extensions = array_map( 'trim', explode( ',', (string) $settings['exclude_file_types'] ) );
		$extensions = array_filter( $extensions );
		$extensions = array_map( 'strtolower', $extensions );
		$extensions[] = 'wpress';

		return array_values( array_unique( $extensions ) );
	}

	private function settings() {
		$stored   = get_option( CMSVC_OPTION_SETTINGS, array() );
		$stored   = is_array( $stored ) ? $stored : array();
		$settings = wp_parse_args( $stored, self::default_settings() );

		if ( empty( $stored['site_key'] ) ) {
			$settings['site_key'] = wp_generate_password( 32, false, false );
			update_option( CMSVC_OPTION_SETTINGS, $settings, false );
		}

		return $settings;
	}

	private function jobs() {
		$jobs = get_option( CMSVC_OPTION_JOBS, array() );
		return is_array( $jobs ) ? $jobs : array();
	}

	private function rest_agent_request_key( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		$key    = (string) $request->get_header( 'x-cmsvc-key' );
		if ( '' === $key && is_array( $params ) && isset( $params['site_key'] ) ) {
			$key = (string) $params['site_key'];
		}

		return $key;
	}

	private function rest_agent_requested_job_id( WP_REST_Request $request ) {
		$id = sanitize_text_field( (string) $request->get_param( 'id' ) );
		if ( '' !== $id ) {
			return $id;
		}

		$params = $request->get_json_params();
		if ( is_array( $params ) && ! empty( $params['job_id'] ) ) {
			return sanitize_text_field( (string) $params['job_id'] );
		}

		return '';
	}

	private function rest_agent_authorize( WP_REST_Request $request ) {
		$settings = $this->settings();
		$key      = $this->rest_agent_request_key( $request );

		if ( ! empty( $settings['site_key'] ) && '' !== $key && hash_equals( (string) $settings['site_key'], $key ) ) {
			return true;
		}

		$job_id = $this->rest_agent_requested_job_id( $request );
		if ( '' !== $job_id ) {
			$job = $this->job_by_id( $job_id );
			if ( ! empty( $job ) ) {
				$job_auth_key = isset( $job['auth_site_key'] ) ? (string) $job['auth_site_key'] : '';
				if ( '' !== $job_auth_key && '' !== $key && hash_equals( $job_auth_key, $key ) ) {
					return true;
				}
			}
		}

		return new WP_Error( 'cmsvc_forbidden', 'Invalid site key.', array( 'status' => 403 ) );
	}

	private function public_job( array $job ) {
		if ( isset( $job['r2']['secret_key'] ) ) {
			unset( $job['r2']['secret_key'] );
		}
		unset( $job['auth_site_key'] );
		return $job;
	}

	private function public_jobs() {
		$jobs = $this->jobs();
		foreach ( $jobs as $id => $job ) {
			$jobs[ $id ] = $this->public_job( $job );
		}
		return $jobs;
	}

	private function save_jobs( array $jobs ) {
		update_option( CMSVC_OPTION_JOBS, $jobs, false );
		foreach ( $jobs as $job ) {
			if ( is_array( $job ) && ! empty( $job['id'] ) ) {
				$this->save_job_snapshot( $job );
			}
		}
	}

	private function save_job( array $job ) {
		$jobs   = $this->jobs();
		$job_id = sanitize_text_field( (string) ( $job['id'] ?? '' ) );
		if ( '' === $job_id ) {
			return;
		}

		$existing_job = isset( $jobs[ $job_id ] ) && is_array( $jobs[ $job_id ] ) ? $jobs[ $job_id ] : array();
		if ( ! empty( $existing_job['cancelled'] ) && empty( $job['cancelled'] ) ) {
			$job = $existing_job;
		}

		$jobs[ $job_id ] = $job;
		$this->save_jobs( $jobs );
	}

	private function job_by_id( $job_id ) {
		$job_id = sanitize_text_field( (string) $job_id );
		if ( '' === $job_id ) {
			return array();
		}

		$jobs = $this->jobs();
		if ( isset( $jobs[ $job_id ] ) && is_array( $jobs[ $job_id ] ) ) {
			return $jobs[ $job_id ];
		}

		return $this->load_job_snapshot( $job_id );
	}

	private function new_job( $id, $stage ) {
		return array(
			'id'         => $id,
			'status'     => 'queued',
			'stage'      => $stage,
			'message'    => '',
			'created_at' => time(),
			'updated_at' => time(),
			'cancelled'  => false,
		);
	}

	private function cancel_job_by_id( $job_id, $message ) {
		$job_id = sanitize_text_field( (string) $job_id );
		if ( '' === $job_id ) {
			return array();
		}

		$jobs = $this->jobs();
		if ( ! isset( $jobs[ $job_id ] ) || ! is_array( $jobs[ $job_id ] ) ) {
			return array();
		}

		$job = $this->request_job_cancellation( $jobs[ $job_id ], $message );
		$this->save_job( $job );

		return $job;
	}

	private function request_job_cancellation( array $job, $message = 'Cancelled by user.' ) {
		$job_id              = sanitize_text_field( (string) ( $job['id'] ?? '' ) );
		$has_processing_task = '' !== $job_id ? $this->export_queue()->count_tasks_for_job( $job_id, array( 'processing' ) ) > 0 : false;

		$job['cancelled']           = true;
		$job['cancel_message']      = sanitize_text_field( (string) $message );
		$job['cleanup_after_cancel'] = true;
		$job['cancelled_at']        = time();
		$this->clear_export_queue_job( $job_id );

		if (
			! in_array( $job['status'] ?? '', array( 'queued', 'running' ), true )
			|| 'queued' === ( $job['status'] ?? '' )
			|| ( ! $has_processing_task && empty( $job['async_runner_active'] ) )
		) {
			return $this->finalize_job_cancellation( $job );
		}

		$job['updated_at'] = time();
		$job['message']    = $job['cancel_message'];
		return $job;
	}

	private function finalize_job_cancellation( array $job, $message = '' ) {
		$cancel_message = '' !== (string) $message
			? sanitize_text_field( (string) $message )
			: sanitize_text_field( (string) ( $job['cancel_message'] ?? 'Cancelled by user.' ) );

		$this->clear_export_queue_job( $job['id'] ?? '' );

		if ( ! empty( $job['cleanup_after_cancel'] ) ) {
			$this->cleanup_job_artifacts( $job );
		}

		$job['cancelled']           = true;
		$job['cancel_message']      = $cancel_message;
		$job['async_runner_active'] = false;
		return $this->mark_job( $job, 'cancelled', 'cancelled', $cancel_message );
	}

	private function assert_job_not_cancelled( $job_or_id ) {
		$job_id = is_array( $job_or_id ) ? sanitize_text_field( (string) ( $job_or_id['id'] ?? '' ) ) : sanitize_text_field( (string) $job_or_id );
		if ( '' === $job_id ) {
			return;
		}

		$job = $this->job_by_id( $job_id );
		if ( empty( $job ) || empty( $job['cancelled'] ) ) {
			return;
		}

		throw new CMSVC_Cancelled_Exception( (string) ( $job['cancel_message'] ?? 'Cancelled by user.' ) );
	}

	private function mark_job( array $job, $status, $stage, $message ) {
		$job['status']     = $status;
		$job['stage']      = $stage;
		$job['message']    = $message;
		$job['updated_at'] = time();
		return $job;
	}

	private function base_work_dir() {
		$upload = wp_upload_dir();
		return trailingslashit( $upload['basedir'] ) . 'cmsvc';
	}

	private function work_dir( $job_id ) {
		return trailingslashit( $this->base_work_dir() ) . sanitize_file_name( $job_id );
	}

	private function archive_path_for_job( $job_id ) {
		return trailingslashit( $this->work_dir( $job_id ) ) . sanitize_file_name( $job_id ) . '.wpress';
	}

	private function archive_is_complete( $path ) {
		if ( empty( $path ) || ! file_exists( $path ) ) {
			return false;
		}

		try {
			$extractor = new CMSVC_Extractor( $path );
			$is_valid  = $extractor->is_valid();
			$extractor->close();
			return $is_valid;
		} catch ( Exception $e ) {
			return false;
		}
	}

	private function export_queue() {
		return new CMSVC_Queue( CMSVC_EXPORT_QUEUE_GROUP, CMSVC_EXPORT_QUEUE_ACTION, CMSVC_EXPORT_TASK_MAX_RETRIES, 1 );
	}

	private function clear_export_queue_job( $job_id ) {
		$job_id = sanitize_text_field( (string) $job_id );
		if ( '' === $job_id ) {
			return;
		}

		$this->export_queue()->delete_tasks_for_job( $job_id );
	}

	private function enqueue_export_job( $job_id, $force = false ) {
		$queue = $this->export_queue();
		if ( ! $force && $queue->get_pending_count() > 0 ) {
			$queue->start_queue();
			return;
		}

		$queue->add_task(
			array(
				'job_id' => $job_id,
				'tick'   => wp_generate_uuid4(),
			)
		);
		$queue->start_queue();
	}

	private function queue_worker( $throttled = false ) {
		if ( $throttled ) {
			$kick_lock = 'cmsvc_kick_lock';
			if ( get_transient( $kick_lock ) ) {
				return;
			}

			set_transient( $kick_lock, 1, 15 );
		}

		if ( ! wp_next_scheduled( CMSVC_KICK_HOOK ) ) {
			wp_schedule_single_event( time() + 5, CMSVC_KICK_HOOK );
		}

		if ( function_exists( 'spawn_cron' ) ) {
			spawn_cron();
		}
	}

	private function cleanup_job_artifacts( array $job ) {
		if ( ! empty( $job['archive_path'] ) && file_exists( $job['archive_path'] ) ) {
			wp_delete_file( $job['archive_path'] );
		}

		$dir = $this->work_dir( $job['id'] ?? '' );
		if ( is_dir( $dir ) ) {
			$this->delete_directory_recursive( $dir );
		}
	}

	private function cleanup_job_artifact_status( array $job ) {
		$archive_path = (string) ( $job['archive_path'] ?? '' );
		$work_dir     = $this->work_dir( $job['id'] ?? '' );

		return array(
			'archive_exists' => '' !== $archive_path && file_exists( $archive_path ),
			'work_dir_exists' => '' !== $work_dir && is_dir( $work_dir ),
		);
	}

	private function save_job_snapshot( array $job ) {
		$path = $this->job_snapshot_path( $job['id'] ?? '' );
		if ( '' === $path ) {
			return;
		}

		if ( ! $this->should_persist_job_snapshot( $job ) ) {
			$this->delete_job_snapshot( $job['id'] ?? '' );
			$this->cleanup_legacy_job_snapshot_directory( $job['id'] ?? '' );
			return;
		}

		wp_mkdir_p( dirname( $path ) );
		file_put_contents( $path, wp_json_encode( $job ) );
		$this->cleanup_legacy_job_snapshot_directory( $job['id'] ?? '' );
	}

	private function load_job_snapshot( $job_id ) {
		$path = $this->job_snapshot_path( $job_id );
		if ( '' === $path || ! file_exists( $path ) ) {
			return array();
		}

		$job = json_decode( (string) file_get_contents( $path ), true );
		return is_array( $job ) ? $job : array();
	}

	private function job_snapshot_path( $job_id ) {
		$job_id = sanitize_file_name( (string) $job_id );
		if ( '' === $job_id ) {
			return '';
		}

		return trailingslashit( $this->job_snapshot_dir() ) . $job_id . '.json';
	}

	private function job_snapshot_dir() {
		return trailingslashit( $this->base_work_dir() ) . '_job-state';
	}

	private function should_persist_job_snapshot( array $job ) {
		return in_array( (string) ( $job['status'] ?? '' ), array( 'queued', 'running' ), true );
	}

	private function delete_job_snapshot( $job_id ) {
		$path = $this->job_snapshot_path( $job_id );
		if ( '' === $path || ! file_exists( $path ) ) {
			return;
		}

		@unlink( $path );
		$directory = dirname( $path );
		if ( is_dir( $directory ) ) {
			$items = array_values(
				array_filter(
					(array) scandir( $directory ),
					static function ( $item ) {
						return '.' !== $item && '..' !== $item;
					}
				)
			);

			if ( empty( $items ) ) {
				@rmdir( $directory );
			}
		}
	}

	private function cleanup_legacy_job_snapshot_directory( $job_id ) {
		$job_id     = sanitize_file_name( (string) $job_id );
		$legacy_dir = '' !== $job_id ? $this->work_dir( $job_id ) : '';
		if ( '' === $legacy_dir || ! is_dir( $legacy_dir ) ) {
			return;
		}

		$items = array_values(
			array_filter(
				(array) scandir( $legacy_dir ),
				static function ( $item ) {
					return '.' !== $item && '..' !== $item;
				}
			)
		);

		if ( 1 !== count( $items ) || 'job-state.json' !== $items[0] ) {
			return;
		}

		$legacy_snapshot = trailingslashit( $legacy_dir ) . 'job-state.json';
		if ( file_exists( $legacy_snapshot ) ) {
			@unlink( $legacy_snapshot );
		}
		@rmdir( $legacy_dir );
	}

	private function delete_directory_recursive( $directory ) {
		$directory = wp_normalize_path( $directory );
		$base      = wp_normalize_path( $this->base_work_dir() );

		if ( '' === $directory || 0 !== strpos( $directory, $base ) ) {
			return;
		}

		$items = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $directory, FilesystemIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ( $items as $item ) {
			if ( $item->isDir() ) {
				@rmdir( $item->getPathname() );
			} else {
				@unlink( $item->getPathname() );
			}
		}

		@rmdir( $directory );
	}

	private function database_tables() {
		global $wpdb;
		$tables = $wpdb->get_col( 'SHOW TABLES' );
		return array_values( array_filter( array_map( 'strval', (array) $tables ) ) );
	}

	private function database_base_tables() {
		return $this->database_entities_by_type( 'BASE TABLE' );
	}

	private function database_views() {
		return $this->database_entities_by_type( 'VIEW' );
	}

	private function database_entities_by_type( $type ) {
		global $wpdb;

		$type   = strtoupper( (string) $type );
		$rows   = $wpdb->get_results( $wpdb->prepare( 'SHOW FULL TABLES WHERE Table_type = %s', $type ), ARRAY_N );
		$names  = array();

		foreach ( (array) $rows as $row ) {
			if ( isset( $row[0] ) && '' !== (string) $row[0] ) {
				$names[] = (string) $row[0];
			}
		}

		return array_values( array_unique( $names ) );
	}

	private function mysql_connection_parts() {
		$host   = DB_HOST;
		$parts  = array(
			'host'   => '',
			'port'   => '',
			'socket' => '',
		);

		if ( false !== strpos( $host, ':/' ) ) {
			list( $parts['host'], $parts['socket'] ) = explode( ':', $host, 2 );
			return $parts;
		}

		if ( preg_match( '/^(.+?):([0-9]+)$/', $host, $matches ) ) {
			$parts['host'] = $matches[1];
			$parts['port'] = $matches[2];
			return $parts;
		}

		$parts['host'] = $host;
		return $parts;
	}

	private function create_mysql_defaults_file() {
		$dir  = $this->work_dir( 'mysql-auth' );
		$file = trailingslashit( $dir ) . 'client.cnf';

		wp_mkdir_p( $dir );

		$contents = "[client]\nuser=" . DB_USER . "\npassword=\"" . addcslashes( DB_PASSWORD, "\\\"\n\r" ) . "\"\n";
		file_put_contents( $file, $contents );
		@chmod( $file, 0600 );

		return $file;
	}

	private function can_use_mysqldump() {
		return $this->can_run_shell_commands() && $this->shell_binary_exists( 'mysqldump' );
	}

	private function can_use_native_mysql_import() {
		return $this->can_run_shell_commands() && '' !== $this->database_client_binary() && $this->shell_binary_exists( 'wp' );
	}

	private function can_run_shell_commands() {
		if ( ! function_exists( 'proc_open' ) ) {
			return false;
		}

		$disabled = array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) );
		return ! in_array( 'proc_open', $disabled, true );
	}

	private function shell_binary_exists( $binary ) {
		if ( ! $this->can_run_shell_commands() ) {
			return false;
		}

		try {
			$this->run_shell_command(
				array(
					'sh',
					'-lc',
					'command -v ' . escapeshellarg( $binary ),
				)
			);
			return true;
		} catch ( Exception $e ) {
			return false;
		}
	}

	private function database_client_binary() {
		if ( $this->shell_binary_exists( 'mariadb' ) ) {
			return 'mariadb';
		}

		if ( $this->shell_binary_exists( 'mysql' ) ) {
			return 'mysql';
		}

		return '';
	}

	private function run_database_client_sql( $sql, $job_id = '' ) {
		$path = $this->work_dir( 'mysql-auth' ) . '/db-client-command.sql';
		wp_mkdir_p( dirname( $path ) );
		file_put_contents( $path, (string) $sql );
		$this->import_sql_file_with_mysql_client( $path, $job_id );
	}

	private function run_detached_shell_command( array $parts, $cwd = null ) {
		$command = implode( ' ', array_map( 'escapeshellarg', $parts ) );
		$cwd     = $cwd ?: ABSPATH;
		$pid     = $this->run_shell_command(
			array(
				'sh',
				'-lc',
				'cd ' . escapeshellarg( $cwd ) . ' && nohup ' . $command . ' >/dev/null 2>&1 & echo $!',
			),
			$cwd
		);

		return trim( (string) $pid );
	}

	private function run_shell_command( array $parts, $cwd = null, $job_id = '' ) {
		$escaped = array_map( 'escapeshellarg', $parts );
		$command = implode( ' ', $escaped );

		$descriptors = array(
			0 => array( 'pipe', 'r' ),
			1 => array( 'pipe', 'w' ),
			2 => array( 'pipe', 'w' ),
		);

		$process = proc_open( $command, $descriptors, $pipes, $cwd ?: ABSPATH );
		if ( ! is_resource( $process ) ) {
			throw new Exception( 'Unable to start shell command.' );
		}

		fclose( $pipes[0] );
		stream_set_blocking( $pipes[1], false );
		stream_set_blocking( $pipes[2], false );

		$stdout                = '';
		$stderr                = '';
		$cancelled_message     = '';
		$termination_attempted = false;

		do {
			$stdout .= stream_get_contents( $pipes[1] );
			$stderr .= stream_get_contents( $pipes[2] );

			if ( '' !== $job_id && '' === $cancelled_message ) {
				try {
					$this->assert_job_not_cancelled( $job_id );
				} catch ( CMSVC_Cancelled_Exception $e ) {
					$cancelled_message = $e->getMessage();
				}
			}

			$status = proc_get_status( $process );
			if ( '' !== $cancelled_message && ! $termination_attempted && ! empty( $status['running'] ) ) {
				$termination_attempted = true;
				@proc_terminate( $process );
			}

			if ( empty( $status['running'] ) ) {
				break;
			}

			usleep( 250000 );
		} while ( true );

		$stdout .= stream_get_contents( $pipes[1] );
		$stderr .= stream_get_contents( $pipes[2] );
		fclose( $pipes[1] );
		fclose( $pipes[2] );

		$code = proc_close( $process );
		if ( '' !== $cancelled_message ) {
			throw new CMSVC_Cancelled_Exception( $cancelled_message );
		}

		if ( 0 !== $code ) {
			throw new Exception( trim( $stderr ?: $stdout ?: 'Shell command failed.' ) );
		}

		return trim( $stdout );
	}
}

add_filter(
	'cron_schedules',
	function ( $schedules ) {
		if ( ! isset( $schedules['minute'] ) ) {
			$schedules['minute'] = array(
				'interval' => 60,
				'display'  => 'Every Minute',
			);
		}
		return $schedules;
	}
);

register_activation_hook( __FILE__, array( 'CMSVC_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'CMSVC_Plugin', 'deactivate' ) );
CMSVC_Plugin::instance();

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	class CMSVC_CLI_Command {
		/**
		 * Imports a Cloud Migration Service archive from local disk.
		 *
		 * ## OPTIONS
		 *
		 * <archive>
		 * : Absolute path to the archive ZIP on this server.
		 *
		 * --source-url=<url>
		 * : Source site URL to replace during import.
		 *
		 * [--source-site-url=<url>]
		 * : Source site_url override.
		 *
		 * [--source-home-url=<url>]
		 * : Source home_url override.
		 *
		 * [--source-abspath=<path>]
		 * : Source ABSPATH override.
		 *
		 * [--source-content-dir=<path>]
		 * : Source WP_CONTENT_DIR override.
		 *
		 * [--source-uploads-dir=<path>]
		 * : Source uploads directory override.
		 *
		 * [--source-uploads-url=<url>]
		 * : Source uploads URL override.
		 *
		 * [--source-table-prefix=<prefix>]
		 * : Source database table prefix override.
		 *
		 * [--skip-email-domains=<1|0>]
		 * : Keep standalone email domains unchanged. Default: 1.
		 */
		public function import( $args, $assoc_args ) {
			$archive_path = isset( $args[0] ) ? (string) $args[0] : '';
			if ( '' === $archive_path || ! file_exists( $archive_path ) ) {
				WP_CLI::error( 'Archive file not found.' );
			}

			$source_context = $this->source_context_from_assoc_args( $assoc_args );
			if ( empty( $source_context['source_url'] ) ) {
				WP_CLI::error( 'Missing --source-url.' );
			}

			$skip_emails = ! isset( $assoc_args['skip-email-domains'] ) || '0' !== (string) $assoc_args['skip-email-domains'];

			try {
				CMSVC_Plugin::instance()->import_archive_from_cli( $archive_path, $source_context, $skip_emails );
				WP_CLI::success( 'Cloud Migration Service archive imported.' );
			} catch ( Exception $e ) {
				WP_CLI::error( $e->getMessage() );
			}
		}

		/**
		 * Downloads a Cloud Migration Service archive from R2 and imports it.
		 *
		 * ## OPTIONS
		 *
		 * <r2-key>
		 * : Object key inside the R2 bucket.
		 *
		 * --source-url=<url>
		 * : Source site URL to replace during import.
		 *
		 * --r2-account-id=<id>
		 * : R2 account ID.
		 *
		 * --r2-access-key=<key>
		 * : R2 access key.
		 *
		 * --r2-secret-key=<secret>
		 * : R2 secret key.
		 *
		 * --r2-bucket=<bucket>
		 * : R2 bucket name.
		 *
		 * [--source-site-url=<url>]
		 * : Source site_url override.
		 *
		 * [--source-home-url=<url>]
		 * : Source home_url override.
		 *
		 * [--source-abspath=<path>]
		 * : Source ABSPATH override.
		 *
		 * [--source-content-dir=<path>]
		 * : Source WP_CONTENT_DIR override.
		 *
		 * [--source-uploads-dir=<path>]
		 * : Source uploads directory override.
		 *
		 * [--source-uploads-url=<url>]
		 * : Source uploads URL override.
		 *
		 * [--source-table-prefix=<prefix>]
		 * : Source database table prefix override.
		 *
		 * [--skip-email-domains=<1|0>]
		 * : Keep standalone email domains unchanged. Default: 1.
		 */
		public function import_r2( $args, $assoc_args ) {
			$r2_key = isset( $args[0] ) ? (string) $args[0] : '';
			if ( '' === $r2_key ) {
				WP_CLI::error( 'Missing R2 key.' );
			}

			$source_context = $this->source_context_from_assoc_args( $assoc_args );
			if ( empty( $source_context['source_url'] ) ) {
				WP_CLI::error( 'Missing --source-url.' );
			}

			$r2 = array(
				'account_id' => (string) ( $assoc_args['r2-account-id'] ?? '' ),
				'access_key' => (string) ( $assoc_args['r2-access-key'] ?? '' ),
				'secret_key' => (string) ( $assoc_args['r2-secret-key'] ?? '' ),
				'bucket'     => (string) ( $assoc_args['r2-bucket'] ?? '' ),
			);

			foreach ( $r2 as $label => $value ) {
				if ( '' === $value ) {
					WP_CLI::error( 'Missing --r2-' . str_replace( '_', '-', $label ) . '.' );
				}
			}

			$skip_emails = ! isset( $assoc_args['skip-email-domains'] ) || '0' !== (string) $assoc_args['skip-email-domains'];

			try {
				CMSVC_Plugin::instance()->import_r2_from_cli( $r2_key, $r2, $source_context, $skip_emails );
				WP_CLI::success( 'Cloud Migration Service archive imported from R2.' );
			} catch ( Exception $e ) {
				WP_CLI::error( $e->getMessage() );
			}
		}

		/**
		 * Prints the destination site's agent info for the SSH worker.
		 */
		public function agent_info() {
			$settings = get_option( CMSVC_OPTION_SETTINGS, array() );

			WP_CLI::line(
				wp_json_encode(
					array(
						'home_url' => home_url(),
						'site_url' => site_url(),
						'site_key' => isset( $settings['site_key'] ) ? (string) $settings['site_key'] : '',
					)
				)
			);
		}

		/**
		 * Runs the detached destination database import for a queued job.
		 *
		 * ## OPTIONS
		 *
		 * <job-id>
		 * : The Cloud Migration Service job ID.
		 */
		public function run_async_db_import( $args ) {
			$job_id = isset( $args[0] ) ? (string) $args[0] : '';
			if ( '' === $job_id ) {
				WP_CLI::error( 'Missing job ID.' );
			}

			try {
				CMSVC_Plugin::instance()->run_async_database_import_job( $job_id );
				WP_CLI::success( 'Detached database import completed.' );
			} catch ( Exception $e ) {
				WP_CLI::error( $e->getMessage() );
			}
		}

		private function source_context_from_assoc_args( array $assoc_args ) {
			$source_url = isset( $assoc_args['source-url'] ) ? (string) $assoc_args['source-url'] : '';

			return array(
				'source_url'         => $source_url,
				'source_site_url'    => isset( $assoc_args['source-site-url'] ) ? (string) $assoc_args['source-site-url'] : $source_url,
				'source_home_url'    => isset( $assoc_args['source-home-url'] ) ? (string) $assoc_args['source-home-url'] : $source_url,
				'source_abspath'     => isset( $assoc_args['source-abspath'] ) ? (string) $assoc_args['source-abspath'] : '',
				'source_content_dir' => isset( $assoc_args['source-content-dir'] ) ? (string) $assoc_args['source-content-dir'] : '',
				'source_uploads_dir' => isset( $assoc_args['source-uploads-dir'] ) ? (string) $assoc_args['source-uploads-dir'] : '',
				'source_uploads_url' => isset( $assoc_args['source-uploads-url'] ) ? (string) $assoc_args['source-uploads-url'] : '',
				'source_table_prefix' => isset( $assoc_args['source-table-prefix'] ) ? (string) $assoc_args['source-table-prefix'] : '',
			);
		}
	}

	WP_CLI::add_command( 'cmsvc', 'CMSVC_CLI_Command' );
}
