<?php
/**
 * Plugin Name: Cloud Migration Service
 * Description: Cloud Migrator for FlyingHost.
 * Version: 0.3.3
 * Author: Rajin Sharwar
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/includes/class-cmsvc-transfer.php';
require_once __DIR__ . '/includes/class-cmsvc-queue.php';

define( 'CMSVC_VERSION', '0.3.3' );
define( 'CMSVC_OPTION_SETTINGS', 'cmsvc_settings' );
define( 'CMSVC_OPTION_JOBS', 'cmsvc_jobs' );
define( 'CMSVC_CRON_HOOK', 'cmsvc_process_jobs' );
define( 'CMSVC_KICK_HOOK', 'cmsvc_kick_jobs' );
define( 'CMSVC_EXPORT_QUEUE_GROUP', 'cmsvc_migration' );
define( 'CMSVC_EXPORT_QUEUE_ACTION', 'cmsvc_process_export_task' );
define( 'CMSVC_USER_AGENT', 'FlyingPress' );
define( 'CMSVC_WORKER_LOCK_TTL', defined( 'HOUR_IN_SECONDS' ) ? 12 * HOUR_IN_SECONDS : 43200 );
define( 'CMSVC_EXPORT_STALE_TTL', defined( 'DAY_IN_SECONDS' ) ? DAY_IN_SECONDS : 86400 );
define( 'CMSVC_EXPORT_TASK_MAX_RETRIES', 2147483647 );
define( 'CMSVC_EXPORT_TASK_CHUNK_BYTES', 536870912 );
define( 'CMSVC_EXPORT_TASK_WINDOW_SECONDS', 15 );
define( 'CMSVC_STREAM_FILE_CHUNK_BYTES', 67108864 );
define( 'CMSVC_STREAM_BUNDLE_BYTES', 67108864 );
define( 'CMSVC_STREAM_BUNDLE_MAX_FILES', 1000 );
define( 'CMSVC_IMPORT_EXTRACT_CHUNK_BYTES', 16777216 );
define( 'CMSVC_IMPORT_SQL_CHUNK_BYTES', 4194304 );
define( 'CMSVC_IMPORT_SQL_CLI_BATCH_BYTES', 134217728 );
define( 'CMSVC_ASYNC_IMPORT_MIN_BYTES', 5242880 );
define( 'CMSVC_IMPORT_ATTACHMENT_REGEN_BATCH_SIZE', 25 );
define( 'CMSVC_CLI_RETRY_LIMIT', 5 );
define( 'CMSVC_CLI_RETRY_DELAY_SECONDS', 5 );
define( 'CMSVC_GZIP_STREAM_CHUNK_BYTES', 1048576 );

class CMSVC_Cancelled_Exception extends Exception {}

final class CMSVC_Plugin {
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		CMSVC_Queue::init();

		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_post_cmsvc_save_settings', array( $this, 'save_settings' ) );
		add_action( 'admin_post_cmsvc_cancel_job', array( $this, 'cancel_job' ) );
		add_action( 'wp_ajax_cmsvc_tick', array( $this, 'ajax_tick' ) );
		add_action( CMSVC_CRON_HOOK, array( $this, 'process_jobs' ) );
		add_action( CMSVC_KICK_HOOK, array( $this, 'process_jobs' ) );
		add_action( CMSVC_EXPORT_QUEUE_ACTION, array( $this, 'process_export_queue_task' ) );
		add_action( 'rest_api_init', array( $this, 'rest_routes' ) );
	}

	public static function activate() {
		$settings = get_option( CMSVC_OPTION_SETTINGS );
		if ( ! is_array( $settings ) ) {
			update_option( CMSVC_OPTION_SETTINGS, self::default_settings(), false );
		}

		if ( ! wp_next_scheduled( CMSVC_CRON_HOOK ) ) {
			wp_schedule_event( time() + 30, 'minute', CMSVC_CRON_HOOK );
		}

		CMSVC_Queue::maybe_create_table();
		CMSVC_Queue::setup_watchdog();
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( CMSVC_CRON_HOOK );
		wp_clear_scheduled_hook( CMSVC_KICK_HOOK );
		CMSVC_Queue::clear_watchdog();
	}

	private static function default_settings() {
		return array(
			'site_key'           => wp_generate_password( 32, false, false ),
			'exclude_paths'      => "wp-content/cache\nwp-content/ai1wm-backups\nwp-content/updraft\nwp-content/uploads/cmsvc\nwp-content/uploads/backup*\nwp-content/object-cache.php\nnode_modules\ncpmove-*",
			'exclude_file_types' => 'log,tmp,zip,gz,bak,tar,wpress',
		);
	}

	public function admin_menu() {
		add_management_page(
			'Cloud Migration',
			'Cloud Migration',
			'manage_options',
			'cmsvc',
			array( $this, 'admin_page' )
		);
	}

	public function admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings       = $this->settings();
		$jobs           = $this->jobs();
		$has_active_job = false;

		foreach ( $jobs as $job ) {
			if ( in_array( $job['status'], array( 'queued', 'running' ), true ) ) {
				$has_active_job = true;
				break;
			}
		}
		?>
		<div class="wrap">
			<h1>Cloud Migration Service</h1>
			<?php settings_errors( 'cmsvc' ); ?>

			<style>
				.cmsvc-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(320px,420px);gap:20px;max-width:1180px}
				.cmsvc-card{background:#fff;border:1px solid #dcdcde;border-radius:4px;padding:18px}
				.cmsvc-card h2{margin-top:0}
				.cmsvc-card input[type=text],.cmsvc-card textarea{width:100%}
				.cmsvc-job{border-top:1px solid #dcdcde;padding:12px 0}
				.cmsvc-muted{color:#646970}
				.cmsvc-code{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:13px;word-break:break-all}
				@media(max-width:900px){.cmsvc-grid{grid-template-columns:1fr}}
			</style>

			<div class="cmsvc-grid">
				<div class="cmsvc-card">
					<h2>Worker Settings</h2>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="cmsvc_save_settings">
						<?php wp_nonce_field( 'cmsvc_save_settings' ); ?>
						<table class="form-table" role="presentation">
							<tr>
								<th scope="row">This site's worker key</th>
								<td>
									<input type="text" readonly value="<?php echo esc_attr( $this->site_worker_key( $settings ) ); ?>">
									<p class="description">Copy this key into Migration Worker.</p>
								</td>
							</tr>
							<tr>
								<th scope="row">Excluded paths</th>
								<td>
									<textarea name="exclude_paths" rows="8"><?php echo esc_textarea( $settings['exclude_paths'] ); ?></textarea>
									<p class="description">One path or glob per line, relative to the WordPress root when possible.</p>
								</td>
							</tr>
							<tr>
								<th scope="row">Excluded file extensions</th>
								<td>
									<input name="exclude_file_types" type="text" value="<?php echo esc_attr( $settings['exclude_file_types'] ); ?>">
									<p class="description">Comma-separated. Example: <span class="cmsvc-code">log,tmp,zip,gz,bak</span></p>
								</td>
							</tr>
						</table>
						<?php submit_button( 'Save Settings' ); ?>
					</form>
				</div>

				<div class="cmsvc-card">
					<h2>Jobs</h2>
					<?php if ( empty( $jobs ) ) : ?>
						<p>No jobs yet.</p>
					<?php else : ?>
						<?php foreach ( array_reverse( $jobs ) as $job ) : ?>
							<div class="cmsvc-job">
								<strong><?php echo esc_html( $job['id'] ); ?></strong>
								<div>Status: <?php echo esc_html( $job['status'] ); ?> / <?php echo esc_html( $job['stage'] ); ?></div>
								<div><?php echo esc_html( $job['message'] ); ?></div>
								<div class="cmsvc-muted">Updated: <?php echo esc_html( date_i18n( 'Y-m-d H:i:s', (int) $job['updated_at'] ) ); ?></div>
							</div>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php if ( $has_active_job ) : ?>
			<script>
				(function () {
					var nonce = <?php echo wp_json_encode( wp_create_nonce( 'cmsvc_tick' ) ); ?>;
					var busy = false;
					function escapeHtml(value) {
						return String(value).replace(/[&<>"']/g, function (char) {
							return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
						});
					}
					function formatDate(timestamp) {
						var date = new Date(Number(timestamp || 0) * 1000);
						if (Number.isNaN(date.getTime())) {
							return '';
						}
						return date.toLocaleString();
					}
					function renderJobs(jobs) {
						var list = document.querySelector('.cmsvc-card:last-of-type');
						if (!list) {
							return;
						}
						var items = Object.keys(jobs || {}).map(function (id) {
							return jobs[id];
						}).sort(function (a, b) {
							return Number(b.updated_at || 0) - Number(a.updated_at || 0);
						});
						var html = '<h2>Jobs</h2>';
						if (!items.length) {
							html += '<p>No jobs yet.</p>';
						} else {
							html += items.map(function (job) {
								return '<div class="cmsvc-job">'
									+ '<strong>' + escapeHtml(job.id || '') + '</strong>'
									+ '<div>Status: ' + escapeHtml(job.status || '') + ' / ' + escapeHtml(job.stage || '') + '</div>'
									+ '<div>' + escapeHtml(job.message || '') + '</div>'
									+ '<div class="cmsvc-muted">Updated: ' + escapeHtml(formatDate(job.updated_at)) + '</div>'
									+ '</div>';
							}).join('');
						}
						list.innerHTML = html;
					}
					function tick() {
						if (busy) {
							return;
						}
						busy = true;
						var data = new window.FormData();
						data.append('action', 'cmsvc_tick');
						data.append('_ajax_nonce', nonce);
						window.fetch(window.ajaxurl, {
							method: 'POST',
							credentials: 'same-origin',
							body: data
						}).then(function (response) {
							return response.json();
						}).then(function (response) {
							if (response && response.success && response.data && response.data.jobs) {
								renderJobs(response.data.jobs);
							}
						}).catch(function () {
						}).finally(function () {
							busy = false;
							window.setTimeout(tick, 5000);
						});
					}
					window.setTimeout(tick, 5000);
				}());
			</script>
		<?php endif; ?>
		<?php
	}

	public function save_settings() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'cmsvc_save_settings' ) ) {
			wp_die( 'Not allowed.' );
		}

		$current                       = $this->settings();
		$current['exclude_paths']      = isset( $_POST['exclude_paths'] ) ? trim( (string) wp_unslash( $_POST['exclude_paths'] ) ) : '';
		$current['exclude_file_types'] = isset( $_POST['exclude_file_types'] ) ? sanitize_text_field( wp_unslash( $_POST['exclude_file_types'] ) ) : '';

		update_option( CMSVC_OPTION_SETTINGS, $current, false );
		add_settings_error( 'cmsvc', 'saved', 'Settings saved.', 'updated' );
		set_transient( 'settings_errors', get_settings_errors(), 30 );
		wp_safe_redirect( admin_url( 'tools.php?page=cmsvc' ) );
		exit;
	}

	public function cancel_job() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'cmsvc_cancel_job' ) ) {
			wp_die( 'Not allowed.' );
		}

		$job_id = isset( $_POST['job_id'] ) ? sanitize_text_field( wp_unslash( $_POST['job_id'] ) ) : '';
		$this->cancel_job_by_id( $job_id, 'Cancelled by an administrator.' );

		wp_safe_redirect( admin_url( 'tools.php?page=cmsvc' ) );
		exit;
	}

	public function ajax_tick() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'cmsvc_tick', false, false ) ) {
			wp_send_json_error( array( 'message' => 'Not allowed.' ), 403 );
		}

		$this->process_jobs();
		wp_send_json_success( array( 'jobs' => $this->public_jobs() ) );
	}

	public function rest_routes() {
		register_rest_route(
			'cmsvc/v1',
			'/agent/export',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'rest_agent_export' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'cmsvc/v1',
			'/agent/import',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'rest_agent_import' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'cmsvc/v1',
			'/agent/info',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'rest_agent_info' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'cmsvc/v1',
			'/agent/plugin/update',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'rest_agent_plugin_update' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'cmsvc/v1',
			'/agent/job/(?P<id>[a-zA-Z0-9_\-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'rest_agent_job' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'cmsvc/v1',
			'/agent/stream/entry/(?P<id>[a-zA-Z0-9_\-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'rest_agent_stream_entry' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'cmsvc/v1',
			'/agent/stream/file/(?P<id>[a-zA-Z0-9_\-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'rest_agent_stream_file' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'cmsvc/v1',
			'/agent/stream/bundle/(?P<id>[a-zA-Z0-9_\-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'rest_agent_stream_bundle' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'cmsvc/v1',
			'/agent/cleanup/(?P<id>[a-zA-Z0-9_\-]+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'rest_agent_cleanup' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'cmsvc/v1',
			'/agent/cancel/(?P<id>[a-zA-Z0-9_\-]+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'rest_agent_cancel' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	public function rest_agent_export( WP_REST_Request $request ) {
		$auth = $this->rest_agent_authorize( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$params = $request->get_json_params();
		$job_id = isset( $params['job_id'] ) ? sanitize_text_field( $params['job_id'] ) : '';
		if ( '' === $job_id ) {
			$job_id = 'agent_' . gmdate( 'Ymd_His' ) . '_' . wp_generate_password( 8, false, false );
		}

		$jobs = $this->jobs();
		foreach ( $jobs as $existing_id => $existing_job ) {
			if ( $existing_id !== $job_id && in_array( $existing_job['status'] ?? '', array( 'queued', 'running' ), true ) ) {
				return new WP_Error( 'cmsvc_export_running', 'A source export is already running. Cancel it before starting another migration.', array( 'status' => 409 ) );
			}
		}

		$job               = $this->new_job( $job_id, 'agent_export' );
		$job['source_url'] = home_url();
		$job['transport']  = 'stream';
		$job['message']    = 'Queued export preparation for direct streaming.';

		$jobs[ $job_id ] = $job;
		$this->save_jobs( $jobs );
		$this->enqueue_export_job( $job_id, true );

		return rest_ensure_response(
			array(
				'ok'     => true,
				'job_id' => $job_id,
			)
		);
	}

	public function rest_agent_import( WP_REST_Request $request ) {
		$auth = $this->rest_agent_authorize( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$params = $request->get_json_params();
		$job_id = isset( $params['job_id'] ) ? sanitize_text_field( $params['job_id'] ) : '';
		if ( '' === $job_id ) {
			$job_id = 'agent_import_' . gmdate( 'Ymd_His' ) . '_' . wp_generate_password( 8, false, false );
		}

		$jobs = $this->jobs();
		foreach ( $jobs as $existing_id => $existing_job ) {
			if ( $existing_id !== $job_id && in_array( $existing_job['status'] ?? '', array( 'queued', 'running' ), true ) ) {
				return new WP_Error( 'cmsvc_import_running', 'A destination import is already running. Cancel it before starting another migration.', array( 'status' => 409 ) );
			}
		}

		$source_context = is_array( $params['source_context'] ?? null ) ? $params['source_context'] : array();
		$source_context = array(
			'source_url'         => isset( $source_context['source_url'] ) ? esc_url_raw( (string) $source_context['source_url'] ) : '',
			'source_site_url'    => isset( $source_context['source_site_url'] ) ? esc_url_raw( (string) $source_context['source_site_url'] ) : '',
			'source_home_url'    => isset( $source_context['source_home_url'] ) ? esc_url_raw( (string) $source_context['source_home_url'] ) : '',
			'source_abspath'     => isset( $source_context['source_abspath'] ) ? wp_normalize_path( (string) $source_context['source_abspath'] ) : '',
			'source_content_dir' => isset( $source_context['source_content_dir'] ) ? wp_normalize_path( (string) $source_context['source_content_dir'] ) : '',
			'source_uploads_dir' => isset( $source_context['source_uploads_dir'] ) ? wp_normalize_path( (string) $source_context['source_uploads_dir'] ) : '',
			'source_uploads_url' => isset( $source_context['source_uploads_url'] ) ? esc_url_raw( (string) $source_context['source_uploads_url'] ) : '',
			'source_table_prefix' => isset( $source_context['source_table_prefix'] ) ? sanitize_text_field( (string) $source_context['source_table_prefix'] ) : '',
			'source_database_counts' => is_array( $source_context['source_database_counts'] ?? null ) ? $this->sanitize_database_counts( $source_context['source_database_counts'] ) : array(),
			'source_wp_config_defines' => is_array( $source_context['source_wp_config_defines'] ?? null ) ? $source_context['source_wp_config_defines'] : array(),
		);

		if ( '' === $source_context['source_url'] ) {
			return new WP_Error( 'cmsvc_bad_request', 'Missing source URL.', array( 'status' => 400 ) );
		}

		$source = is_array( $params['source'] ?? null ) ? $params['source'] : array();
		$source_transfer = array(
			'url'         => isset( $source['url'] ) ? esc_url_raw( (string) $source['url'] ) : $source_context['source_url'],
			'job_id'      => isset( $source['job_id'] ) ? sanitize_text_field( (string) $source['job_id'] ) : '',
			'site_key'    => isset( $source['site_key'] ) ? sanitize_text_field( (string) $source['site_key'] ) : '',
			'chunk_bytes' => isset( $source['chunk_bytes'] ) ? max( 1048576, min( CMSVC_STREAM_FILE_CHUNK_BYTES, (int) $source['chunk_bytes'] ) ) : CMSVC_STREAM_FILE_CHUNK_BYTES,
		);

		if ( '' === $source_transfer['url'] || '' === $source_transfer['job_id'] || '' === $source_transfer['site_key'] ) {
			return new WP_Error( 'cmsvc_bad_request', 'Missing source streaming handoff values.', array( 'status' => 400 ) );
		}

		$job                           = $this->new_job( $job_id, 'destination_stream' );
		$job['transport']             = 'stream';
		$job['source_context']         = $source_context;
		$job['auth_site_key']          = $this->rest_agent_request_key( $request );
		$job['do_not_replace_emails']  = ! isset( $params['skip_email_domains'] ) || ! empty( $params['skip_email_domains'] );
		$job['cleanup_after_complete'] = ! isset( $params['cleanup_after_complete'] ) || ! empty( $params['cleanup_after_complete'] );
		$job['message']                = 'Queued destination direct file streaming.';
		$job['source_transfer']        = $source_transfer;

		$jobs[ $job_id ] = $job;
		$this->save_jobs( $jobs );
		$this->enqueue_export_job( $job_id, true );

		return rest_ensure_response(
			array(
				'ok'     => true,
				'job_id' => $job_id,
			)
		);
	}

	public function rest_agent_info( WP_REST_Request $request ) {
		$auth = $this->rest_agent_authorize( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$settings = $this->settings();

		return rest_ensure_response(
			array(
				'ok'       => true,
				'version'  => CMSVC_VERSION,
				'home_url' => home_url(),
				'site_url' => site_url(),
				'site_key' => $this->site_worker_key( $settings ),
			)
		);
	}

	public function rest_agent_plugin_update( WP_REST_Request $request ) {
		$auth = $this->rest_agent_authorize( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$params  = $request->get_json_params();
		$params  = is_array( $params ) ? $params : array();
		$zip_url = isset( $params['zip_url'] ) ? esc_url_raw( (string) $params['zip_url'] ) : '';
		if ( '' === $zip_url ) {
			return new WP_Error( 'cmsvc_bad_request', 'Missing plugin ZIP URL.', array( 'status' => 400 ) );
		}

		try {
			$result = $this->install_plugin_from_zip_url( $zip_url );
		} catch ( Exception $e ) {
			return new WP_Error( 'cmsvc_plugin_update_failed', $e->getMessage(), array( 'status' => 500 ) );
		}

		return rest_ensure_response(
			array(
				'ok'      => true,
				'version' => CMSVC_VERSION,
				'result'  => $result,
			)
		);
	}

	public function rest_agent_job( WP_REST_Request $request ) {
		$auth = $this->rest_agent_authorize( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$id  = sanitize_text_field( $request['id'] );
		$job = $this->job_by_id( $id );
		if ( empty( $job ) ) {
			return new WP_Error( 'cmsvc_not_found', 'Job not found.', array( 'status' => 404 ) );
		}

		if ( in_array( $job['status'], array( 'queued', 'running' ), true ) && empty( $job['async_runner_active'] ) && empty( $job['cancelled'] ) ) {
			$this->enqueue_export_job( $id );
		}

		$job = $this->public_job( $job );
		if ( ! empty( $job['manifest'] ) && is_array( $job['manifest'] ) ) {
			$job = array_merge( $job, $job['manifest'] );
		}

		return rest_ensure_response( $job );
	}

	public function rest_agent_stream_entry( WP_REST_Request $request ) {
		$auth = $this->rest_agent_authorize( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$job = $this->source_stream_job_from_request( $request );
		if ( is_wp_error( $job ) ) {
			return $job;
		}

		$offset = max( 0, (int) $request->get_param( 'offset' ) );
		try {
			$entry = $this->source_stream_entry_at_offset( $job, $offset, false );
		} catch ( Exception $e ) {
			return new WP_Error( 'cmsvc_stream_entry_error', $e->getMessage(), array( 'status' => 500 ) );
		}

		return rest_ensure_response( $entry );
	}

	public function rest_agent_stream_file( WP_REST_Request $request ) {
		$auth = $this->rest_agent_authorize( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$job = $this->source_stream_job_from_request( $request );
		if ( is_wp_error( $job ) ) {
			return $job;
		}

		$entry_offset = max( 0, (int) $request->get_param( 'entry_offset' ) );
		$file_offset  = max( 0, (int) $request->get_param( 'offset' ) );
		$max_length   = max( 1, min( CMSVC_STREAM_FILE_CHUNK_BYTES, (int) $request->get_param( 'length' ) ) );
		try {
			$result = $this->source_stream_entry_at_offset( $job, $entry_offset, true );
		} catch ( Exception $e ) {
			return new WP_Error( 'cmsvc_stream_file_error', $e->getMessage(), array( 'status' => 500 ) );
		}

		if ( ! empty( $result['complete'] ) || empty( $result['entry'] ) || ! empty( $result['entry']['missing'] ) ) {
			return new WP_Error( 'cmsvc_stream_file_missing', 'Source stream file is not available.', array( 'status' => 404 ) );
		}

		$entry = $result['entry'];
		$size  = max( 0, (int) ( $entry['size'] ?? 0 ) );
		if ( $file_offset >= $size ) {
			return new WP_Error( 'cmsvc_stream_range_invalid', 'Requested source stream range is outside the file.', array( 'status' => 416 ) );
		}

		$length = min( $max_length, $size - $file_offset );
		$this->send_source_stream_file_chunk( (string) $entry['source'], $file_offset, $length, $size, (int) ( $entry['mtime'] ?? time() ) );
		exit;
	}

	public function rest_agent_stream_bundle( WP_REST_Request $request ) {
		$auth = $this->rest_agent_authorize( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$job = $this->source_stream_job_from_request( $request );
		if ( is_wp_error( $job ) ) {
			return $job;
		}

		$offset          = max( 0, (int) $request->get_param( 'offset' ) );
		$requested_bytes = (int) $request->get_param( 'max_bytes' );
		$requested_files = (int) $request->get_param( 'max_files' );
		$max_bytes       = $requested_bytes > 0 ? max( 1048576, min( CMSVC_STREAM_BUNDLE_BYTES, $requested_bytes ) ) : CMSVC_STREAM_BUNDLE_BYTES;
		$max_files       = $requested_files > 0 ? max( 1, min( CMSVC_STREAM_BUNDLE_MAX_FILES, $requested_files ) ) : CMSVC_STREAM_BUNDLE_MAX_FILES;
		$bundle_path = $this->source_stream_bundle_path( $job );

		try {
			$result = $this->create_source_stream_bundle( $job, $offset, $max_bytes, $max_files, $bundle_path );
		} catch ( Exception $e ) {
			if ( file_exists( $bundle_path ) ) {
				@unlink( $bundle_path );
			}
			return new WP_Error( 'cmsvc_stream_bundle_error', $e->getMessage(), array( 'status' => 500 ) );
		}

		if ( empty( $result['files'] ) && empty( $result['skipped'] ) ) {
			if ( file_exists( $bundle_path ) ) {
				@unlink( $bundle_path );
			}
			return rest_ensure_response( $result );
		}

		$this->send_source_stream_bundle( $bundle_path, $result );
		exit;
	}

	public function rest_agent_cleanup( WP_REST_Request $request ) {
		$auth = $this->rest_agent_authorize( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$id  = sanitize_text_field( $request['id'] );
		$job = $this->job_by_id( $id );
		if ( empty( $job ) ) {
			return new WP_Error( 'cmsvc_not_found', 'Job not found.', array( 'status' => 404 ) );
		}

		$this->cleanup_job_artifacts( $job );
		if ( ! empty( $job['cancelled'] ) || 'cancelled' === ( $job['status'] ?? '' ) ) {
			$job = $this->finalize_job_cancellation( $job );
		} else {
			$job = $this->mark_job( $job, 'complete', 'agent_cleaned', 'Agent temporary files cleaned.' );
		}
		$this->save_job( $job );

		$cleanup = $this->cleanup_job_artifact_status( $job );

		return rest_ensure_response(
			array(
				'ok'      => true,
				'job_id'  => $id,
				'cleanup' => $cleanup,
			)
		);
	}

	public function rest_agent_cancel( WP_REST_Request $request ) {
		$auth = $this->rest_agent_authorize( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$id      = sanitize_text_field( $request['id'] );
		$params  = $request->get_json_params();
		$message = is_array( $params ) && ! empty( $params['message'] )
			? sanitize_text_field( (string) $params['message'] )
			: 'Cancelled by user.';

		$job = $this->cancel_job_by_id( $id, $message );
		if ( empty( $job ) ) {
			return new WP_Error( 'cmsvc_not_found', 'Job not found.', array( 'status' => 404 ) );
		}

		return rest_ensure_response(
			array(
				'ok'  => true,
				'job' => $this->public_job( $job ),
			)
		);
	}

	public function process_jobs() {
		$jobs = $this->jobs();
		foreach ( $jobs as $job_id => $job ) {
			if ( ! empty( $job['manual_only'] ) || ! empty( $job['async_runner_active'] ) ) {
				continue;
			}

			if ( in_array( $job['status'] ?? '', array( 'queued', 'running' ), true ) && empty( $job['cancelled'] ) ) {
				$this->enqueue_export_job( $job_id );
			}
		}
	}

	public function process_export_queue_task( $task_data ) {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 );
		}

		$job_id = sanitize_text_field( (string) ( $task_data['job_id'] ?? '' ) );
		if ( '' === $job_id ) {
			return;
		}

		$jobs = $this->jobs();
		if ( ! isset( $jobs[ $job_id ] ) ) {
			return;
		}

		$job = $jobs[ $job_id ];
		if ( ! in_array( $job['status'] ?? '', array( 'queued', 'running' ), true ) ) {
			return;
		}

		if ( ! empty( $job['cancelled'] ) ) {
			$jobs[ $job_id ] = $this->finalize_job_cancellation( $job );
			$this->save_jobs( $jobs );
			return;
		}

		try {
			$job = $this->run_export_queue_step( $job );
		} catch ( CMSVC_Cancelled_Exception $e ) {
			$latest_job      = $this->job_by_id( $job_id );
			$latest_job      = empty( $latest_job ) ? $job : $latest_job;
			$jobs[ $job_id ] = $this->finalize_job_cancellation( $latest_job, $e->getMessage() );
			$this->save_jobs( $jobs );
			return;
		} catch ( Exception $e ) {
			$latest_job = $this->job_by_id( $job_id );
			if ( ! empty( $latest_job ) && ! empty( $latest_job['cancelled'] ) ) {
				$jobs[ $job_id ] = $this->finalize_job_cancellation( $latest_job, (string) ( $latest_job['cancel_message'] ?? $e->getMessage() ) );
				$this->save_jobs( $jobs );
				return;
			}

			$job = $this->mark_job( $job, 'running', $job['stage'], 'Retrying after export error: ' . $e->getMessage() );
			$this->save_job( $job );
			throw $e;
		}

		$latest_job = $this->job_by_id( $job_id );
		if ( ! empty( $latest_job ) && ! empty( $latest_job['cancelled'] ) ) {
			$jobs[ $job_id ] = $this->finalize_job_cancellation( $latest_job, (string) ( $latest_job['cancel_message'] ?? '' ) );
			$this->save_jobs( $jobs );
			return;
		}

		$this->save_job( $job );

		$latest_job = $this->job_by_id( $job_id );
		if (
			! empty( $latest_job )
			&& in_array( $latest_job['status'] ?? '', array( 'queued', 'running' ), true )
			&& empty( $latest_job['cancelled'] )
		) {
			$this->enqueue_export_job( $job_id, true );
		}
	}

	private function run_export_queue_step( array $job ) {
		$job['status']     = 'running';
		$job['updated_at'] = time();

		switch ( $job['stage'] ) {
			case 'agent_export':
				return $this->prepare_agent_export_archive( $job );

			case 'agent_exporting':
				if ( ! empty( $job['index_state'] ) ) {
					return $this->process_agent_index_batch( $job );
				}

				return $this->recover_agent_export_preparation( $job );

			case 'agent_indexing':
				return $this->process_agent_index_batch( $job );

			case 'destination_stream':
				return $this->process_destination_stream_batch( $job );

			case 'destination_extract':
				return $this->process_destination_extract_batch( $job );

			case 'destination_db_expand':
				return $this->process_destination_database_expand_batch( $job );

			case 'destination_db_import':
				return $this->process_destination_database_import_batch( $job );

			case 'destination_media_regenerate':
				return $this->process_destination_attachment_metadata_batch( $job );

			case 'destination_finalize':
				return $this->finalize_destination_import( $job );
		}

		throw new Exception( 'Unknown job stage: ' . $job['stage'] );
	}

	private function run_job_step( array $job ) {
		return $this->run_export_queue_step( $job );
	}

	private function prepare_agent_export_archive( array $job ) {
		$paths = $this->export_artifact_paths( $job['id'] );
		wp_mkdir_p( $paths['dir'] );

		foreach ( array( $paths['db'], $paths['db_gzip'], $paths['manifest'], $paths['list'], $paths['archive'] ) as $path ) {
			if ( file_exists( $path ) ) {
				wp_delete_file( $path );
				clearstatcache( true, $path );
				if ( file_exists( $path ) ) {
					throw new Exception( 'Unable to remove previous export artifact: ' . basename( $path ) );
				}
			}
		}

		$job['stage_started_at'] = time();
		$job['index_state']      = array(
			'db_path'          => $paths['db'],
			'manifest_path'    => $paths['manifest'],
			'list_path'        => $paths['list'],
			'indexed_files'    => 0,
			'database_ready'   => false,
			'manifest_ready'   => false,
			'initial_entries'  => false,
			'scan_stack'       => $this->initial_archive_scan_stack(),
		);
		$job                     = $this->mark_job( $job, 'running', 'agent_exporting', 'Exporting database and indexing files.' );
		$this->save_job( $job );

		return $this->process_agent_index_batch( $job );
	}

	private function recover_agent_export_preparation( array $job ) {
		$paths = $this->export_artifact_paths( $job['id'] );

		if ( file_exists( $paths['db'] ) && file_exists( $paths['manifest'] ) && file_exists( $paths['list'] ) ) {
			$indexed_files      = $this->count_archive_file_list_entries( $paths['list'], true );
			$job['index_state'] = array(
				'db_path'          => $paths['db'],
				'manifest_path'    => $paths['manifest'],
				'list_path'        => $paths['list'],
				'indexed_files'    => 0,
				'database_ready'   => true,
				'manifest_ready'   => true,
				'initial_entries'  => false,
				'scan_stack'       => $this->initial_archive_scan_stack(),
			);
			$job                 = $this->mark_job( $job, 'running', 'agent_indexing', 'Recovering file index without re-exporting the database.' );
			$this->save_job( $job );

			return $this->process_agent_index_batch( $job );
		}

		$job['stage'] = 'agent_export';
		return $this->prepare_agent_export_archive( $job );
	}

	private function process_agent_index_batch( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$state = is_array( $job['index_state'] ?? null ) ? $job['index_state'] : array();
		$paths = $this->export_artifact_paths( $job['id'] );

		$db_path       = (string) ( $state['db_path'] ?? $paths['db'] );
		$db_gzip_path  = (string) ( $state['db_gzip_path'] ?? $paths['db_gzip'] );
		$manifest_path = (string) ( $state['manifest_path'] ?? $paths['manifest'] );
		$list_path     = (string) ( $state['list_path'] ?? $paths['list'] );

		if ( empty( $state['database_ready'] ) || ! file_exists( $db_path ) ) {
			if ( file_exists( $db_path ) ) {
				wp_delete_file( $db_path );
			}
			if ( file_exists( $manifest_path ) ) {
				wp_delete_file( $manifest_path );
			}
			if ( file_exists( $list_path ) ) {
				wp_delete_file( $list_path );
			}

			$job = $this->mark_job( $job, 'running', 'agent_exporting', 'Exporting database.' );
			$this->save_job( $job );
			$state['database_counts'] = $this->database_verification_counts();
			$this->export_database( $db_path, $job['id'] );

			$state['database_ready'] = true;
			$state['db_gzip_path']   = $db_gzip_path;
			$state['indexed_files']  = 0;
			$state['scan_stack']     = $this->initial_archive_scan_stack();
			$job['index_state']      = $state;
			$this->save_job( $job );
		}

		if ( ! empty( $state['database_ready'] ) ) {
			$this->assert_job_not_cancelled( $job );
			$state['db_gzip_path'] = $this->prepare_database_archive_artifact( $db_path, $db_gzip_path, $job['id'] ) ? $db_gzip_path : '';
			$job['index_state']    = $state;
			$this->save_job( $job );
		}

		$database_entry = $this->database_archive_entry( $db_path, (string) ( $state['db_gzip_path'] ?? '' ) );

		if ( empty( $state['manifest_ready'] ) || ! file_exists( $manifest_path ) ) {
			$manifest = $this->source_manifest( is_array( $state['database_counts'] ?? null ) ? $state['database_counts'] : array() );
			file_put_contents( $manifest_path, wp_json_encode( $manifest, JSON_PRETTY_PRINT ) );
			$job['manifest']          = $manifest;
			$state['manifest_ready']  = true;
			$job['index_state']       = $state;
			$this->save_job( $job );
		} elseif ( empty( $job['manifest'] ) ) {
			$manifest = json_decode( (string) file_get_contents( $manifest_path ), true );
			if ( is_array( $manifest ) ) {
				$job['manifest'] = $manifest;
			}
		}

		if ( empty( $state['initial_entries'] ) || ! file_exists( $list_path ) ) {
			$handle = fopen( $list_path, 'wb' );
			if ( ! $handle ) {
				throw new Exception( 'Unable to write archive file list.' );
			}

			$count = 0;
			fclose( $handle );

			$state['indexed_files']   = $count;
			$state['initial_entries'] = true;
			$state['scan_stack']      = $this->initial_archive_scan_stack();
			$job['index_state']       = $state;
			$this->save_job( $job );
		}

		if ( empty( $state['scan_stack'] ) || ! is_array( $state['scan_stack'] ) ) {
			$existing_count = $this->count_archive_file_list_entries( $list_path, true );
			if ( $existing_count > 0 ) {
				$handle = fopen( $list_path, 'wb' );
				if ( ! $handle ) {
					throw new Exception( 'Unable to reset archive file list for cursor recovery.' );
				}

				fclose( $handle );
				$state['indexed_files'] = 0;
			}

			$state['scan_stack']  = $this->initial_archive_scan_stack();
			$job['index_state']   = $state;
			$job                  = $this->mark_job( $job, 'running', 'agent_indexing', 'Recovering file index cursor.' );
			$this->save_job( $job );
		}

		$indexed_files          = max( 0, (int) ( $state['indexed_files'] ?? 0 ) );
		$state['indexed_files'] = $indexed_files;
		$job['index_state']     = $state;
		$job                    = $this->mark_job( $job, 'running', 'agent_indexing', $this->index_progress_message( $state['indexed_files'] ) );
		$this->save_job( $job );

		$handle = fopen( $list_path, 'ab' );
		if ( ! $handle ) {
			throw new Exception( 'Unable to append archive file list.' );
		}

		$deadline          = microtime( true ) + CMSVC_EXPORT_TASK_WINDOW_SECONDS;
		$progress_callback = function ( $indexed_files, $scan_stack = null ) use ( &$job, &$state ) {
			$state['indexed_files'] = $indexed_files;
			if ( is_array( $scan_stack ) ) {
				$state['scan_stack'] = $scan_stack;
			}
			$job['index_state']     = $state;
			$job                    = $this->mark_job( $job, 'running', 'agent_indexing', $this->index_progress_message( $indexed_files ) );
			$this->save_job( $job );
		};

		$result = $this->append_directory_archive_file_entries_from_stack(
			$handle,
			array( $this->base_work_dir() ),
			(array) $state['scan_stack'],
			$deadline,
			$progress_callback,
			(int) $state['indexed_files'],
			$job['id']
		);
		fclose( $handle );

		$state['indexed_files'] = (int) ( $result['indexed_files'] ?? $state['indexed_files'] );
		$state['scan_stack']    = $result['scan_stack'] ?? array();
		$job['index_state']     = $state;

		if ( ! empty( $result['complete'] ) ) {
			$handle = fopen( $list_path, 'ab' );
			if ( ! $handle ) {
				throw new Exception( 'Unable to append stream export final entries.' );
			}
			$this->write_archive_file_entry( $handle, $database_entry['source'], $database_entry['archive'] );
			$this->write_archive_file_entry( $handle, $manifest_path, 'manifest.json' );
			fclose( $handle );

			$summary                   = $this->archive_file_list_summary( $list_path );
			$job['file_list_path']     = $list_path;
			$job['stream_ready']       = true;
			$job['stream_file_count']  = (int) $summary['files'];
			$job['stream_total_bytes'] = (int) $summary['bytes'];
			$manifest                  = json_decode( (string) file_get_contents( $manifest_path ), true );
			$job['manifest']          = is_array( $manifest ) ? $manifest : $this->source_manifest( is_array( $state['database_counts'] ?? null ) ? $state['database_counts'] : array() );
			unset( $job['index_state'], $job['archive_state'], $job['stage_started_at'] );

			return $this->mark_job( $job, 'complete', 'agent_stream_ready', 'Source files and database export are ready for direct streaming.' );
		}

		return $this->mark_job( $job, 'running', 'agent_indexing', $this->index_progress_message( $state['indexed_files'] ) );
	}

	private function export_artifact_paths( $job_id ) {
		$dir = $this->work_dir( $job_id );

		return array(
			'dir'      => $dir,
			'db'       => $dir . '/database.sql',
			'db_gzip'  => $dir . '/database.sql.gz',
			'manifest' => $dir . '/manifest.json',
			'list'     => $dir . '/archive-files.jsonl',
			'archive'  => $this->archive_path_for_job( $job_id ),
		);
	}

	private function prepare_database_archive_artifact( $db_path, $db_gzip_path, $job_id = '' ) {
		if ( ! file_exists( $db_path ) || ! is_readable( $db_path ) || ! function_exists( 'gzopen' ) ) {
			return false;
		}

		clearstatcache( true, $db_path );
		clearstatcache( true, $db_gzip_path );

		if ( file_exists( $db_gzip_path ) && max( 0, (int) filesize( $db_gzip_path ) ) > 0 && filemtime( $db_gzip_path ) >= filemtime( $db_path ) ) {
			return true;
		}

		if ( file_exists( $db_gzip_path ) ) {
			wp_delete_file( $db_gzip_path );
		}

		$input  = @fopen( $db_path, 'rb' );
		$output = @gzopen( $db_gzip_path, 'wb6' );
		if ( false === $input || false === $output ) {
			if ( false !== $input ) {
				@fclose( $input );
			}
			if ( false !== $output ) {
				@gzclose( $output );
			}

			return false;
		}

		try {
			while ( ! feof( $input ) ) {
				$this->assert_job_not_cancelled( $job_id );
				$chunk = @fread( $input, CMSVC_GZIP_STREAM_CHUNK_BYTES );
				if ( false === $chunk ) {
					throw new Exception( 'Unable to read database export for gzip compression.' );
				}

				if ( '' === $chunk ) {
					continue;
				}

				if ( false === @gzwrite( $output, $chunk ) ) {
					throw new Exception( 'Unable to write compressed database export.' );
				}
			}
		} catch ( Exception $e ) {
			@fclose( $input );
			@gzclose( $output );
			if ( file_exists( $db_gzip_path ) ) {
				wp_delete_file( $db_gzip_path );
			}
			return false;
		}

		@fclose( $input );
		@gzclose( $output );
		clearstatcache( true, $db_gzip_path );

		return file_exists( $db_gzip_path ) && max( 0, (int) filesize( $db_gzip_path ) ) > 0;
	}

	private function database_archive_entry( $db_path, $db_gzip_path ) {
		if ( ! empty( $db_gzip_path ) && file_exists( $db_gzip_path ) && is_readable( $db_gzip_path ) ) {
			return array(
				'source'  => $db_gzip_path,
				'archive' => 'database.sql.gz',
			);
		}

		return array(
			'source'  => $db_path,
			'archive' => 'database.sql',
		);
	}

	private function write_archive_file_entry( $handle, $source, $archive ) {
		$source = wp_normalize_path( $source );
		if ( ! is_file( $source ) || ! is_readable( $source ) ) {
			return 0;
		}

		$stat = @stat( $source );
		if ( false === $stat ) {
			return 0;
		}

		fwrite(
			$handle,
			wp_json_encode(
				array(
					'source'  => $source,
					'archive' => ltrim( wp_normalize_path( $archive ), '/' ),
					'size'    => max( 0, (int) $stat['size'] ),
					'mtime'   => max( 0, (int) $stat['mtime'] ),
				)
			) . "\n"
		);

		return 1;
	}

	private function initial_archive_scan_stack() {
		return array(
			array(
				'dir'    => wp_normalize_path( ABSPATH ),
				'target' => 'site',
				'offset' => 0,
			),
		);
	}

	private function append_directory_archive_file_entries_from_stack( $handle, array $excluded_roots, array $scan_stack, $deadline, callable $progress_callback, $indexed_files, $job_id = '' ) {
		$excluded_roots      = array_map( 'wp_normalize_path', $excluded_roots );
		$excluded_root_globs = $this->settings_excluded_paths();
		$excluded_extensions = $this->settings_excluded_extensions();
		$indexed_files       = max( 0, (int) $indexed_files );
		$written_since_save  = 0;

		if ( empty( $scan_stack ) ) {
			$scan_stack = $this->initial_archive_scan_stack();
		}

		while ( ! empty( $scan_stack ) ) {
			$frame  = array_pop( $scan_stack );
			$dir    = wp_normalize_path( (string) ( $frame['dir'] ?? '' ) );
			$target = ltrim( wp_normalize_path( (string) ( $frame['target'] ?? 'site' ) ), '/' );
			$offset = max( 0, (int) ( $frame['offset'] ?? 0 ) );

			if ( '' === $dir || ! is_dir( $dir ) || ! is_readable( $dir ) ) {
				continue;
			}

			$entries = @scandir( $dir );
			if ( ! is_array( $entries ) ) {
				continue;
			}

			$total_entries = count( $entries );
			for ( $index = $offset; $index < $total_entries; $index++ ) {
				if ( '' !== $job_id ) {
					$this->assert_job_not_cancelled( $job_id );
				}

				if ( microtime( true ) >= $deadline ) {
					$frame['offset'] = $index;
					$scan_stack[]    = $frame;
					fflush( $handle );
					$progress_callback( $indexed_files, $scan_stack );

					return array(
						'complete'      => false,
						'indexed_files' => $indexed_files,
						'scan_stack'    => $scan_stack,
					);
				}

				$name = $entries[ $index ];
				if ( '.' === $name || '..' === $name ) {
					continue;
				}

				$path = wp_normalize_path( trailingslashit( $dir ) . $name );
				if ( 'wp-config.php' === basename( $path ) ) {
					continue;
				}

				foreach ( $excluded_roots as $excluded ) {
					if ( 0 === strpos( $path, $excluded ) ) {
						continue 2;
					}
				}

				$root     = wp_normalize_path( ABSPATH );
				$relative = ltrim( str_replace( $root, '', $path ), '/' );
				if ( '' !== $relative && $this->path_should_be_skipped_for_migration( $relative, $excluded_root_globs, $excluded_extensions ) ) {
					continue;
				}

				if ( ! is_readable( $path ) ) {
					continue;
				}

				if ( is_dir( $path ) ) {
					$frame['offset'] = $index + 1;
					$scan_stack[]    = $frame;
					$scan_stack[]    = array(
						'dir'    => $path,
						'target' => trailingslashit( $target ) . $name,
						'offset' => 0,
					);

					continue 2;
				}

				if ( is_file( $path ) ) {
					$indexed_files     += $this->write_archive_file_entry( $handle, $path, trailingslashit( $target ) . $name );
					$written_since_save++;

					if ( $written_since_save >= 100 ) {
						$frame['offset'] = $index + 1;
						$saved_stack     = $scan_stack;
						$saved_stack[]   = $frame;
						fflush( $handle );
						$progress_callback( $indexed_files, $saved_stack );
						$written_since_save = 0;
					}
				}
			}
		}

		fflush( $handle );
		$progress_callback( $indexed_files, array() );

		return array(
			'complete'      => true,
			'indexed_files' => $indexed_files,
			'scan_stack'    => array(),
		);
	}

	private function append_directory_archive_file_entries( $handle, $source, $target, array $excluded_roots, $skip_entries, $deadline, callable $progress_callback, $indexed_files ) {
		$source              = wp_normalize_path( $source );
		$excluded_roots      = array_map( 'wp_normalize_path', $excluded_roots );
		$excluded_root_globs = $this->settings_excluded_paths();
		$excluded_extensions = $this->settings_excluded_extensions();
		$skip_entries        = max( 0, (int) $skip_entries );
		$indexed_files       = max( 0, (int) $indexed_files );
		$seen_entries        = 0;
		$written_since_save  = 0;
		$directory_iterator  = new RecursiveDirectoryIterator(
			$source,
			FilesystemIterator::SKIP_DOTS | FilesystemIterator::CURRENT_AS_FILEINFO | FilesystemIterator::KEY_AS_PATHNAME
		);
		$filter              = new RecursiveCallbackFilterIterator(
			$directory_iterator,
			function ( $current ) use ( $source, $excluded_roots, $excluded_root_globs, $excluded_extensions ) {
				$path = wp_normalize_path( $current->getPathname() );

				if ( 'wp-config.php' === basename( $path ) ) {
					return false;
				}

				foreach ( $excluded_roots as $excluded ) {
					if ( 0 === strpos( $path, $excluded ) ) {
						return false;
					}
				}

				$relative = ltrim( str_replace( $source, '', $path ), '/' );
				if ( '' !== $relative && $this->path_should_be_skipped_for_migration( $relative, $excluded_root_globs, $excluded_extensions ) ) {
					return false;
				}

				return $current->isReadable();
			}
		);
		$files               = new RecursiveIteratorIterator(
			$filter,
			RecursiveIteratorIterator::SELF_FIRST,
			RecursiveIteratorIterator::CATCH_GET_CHILD
		);

		foreach ( $files as $file ) {
			$path = wp_normalize_path( $file->getPathname() );

			if ( $file->isDir() || 'wp-config.php' === basename( $path ) ) {
				continue;
			}

			foreach ( $excluded_roots as $excluded ) {
				if ( 0 === strpos( $path, $excluded ) ) {
					continue 2;
				}
			}

			$relative = ltrim( str_replace( $source, '', $path ), '/' );
			if ( '' === $relative || $this->path_should_be_skipped_for_migration( $relative, $excluded_root_globs, $excluded_extensions ) ) {
				continue;
			}

			if ( $seen_entries < $skip_entries ) {
				$seen_entries++;
				continue;
			}

			$indexed_files      += $this->write_archive_file_entry( $handle, $path, trailingslashit( $target ) . $relative );
			$seen_entries++;
			$written_since_save++;

			if ( $written_since_save >= 100 ) {
				fflush( $handle );
				$progress_callback( $indexed_files );
				$written_since_save = 0;
			}

			if ( microtime( true ) >= $deadline ) {
				fflush( $handle );
				$progress_callback( $indexed_files );
				return array(
					'complete'      => false,
					'indexed_files' => $indexed_files,
				);
			}
		}

		fflush( $handle );
		$progress_callback( $indexed_files );

		return array(
			'complete'      => true,
			'indexed_files' => $indexed_files,
		);
	}

	private function count_archive_file_list_entries( $list_path, $truncate_invalid = false ) {
		if ( ! file_exists( $list_path ) ) {
			return 0;
		}

		$handle = fopen( $list_path, 'rb' );
		if ( ! $handle ) {
			return 0;
		}

		$count            = 0;
		$last_good_offset = 0;

		while ( ! feof( $handle ) ) {
			$line = fgets( $handle );
			if ( false === $line ) {
				break;
			}

			$trimmed = trim( $line );
			if ( '' === $trimmed ) {
				$last_good_offset = ftell( $handle );
				continue;
			}

			$entry = json_decode( $trimmed, true );
			if ( ! is_array( $entry ) || empty( $entry['source'] ) || empty( $entry['archive'] ) ) {
				break;
			}

			$count++;
			$last_good_offset = ftell( $handle );
		}

		fclose( $handle );

		if ( $truncate_invalid ) {
			$current_size = filesize( $list_path );
			if ( false !== $current_size && $last_good_offset < $current_size ) {
				$write_handle = fopen( $list_path, 'c+b' );
				if ( $write_handle ) {
					ftruncate( $write_handle, $last_good_offset );
					fclose( $write_handle );
				}
			}
		}

		return $count;
	}

	private function archive_file_list_summary( $list_path ) {
		$summary = array(
			'files' => 0,
			'bytes' => 0,
		);

		if ( ! file_exists( $list_path ) ) {
			return $summary;
		}

		$handle = fopen( $list_path, 'rb' );
		if ( ! $handle ) {
			return $summary;
		}

		while ( ! feof( $handle ) ) {
			$line = fgets( $handle );
			if ( false === $line ) {
				break;
			}

			$entry = json_decode( trim( $line ), true );
			if ( ! is_array( $entry ) || empty( $entry['archive'] ) ) {
				continue;
			}

			$summary['files']++;
			if ( isset( $entry['size'] ) ) {
				$summary['bytes'] += max( 0, (int) $entry['size'] );
			}
		}

		fclose( $handle );

		return $summary;
	}

	private function archive_file_entry_at_offset( $list_path, $offset ) {
		if ( ! file_exists( $list_path ) ) {
			return null;
		}

		$handle = fopen( $list_path, 'rb' );
		if ( ! $handle ) {
			return null;
		}

		$offset = max( 0, (int) $offset );
		if ( $offset > 0 && -1 === fseek( $handle, $offset, SEEK_SET ) ) {
			fclose( $handle );
			return null;
		}

		$line = fgets( $handle );
		if ( false === $line ) {
			fclose( $handle );
			return null;
		}

		$next_offset = ftell( $handle );
		fclose( $handle );

		$entry = json_decode( trim( $line ), true );
		if ( ! is_array( $entry ) ) {
			$entry = null;
		}

		return array(
			'entry'       => $entry,
			'next_offset' => false === $next_offset ? $offset + strlen( $line ) : $next_offset,
		);
	}

	private function archive_file_list_offset_for_index( $list_path, $index ) {
		if ( ! file_exists( $list_path ) ) {
			return 0;
		}

		$handle = fopen( $list_path, 'rb' );
		if ( ! $handle ) {
			return 0;
		}

		$index  = max( 0, (int) $index );
		$offset = 0;
		for ( $line_index = 0; $line_index < $index; $line_index++ ) {
			if ( false === fgets( $handle ) ) {
				break;
			}

			$current = ftell( $handle );
			if ( false === $current ) {
				break;
			}

			$offset = $current;
		}

		fclose( $handle );

		return $offset;
	}

	private function archive_file_entry_at( $list_path, $index ) {
		$file = new SplFileObject( $list_path, 'rb' );
		$file->seek( max( 0, (int) $index ) );

		if ( $file->eof() ) {
			return null;
		}

		$line = trim( (string) $file->current() );
		if ( '' === $line ) {
			return null;
		}

		$entry = json_decode( $line, true );
		return is_array( $entry ) ? $entry : null;
	}

	private function index_progress_message( $indexed_files ) {
		return sprintf(
			'Indexing source files: %d files queued for direct streaming.',
			max( 0, (int) $indexed_files )
		);
	}

	public function import_archive_from_cli( $archive_path, array $source_context, $skip_email_domains ) {
		$archive_path = wp_normalize_path( $archive_path );
		$job_id       = $this->cli_job_id( 'archive_import', $archive_path . '|' . (string) ( $source_context['source_url'] ?? '' ) );

		$this->upsert_cli_job(
			$job_id,
			'destination_extract',
			array(
				'archive_path'          => $archive_path,
				'source_context'        => $source_context,
				'do_not_replace_emails' => $skip_email_domains,
			)
		);

		$this->run_cli_job_until_complete( $job_id );
	}

	private function source_manifest( array $database_counts = array() ) {
		global $wpdb;

		$uploads = wp_get_upload_dir();
		$database_counts = ! empty( $database_counts ) ? $this->sanitize_database_counts( $database_counts ) : $this->database_verification_counts( isset( $wpdb->prefix ) ? (string) $wpdb->prefix : '' );

		return array(
			'version'            => CMSVC_VERSION,
			'created_at'         => gmdate( 'c' ),
			'source_url'         => home_url(),
			'source_site_url'    => site_url(),
			'source_home_url'    => home_url(),
			'source_abspath'     => ABSPATH,
			'source_content_dir' => WP_CONTENT_DIR,
			'source_uploads_url' => $uploads['baseurl'] ?? '',
			'source_uploads_dir' => $uploads['basedir'] ?? '',
			'source_table_prefix' => isset( $wpdb->prefix ) ? (string) $wpdb->prefix : '',
			'source_database_counts' => $database_counts,
			'source_wp_config_defines' => $this->supported_wp_config_defines(),
		);
	}

	private function job_uses_stream_transport( array $job ) {
		return true;
	}

	private function source_stream_job_from_request( WP_REST_Request $request ) {
		$id  = sanitize_text_field( $request['id'] );
		$job = $this->job_by_id( $id );
		if ( empty( $job ) ) {
			return new WP_Error( 'cmsvc_not_found', 'Source stream job not found.', array( 'status' => 404 ) );
		}

		if ( ! $this->job_uses_stream_transport( $job ) || empty( $job['stream_ready'] ) ) {
			return new WP_Error( 'cmsvc_stream_not_ready', 'Source stream job is not ready yet.', array( 'status' => 409 ) );
		}

		$list_path = (string) ( $job['file_list_path'] ?? $this->export_artifact_paths( $id )['list'] );
		if ( '' === $list_path || ! file_exists( $list_path ) ) {
			return new WP_Error( 'cmsvc_stream_index_missing', 'Source stream index is missing.', array( 'status' => 404 ) );
		}

		$job['file_list_path'] = $list_path;
		return $job;
	}

	private function source_stream_entry_at_offset( array $job, $offset, $include_source = false ) {
		$list_path = (string) ( $job['file_list_path'] ?? $this->export_artifact_paths( $job['id'] )['list'] );
		$offset    = max( 0, (int) $offset );
		$result    = $this->archive_file_entry_at_offset( $list_path, $offset );

		if ( empty( $result ) || empty( $result['entry'] ) ) {
			return array(
				'complete' => true,
				'offset'   => $offset,
			);
		}

		$entry = $result['entry'];
		if ( ! $this->source_stream_entry_is_allowed( $job, $entry ) ) {
			throw new Exception( 'Source stream index contains an unsafe entry.' );
		}

		$source  = wp_normalize_path( (string) ( $entry['source'] ?? '' ) );
		$archive = ltrim( wp_normalize_path( (string) ( $entry['archive'] ?? '' ) ), '/' );
		$missing = ! is_file( $source ) || ! is_readable( $source );
		$size    = max( 0, (int) ( $entry['size'] ?? 0 ) );
		$mtime   = max( 0, (int) ( $entry['mtime'] ?? 0 ) );

		if ( ! $missing ) {
			clearstatcache( true, $source );
			$size  = max( 0, (int) filesize( $source ) );
			$mtime = max( 0, (int) filemtime( $source ) );
		}

		$payload = array(
			'archive' => $archive,
			'size'    => $size,
			'mtime'   => $mtime,
			'missing' => $missing,
		);

		if ( $include_source ) {
			$payload['source'] = $source;
		}

		return array(
			'complete'    => false,
			'offset'      => $offset,
			'next_offset' => max( $offset, (int) ( $result['next_offset'] ?? $offset ) ),
			'entry'       => $payload,
		);
	}

	private function source_stream_entry_is_allowed( array $job, array $entry ) {
		$source  = wp_normalize_path( (string) ( $entry['source'] ?? '' ) );
		$archive = ltrim( wp_normalize_path( (string) ( $entry['archive'] ?? '' ) ), '/' );
		if ( '' === $source || '' === $archive ) {
			return false;
		}

		if ( in_array( $archive, array( 'database.sql', 'database.sql.gz', 'manifest.json' ), true ) ) {
			$work_dir = trailingslashit( wp_normalize_path( $this->work_dir( $job['id'] ?? '' ) ) );
			return 0 === strpos( $source, $work_dir ) && basename( $source ) === basename( $archive );
		}

		if ( 0 !== strpos( $archive, 'site/' ) ) {
			return false;
		}

		$root = trailingslashit( wp_normalize_path( ABSPATH ) );
		if ( 0 !== strpos( $source, $root ) ) {
			return false;
		}

		$relative = ltrim( substr( $archive, 5 ), '/' );
		return '' !== $relative && ! $this->path_is_protected_for_migration( $relative );
	}

	private function send_source_stream_file_chunk( $source, $offset, $length, $total_size, $mtime ) {
		$source     = wp_normalize_path( $source );
		$offset     = max( 0, (int) $offset );
		$length     = max( 0, (int) $length );
		$total_size = max( 0, (int) $total_size );

		if ( '' === $source || ! is_file( $source ) || ! is_readable( $source ) ) {
			status_header( 404 );
			exit;
		}

		$handle = @fopen( $source, 'rb' );
		if ( false === $handle ) {
			status_header( 404 );
			exit;
		}

		if ( $offset > 0 && -1 === @fseek( $handle, $offset, SEEK_SET ) ) {
			@fclose( $handle );
			status_header( 416 );
			exit;
		}

		while ( ob_get_level() > 0 ) {
			@ob_end_clean();
		}

		nocache_headers();
		status_header( $offset > 0 || $length < $total_size ? 206 : 200 );
		header( 'Content-Type: application/octet-stream' );
		header( 'Content-Length: ' . $length );
		header( 'Content-Range: bytes ' . $offset . '-' . max( $offset, $offset + $length - 1 ) . '/' . $total_size );
		header( 'X-CMSVC-File-Size: ' . $total_size );
		header( 'X-CMSVC-File-Mtime: ' . max( 0, (int) $mtime ) );

		$remaining = $length;
		while ( $remaining > 0 && ! feof( $handle ) ) {
			$chunk = @fread( $handle, min( CMSVC_Archiver::READ_CHUNK_SIZE, $remaining ) );
			if ( false === $chunk || '' === $chunk ) {
				break;
			}

			echo $chunk;
			$remaining -= strlen( $chunk );
			@flush();
		}

		@fclose( $handle );
	}

	private function source_stream_bundle_path( array $job ) {
		$dir = $this->work_dir( $job['id'] ?? '' );
		wp_mkdir_p( $dir );
		return trailingslashit( $dir ) . 'stream-bundle-' . wp_generate_uuid4() . '.wpress';
	}

	private function create_source_stream_bundle( array $job, $offset, $max_bytes, $max_files, $bundle_path ) {
		$offset       = max( 0, (int) $offset );
		$max_bytes    = max( 1048576, (int) $max_bytes );
		$max_files    = max( 1, (int) $max_files );
		$current      = $offset;
		$files        = 0;
		$skipped      = 0;
		$bytes        = 0;
		$complete     = false;
		$blocked      = false;

		wp_mkdir_p( dirname( $bundle_path ) );
		if ( file_exists( $bundle_path ) ) {
			@unlink( $bundle_path );
		}

		$archive = new CMSVC_Compressor( $bundle_path );
		try {
			while ( ( $files + $skipped ) < $max_files ) {
				$this->assert_job_not_cancelled( $job );
				$entry_result = $this->source_stream_entry_at_offset( $job, $current, true );
				if ( ! empty( $entry_result['complete'] ) ) {
					$complete = true;
					break;
				}

				$entry       = is_array( $entry_result['entry'] ?? null ) ? $entry_result['entry'] : array();
				$next_offset = max( $current, (int) ( $entry_result['next_offset'] ?? $current ) );
				$source      = (string) ( $entry['source'] ?? '' );
				$archive_name = (string) ( $entry['archive'] ?? '' );
				$size        = max( 0, (int) ( $entry['size'] ?? 0 ) );

				if ( $next_offset <= $current ) {
					$blocked = true;
					break;
				}

				if ( ! empty( $entry['missing'] ) || '' === $source || '' === $archive_name || ! is_file( $source ) || ! is_readable( $source ) ) {
					$skipped++;
					$current = $next_offset;
					continue;
				}

				if ( $size > $max_bytes ) {
					$blocked = true;
					break;
				}

				if ( $files > 0 && $bytes + $size > $max_bytes ) {
					break;
				}

				$result = $archive->add_file( $source, $archive_name );
				if ( false === $result ) {
					$skipped++;
					$current = $next_offset;
					continue;
				}

				$files++;
				$bytes  += $size;
				$current = $next_offset;

				if ( $bytes >= $max_bytes ) {
					break;
				}
			}

			$archive->close( true );
		} catch ( Exception $e ) {
			try {
				$archive->close( false );
			} catch ( Exception $close_exception ) {
				// Preserve the original stream error.
			}
			if ( file_exists( $bundle_path ) ) {
				@unlink( $bundle_path );
			}
			throw $e;
		}

		clearstatcache( true, $bundle_path );
		return array(
			'offset'      => $offset,
			'next_offset' => $current,
			'files'       => $files,
			'skipped'     => $skipped,
			'bytes'       => $bytes,
			'complete'    => $complete,
			'blocked'     => $blocked,
			'bundle_size' => file_exists( $bundle_path ) ? max( 0, (int) filesize( $bundle_path ) ) : 0,
		);
	}

	private function send_source_stream_bundle( $bundle_path, array $result ) {
		clearstatcache( true, $bundle_path );
		if ( '' === $bundle_path || ! file_exists( $bundle_path ) || ! is_readable( $bundle_path ) ) {
			status_header( 404 );
			exit;
		}

		$handle = @fopen( $bundle_path, 'rb' );
		if ( false === $handle ) {
			status_header( 404 );
			exit;
		}

		while ( ob_get_level() > 0 ) {
			@ob_end_clean();
		}

		$size = max( 0, (int) filesize( $bundle_path ) );
		nocache_headers();
		status_header( 200 );
		header( 'Content-Type: application/octet-stream' );
		header( 'Content-Length: ' . $size );
		header( 'X-CMSVC-Offset: ' . max( 0, (int) ( $result['offset'] ?? 0 ) ) );
		header( 'X-CMSVC-Next-Offset: ' . max( 0, (int) ( $result['next_offset'] ?? 0 ) ) );
		header( 'X-CMSVC-Files: ' . max( 0, (int) ( $result['files'] ?? 0 ) ) );
		header( 'X-CMSVC-Skipped: ' . max( 0, (int) ( $result['skipped'] ?? 0 ) ) );
		header( 'X-CMSVC-Bytes: ' . max( 0, (int) ( $result['bytes'] ?? 0 ) ) );
		header( 'X-CMSVC-Complete: ' . ( ! empty( $result['complete'] ) ? '1' : '0' ) );

		while ( ! feof( $handle ) ) {
			$chunk = @fread( $handle, CMSVC_Archiver::READ_CHUNK_SIZE );
			if ( false === $chunk || '' === $chunk ) {
				break;
			}

			echo $chunk;
			@flush();
		}

		@fclose( $handle );
		@unlink( $bundle_path );
	}

	private function process_destination_stream_batch( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$extract_dir = $this->work_dir( $job['id'] ) . '/extract';
		wp_mkdir_p( $extract_dir );

		$state = is_array( $job['stream_state'] ?? null ) ? $job['stream_state'] : array();
		if ( empty( $state ) ) {
			$state = array(
				'list_offset'       => 0,
				'file_offset'       => 0,
				'file_index'        => 0,
				'transferred_files' => 0,
				'skipped_files'     => 0,
				'bytes_transferred' => 0,
			);
			$job = $this->append_job_debug_log(
				$job,
				'Destination direct stream prepared.',
				array(
					'extract_dir'      => $this->debug_directory_snapshot( $extract_dir ),
					'source_transfer' => $this->public_stream_source_transfer( $job ),
				)
			);
		}

		$started_at = microtime( true );
		$complete   = false;

		while ( microtime( true ) - $started_at < CMSVC_EXPORT_TASK_WINDOW_SECONDS ) {
			$this->assert_job_not_cancelled( $job );

			$entry_result = $this->fetch_source_stream_entry( $job, (int) $state['list_offset'] );
			if ( ! empty( $entry_result['complete'] ) ) {
				$complete = true;
				break;
			}

			$entry       = is_array( $entry_result['entry'] ?? null ) ? $entry_result['entry'] : array();
			$archive     = ltrim( wp_normalize_path( (string) ( $entry['archive'] ?? '' ) ), '/' );
			$entry_size  = max( 0, (int) ( $entry['size'] ?? 0 ) );
			$entry_mtime = max( 0, (int) ( $entry['mtime'] ?? time() ) );
			$target      = $this->import_extract_target( array( 'filename' => $archive ), $extract_dir );

			if ( '' === $archive || false === $target || ! empty( $entry['missing'] ) ) {
				$state = $this->advance_destination_stream_state( $state, $entry_result, 0, true );
				$job['stream_state'] = $state;
				$job = $this->mark_job( $job, 'running', 'destination_stream', $this->destination_stream_progress_message( $state ) );
				$this->save_job( $job );
				continue;
			}

			$file_offset = max( 0, (int) ( $state['file_offset'] ?? 0 ) );
			if ( 0 === $file_offset && $entry_size <= CMSVC_STREAM_BUNDLE_BYTES ) {
				$bundle_path = $this->destination_stream_bundle_path( $job );
				$bundle      = $this->download_source_stream_bundle( $job, (int) $state['list_offset'], $bundle_path );
				if ( ! empty( $bundle['progress'] ) ) {
					try {
						$extract = $this->extract_source_stream_bundle( $bundle_path, $extract_dir );
					} finally {
						@unlink( $bundle_path );
					}

					$state               = $this->advance_destination_stream_state_by_bundle( $state, $bundle, $extract );
					$job['stream_state'] = $state;
					$job                 = $this->mark_job( $job, 'running', 'destination_stream', $this->destination_stream_progress_message( $state ) );
					$this->save_job( $job );

					if ( ! empty( $bundle['complete'] ) ) {
						$complete = true;
						break;
					}

					continue;
				}

				@unlink( $bundle_path );
			}

			if ( 0 === $entry_size ) {
				$this->write_empty_stream_target( $target, $entry_mtime );
				$state = $this->advance_destination_stream_state( $state, $entry_result, 0, false );
				$job['stream_state'] = $state;
				$job = $this->mark_job( $job, 'running', 'destination_stream', $this->destination_stream_progress_message( $state ) );
				$this->save_job( $job );
				continue;
			}

			if ( $file_offset > $entry_size ) {
				$file_offset = 0;
			}
			if ( $file_offset > 0 && ( ! file_exists( $target ) || filesize( $target ) < $file_offset ) ) {
				$file_offset = file_exists( $target ) ? min( max( 0, (int) filesize( $target ) ), $entry_size ) : 0;
			}

			$source_transfer = $this->stream_source_transfer( $job );
			$chunk_size      = min( (int) $source_transfer['chunk_bytes'], $entry_size - $file_offset );
			$written         = $this->download_source_stream_chunk_to_target( $job, (int) $state['list_offset'], $file_offset, $chunk_size, $target, 0 === $file_offset );

			$file_offset += $written;
			$state['bytes_transferred'] = max( 0, (int) ( $state['bytes_transferred'] ?? 0 ) ) + $written;

			if ( $file_offset >= $entry_size ) {
				$this->finish_stream_target( $target, $entry_mtime );
				$state = $this->advance_destination_stream_state( $state, $entry_result, 0, false );
			} else {
				$state['file_offset'] = $file_offset;
			}

			$job['stream_state'] = $state;
			$job = $this->mark_job( $job, 'running', 'destination_stream', $this->destination_stream_progress_message( $state ) );
			$this->save_job( $job );
		}

		if ( ! $complete ) {
			return $this->mark_job( $job, 'running', 'destination_stream', $this->destination_stream_progress_message( $state ) );
		}

		unset( $job['stream_state'] );
		@unlink( $this->destination_stream_chunk_path( $job ) );

		$db_path      = $extract_dir . '/database.sql';
		$db_gzip_path = $extract_dir . '/database.sql.gz';
		clearstatcache( true, $db_path );
		clearstatcache( true, $db_gzip_path );

		$job = $this->append_job_debug_log(
			$job,
			'Destination direct stream complete.',
			array(
				'summary'    => $this->destination_database_debug_summary( $extract_dir, $db_path, $db_gzip_path ),
				'stream_end' => $state,
			)
		);

		if ( max( 0, (int) ( $state['skipped_files'] ?? 0 ) ) > 0 ) {
			$this->save_job( $job );
			throw new Exception(
				sprintf(
					'Destination stream skipped %d source files. Migration stopped because the destination would be incomplete.',
					max( 0, (int) ( $state['skipped_files'] ?? 0 ) )
				)
			);
		}

		if ( ! file_exists( $db_path ) && ! file_exists( $db_gzip_path ) ) {
			$this->save_job( $job );
			throw new Exception( 'Streamed migration is missing database.sql or database.sql.gz. ' . $this->destination_database_debug_summary( $extract_dir, $db_path, $db_gzip_path ) );
		}

		if ( ! file_exists( $db_path ) && file_exists( $db_gzip_path ) ) {
			return $this->mark_job( $job, 'running', 'destination_db_expand', 'Files streamed. Expanding compressed database export.' );
		}

		return $this->mark_job( $job, 'running', 'destination_db_import', 'Files streamed. Importing database.' );
	}

	private function stream_source_transfer( array $job ) {
		$source = is_array( $job['source_transfer'] ?? null ) ? $job['source_transfer'] : array();
		$source = array(
			'url'         => isset( $source['url'] ) ? esc_url_raw( (string) $source['url'] ) : '',
			'job_id'      => isset( $source['job_id'] ) ? sanitize_text_field( (string) $source['job_id'] ) : '',
			'site_key'    => isset( $source['site_key'] ) ? sanitize_text_field( (string) $source['site_key'] ) : '',
			'chunk_bytes' => isset( $source['chunk_bytes'] ) ? max( 1048576, min( CMSVC_STREAM_FILE_CHUNK_BYTES, (int) $source['chunk_bytes'] ) ) : CMSVC_STREAM_FILE_CHUNK_BYTES,
		);

		if ( '' === $source['url'] || '' === $source['job_id'] || '' === $source['site_key'] ) {
			throw new Exception( 'Destination stream source handoff is incomplete.' );
		}

		return $source;
	}

	private function public_stream_source_transfer( array $job ) {
		$source = $this->stream_source_transfer( $job );
		unset( $source['site_key'] );
		return $source;
	}

	private function source_stream_endpoint_url( array $job, $kind, array $query = array() ) {
		$source = $this->stream_source_transfer( $job );
		$base   = trailingslashit( $source['url'] ) . 'wp-json/cmsvc/v1/agent/stream/' . rawurlencode( $kind ) . '/' . rawurlencode( $source['job_id'] );

		return empty( $query ) ? $base : add_query_arg( $query, $base );
	}

	private function fetch_source_stream_entry( array $job, $list_offset ) {
		$source   = $this->stream_source_transfer( $job );
		$response = wp_remote_get(
			$this->source_stream_endpoint_url( $job, 'entry', array( 'offset' => max( 0, (int) $list_offset ) ) ),
			array(
				'timeout'     => 60,
				'redirection' => 3,
				'headers'     => array(
					'accept'       => 'application/json',
					'x-cmsvc-key'  => $source['site_key'],
					'user-agent'   => CMSVC_USER_AGENT,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new Exception( 'Unable to read source stream entry: ' . $response->get_error_message() );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = (string) wp_remote_retrieve_body( $response );
		if ( $code < 200 || $code >= 300 ) {
			throw new Exception( sprintf( 'Unable to read source stream entry: HTTP %d %s', $code, $this->summarize_remote_body( $body ) ) );
		}

		$payload = json_decode( $body, true );
		if ( ! is_array( $payload ) ) {
			throw new Exception( 'Source stream entry response was not valid JSON.' );
		}

		return $payload;
	}

	private function download_source_stream_bundle( array $job, $list_offset, $bundle_path ) {
		$source = $this->stream_source_transfer( $job );
		wp_mkdir_p( dirname( $bundle_path ) );
		if ( file_exists( $bundle_path ) ) {
			@unlink( $bundle_path );
		}

		$response = wp_remote_get(
			$this->source_stream_endpoint_url(
				$job,
				'bundle',
				array(
					'offset'    => max( 0, (int) $list_offset ),
					'max_bytes' => CMSVC_STREAM_BUNDLE_BYTES,
					'max_files' => CMSVC_STREAM_BUNDLE_MAX_FILES,
				)
			),
			array(
				'timeout'     => 600,
				'redirection' => 3,
				'stream'      => true,
				'filename'    => $bundle_path,
				'headers'     => array(
					'accept'       => 'application/octet-stream, application/json',
					'x-cmsvc-key'  => $source['site_key'],
					'user-agent'   => CMSVC_USER_AGENT,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			@unlink( $bundle_path );
			throw new Exception( 'Unable to download source stream bundle: ' . $response->get_error_message() );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			@unlink( $bundle_path );
			throw new Exception( sprintf( 'Unable to download source stream bundle: HTTP %d', $code ) );
		}

		$content_type = strtolower( (string) wp_remote_retrieve_header( $response, 'content-type' ) );
		if ( false === strpos( $content_type, 'application/octet-stream' ) ) {
			$payload = file_exists( $bundle_path ) ? json_decode( (string) file_get_contents( $bundle_path ), true ) : array();
			@unlink( $bundle_path );
			return is_array( $payload ) ? array_merge( $payload, array( 'progress' => false ) ) : array( 'progress' => false );
		}

		clearstatcache( true, $bundle_path );
		$downloaded = file_exists( $bundle_path ) ? max( 0, (int) filesize( $bundle_path ) ) : 0;
		$expected   = $this->remote_response_header_int( $response, 'content-length', 0 );
		if ( $expected > 0 && $downloaded !== $expected ) {
			@unlink( $bundle_path );
			throw new Exception( 'Downloaded source stream bundle size was invalid.' );
		}

		$files   = $this->remote_response_header_int( $response, 'x-cmsvc-files', 0 );
		$skipped = $this->remote_response_header_int( $response, 'x-cmsvc-skipped', 0 );
		if ( $files <= 0 && $skipped <= 0 ) {
			@unlink( $bundle_path );
			return array( 'progress' => false );
		}

		return array(
			'progress'    => true,
			'path'        => $bundle_path,
			'offset'      => $this->remote_response_header_int( $response, 'x-cmsvc-offset', max( 0, (int) $list_offset ) ),
			'next_offset' => $this->remote_response_header_int( $response, 'x-cmsvc-next-offset', max( 0, (int) $list_offset ) ),
			'files'       => $files,
			'skipped'     => $skipped,
			'bytes'       => $this->remote_response_header_int( $response, 'x-cmsvc-bytes', 0 ),
			'complete'    => '1' === (string) wp_remote_retrieve_header( $response, 'x-cmsvc-complete' ),
			'bundle_size' => $downloaded,
		);
	}

	private function extract_source_stream_bundle( $bundle_path, $extract_dir ) {
		$extractor = new CMSVC_Extractor( $bundle_path );
		$offset    = 0;
		$files     = 0;
		$skipped   = 0;
		$bytes     = 0;

		try {
			while ( true ) {
				$entry = $extractor->entry_at_offset( $offset );
				if ( empty( $entry ) ) {
					break;
				}

				$target = $this->import_extract_target( $entry, $extract_dir );
				if ( false === $target ) {
					$offset = max( $offset, (int) ( $entry['next_offset'] ?? $offset ) );
					$skipped++;
					continue;
				}

				$result = $extractor->extract_entry_chunk( $entry, $target, 0, PHP_INT_MAX );
				if ( empty( $result['complete'] ) ) {
					throw new Exception( 'Unable to extract a complete stream bundle entry.' );
				}

				$files++;
				$bytes += max( 0, (int) ( $entry['size'] ?? 0 ) );
				$offset = max( $offset, (int) ( $result['next_offset'] ?? $entry['next_offset'] ?? $offset ) );
			}
		} finally {
			$extractor->close();
		}

		return array(
			'files'   => $files,
			'skipped' => $skipped,
			'bytes'   => $bytes,
		);
	}

	private function download_source_stream_chunk( array $job, $entry_offset, $file_offset, $length, $chunk_path ) {
		$source = $this->stream_source_transfer( $job );
		$length = max( 1, min( (int) $source['chunk_bytes'], (int) $length ) );
		wp_mkdir_p( dirname( $chunk_path ) );
		if ( file_exists( $chunk_path ) ) {
			@unlink( $chunk_path );
		}

		$response = wp_remote_get(
			$this->source_stream_endpoint_url(
				$job,
				'file',
				array(
					'entry_offset' => max( 0, (int) $entry_offset ),
					'offset'       => max( 0, (int) $file_offset ),
					'length'       => $length,
				)
			),
			array(
				'timeout'     => 300,
				'redirection' => 3,
				'stream'      => true,
				'filename'    => $chunk_path,
				'headers'     => array(
					'accept'       => 'application/octet-stream',
					'x-cmsvc-key'  => $source['site_key'],
					'user-agent'   => CMSVC_USER_AGENT,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			@unlink( $chunk_path );
			throw new Exception( 'Unable to download source stream chunk: ' . $response->get_error_message() );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code && 206 !== $code ) {
			@unlink( $chunk_path );
			throw new Exception( sprintf( 'Unable to download source stream chunk: HTTP %d', $code ) );
		}

		clearstatcache( true, $chunk_path );
		$downloaded = file_exists( $chunk_path ) ? max( 0, (int) filesize( $chunk_path ) ) : 0;
		if ( $downloaded !== $length ) {
			@unlink( $chunk_path );
			throw new Exception( 'Downloaded source stream chunk size was invalid.' );
		}

		return $downloaded;
	}

	private function download_source_stream_chunk_to_target( array $job, $entry_offset, $file_offset, $length, $target, $truncate ) {
		if ( function_exists( 'curl_init' ) ) {
			return $this->download_source_stream_chunk_to_target_with_curl( $job, $entry_offset, $file_offset, $length, $target, $truncate );
		}

		$chunk_path = $this->destination_stream_chunk_path( $job );
		$downloaded = $this->download_source_stream_chunk( $job, $entry_offset, $file_offset, $length, $chunk_path );
		$written    = $this->write_stream_chunk_to_target( $chunk_path, $target, $file_offset, $truncate );
		@unlink( $chunk_path );

		if ( $written !== $downloaded ) {
			throw new Exception( 'Destination stream chunk write size did not match downloaded size.' );
		}

		return $written;
	}

	private function download_source_stream_chunk_to_target_with_curl( array $job, $entry_offset, $file_offset, $length, $target, $truncate ) {
		$source = $this->stream_source_transfer( $job );
		$length = max( 1, min( (int) $source['chunk_bytes'], (int) $length ) );
		$directory = dirname( $target );
		if ( ! is_dir( $directory ) ) {
			wp_mkdir_p( $directory );
		}

		$output = @fopen( $target, 'c+b' );
		if ( false === $output ) {
			throw new Exception( sprintf( 'Unable to write streamed file: %s', $target ) );
		}

		if ( $truncate && ! @ftruncate( $output, 0 ) ) {
			@fclose( $output );
			throw new Exception( sprintf( 'Unable to reset streamed file: %s', $target ) );
		}

		if ( -1 === @fseek( $output, max( 0, (int) $file_offset ), SEEK_SET ) ) {
			@fclose( $output );
			throw new Exception( sprintf( 'Unable to resume streamed file: %s', $target ) );
		}

		$url = $this->source_stream_endpoint_url(
			$job,
			'file',
			array(
				'entry_offset' => max( 0, (int) $entry_offset ),
				'offset'       => max( 0, (int) $file_offset ),
				'length'       => $length,
			)
		);

		$curl = curl_init( $url );
		if ( false === $curl ) {
			@fclose( $output );
			throw new Exception( 'Unable to initialize source stream download.' );
		}

		$options = array(
			CURLOPT_FILE           => $output,
			CURLOPT_CONNECTTIMEOUT => 30,
			CURLOPT_TIMEOUT        => 600,
			CURLOPT_USERAGENT      => CMSVC_USER_AGENT,
			CURLOPT_HTTPHEADER     => array(
				'Accept: application/octet-stream',
				'X-CMSVC-Key: ' . $source['site_key'],
			),
		);
		if ( ! ini_get( 'open_basedir' ) ) {
			$options[ CURLOPT_FOLLOWLOCATION ] = true;
			$options[ CURLOPT_MAXREDIRS ]      = 3;
		}

		curl_setopt_array( $curl, $options );

		$ok         = curl_exec( $curl );
		$error      = curl_error( $curl );
		$code_info  = defined( 'CURLINFO_RESPONSE_CODE' ) ? CURLINFO_RESPONSE_CODE : CURLINFO_HTTP_CODE;
		$code       = (int) curl_getinfo( $curl, $code_info );
		$downloaded = (int) round( (float) curl_getinfo( $curl, CURLINFO_SIZE_DOWNLOAD ) );
		curl_close( $curl );
		@fclose( $output );

		if ( ! $ok ) {
			throw new Exception( 'Unable to download source stream chunk: ' . $error );
		}

		if ( 200 !== $code && 206 !== $code ) {
			throw new Exception( sprintf( 'Unable to download source stream chunk: HTTP %d', $code ) );
		}

		if ( $downloaded !== $length ) {
			throw new Exception( 'Downloaded source stream chunk size was invalid.' );
		}

		return $downloaded;
	}

	private function write_stream_chunk_to_target( $chunk_path, $target, $offset, $truncate ) {
		$directory = dirname( $target );
		if ( ! is_dir( $directory ) ) {
			wp_mkdir_p( $directory );
		}

		$input = @fopen( $chunk_path, 'rb' );
		if ( false === $input ) {
			throw new Exception( 'Unable to read downloaded stream chunk.' );
		}

		$output = @fopen( $target, 'c+b' );
		if ( false === $output ) {
			@fclose( $input );
			throw new Exception( sprintf( 'Unable to write streamed file: %s', $target ) );
		}

		if ( $truncate && ! @ftruncate( $output, 0 ) ) {
			@fclose( $input );
			@fclose( $output );
			throw new Exception( sprintf( 'Unable to reset streamed file: %s', $target ) );
		}

		if ( -1 === @fseek( $output, max( 0, (int) $offset ), SEEK_SET ) ) {
			@fclose( $input );
			@fclose( $output );
			throw new Exception( sprintf( 'Unable to resume streamed file: %s', $target ) );
		}

		$written_total = 0;
		while ( ! feof( $input ) ) {
			$chunk = @fread( $input, CMSVC_Archiver::READ_CHUNK_SIZE );
			if ( false === $chunk ) {
				@fclose( $input );
				@fclose( $output );
				throw new Exception( 'Unable to read downloaded stream chunk.' );
			}

			if ( '' === $chunk ) {
				break;
			}

			$written = @fwrite( $output, $chunk );
			if ( false === $written || strlen( $chunk ) !== $written ) {
				@fclose( $input );
				@fclose( $output );
				throw new Exception( sprintf( 'Unable to write streamed contents: %s', $target ) );
			}

			$written_total += strlen( $chunk );
		}

		@fclose( $input );
		@fclose( $output );

		return $written_total;
	}

	private function write_empty_stream_target( $target, $mtime ) {
		$directory = dirname( $target );
		if ( ! is_dir( $directory ) ) {
			wp_mkdir_p( $directory );
		}

		$handle = @fopen( $target, 'wb' );
		if ( false === $handle ) {
			throw new Exception( sprintf( 'Unable to write empty streamed file: %s', $target ) );
		}

		@fclose( $handle );
		$this->finish_stream_target( $target, $mtime );
	}

	private function finish_stream_target( $target, $mtime ) {
		@touch( $target, max( 1, (int) $mtime ) );
		@chmod( $target, defined( 'FS_CHMOD_FILE' ) ? FS_CHMOD_FILE : 0644 );
	}

	private function destination_stream_chunk_path( array $job ) {
		return $this->work_dir( $job['id'] ) . '/stream-chunk.tmp';
	}

	private function destination_stream_bundle_path( array $job ) {
		return $this->work_dir( $job['id'] ) . '/stream-bundle.tmp';
	}

	private function advance_destination_stream_state( array $state, array $entry_result, $file_offset = 0, $skipped = false ) {
		$state['list_offset'] = max( 0, (int) ( $entry_result['next_offset'] ?? $state['list_offset'] ?? 0 ) );
		$state['file_offset'] = max( 0, (int) $file_offset );
		$state['file_index']  = max( 0, (int) ( $state['file_index'] ?? 0 ) ) + 1;

		if ( $skipped ) {
			$state['skipped_files'] = max( 0, (int) ( $state['skipped_files'] ?? 0 ) ) + 1;
		} else {
			$state['transferred_files'] = max( 0, (int) ( $state['transferred_files'] ?? 0 ) ) + 1;
		}

		return $state;
	}

	private function advance_destination_stream_state_by_bundle( array $state, array $bundle, array $extract ) {
		$transferred = max( 0, (int) ( $extract['files'] ?? 0 ) );
		$skipped     = max( 0, (int) ( $bundle['skipped'] ?? 0 ) ) + max( 0, (int) ( $extract['skipped'] ?? 0 ) );

		$state['list_offset']       = max( (int) ( $state['list_offset'] ?? 0 ), (int) ( $bundle['next_offset'] ?? 0 ) );
		$state['file_offset']       = 0;
		$state['file_index']        = max( 0, (int) ( $state['file_index'] ?? 0 ) ) + $transferred + $skipped;
		$state['transferred_files'] = max( 0, (int) ( $state['transferred_files'] ?? 0 ) ) + $transferred;
		$state['skipped_files']     = max( 0, (int) ( $state['skipped_files'] ?? 0 ) ) + $skipped;
		$state['bytes_transferred'] = max( 0, (int) ( $state['bytes_transferred'] ?? 0 ) ) + max( 0, (int) ( $extract['bytes'] ?? $bundle['bytes'] ?? 0 ) );

		return $state;
	}

	private function destination_stream_progress_message( array $state ) {
		return sprintf(
			'Streaming files directly: %d files, %s MB transferred.',
			max( 0, (int) ( $state['transferred_files'] ?? 0 ) ),
			number_format_i18n( max( 0, (int) ( $state['bytes_transferred'] ?? 0 ) ) / 1048576, 2 )
		);
	}

	private function remote_response_header_int( $response, $name, $default = 0 ) {
		$value = wp_remote_retrieve_header( $response, $name );
		if ( is_array( $value ) ) {
			$value = reset( $value );
		}

		if ( null === $value || '' === $value || ! is_numeric( $value ) ) {
			return max( 0, (int) $default );
		}

		return max( 0, (int) $value );
	}

	private function summarize_remote_body( $body ) {
		$body = trim( wp_strip_all_tags( (string) $body ) );
		if ( '' === $body ) {
			return '';
		}

		return substr( $body, 0, 300 );
	}

	private function process_destination_extract_batch( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$archive_path = (string) ( $job['archive_path'] ?? '' );
		if ( '' === $archive_path || ! file_exists( $archive_path ) ) {
			throw new Exception( 'Archive not found on destination.' );
		}

		$extract_dir = $this->work_dir( $job['id'] ) . '/extract';
		wp_mkdir_p( $extract_dir );

		$state = is_array( $job['extract_state'] ?? null ) ? $job['extract_state'] : array();
		$job   = $this->append_job_debug_log(
			$job,
			'Destination extract batch starting.',
			array(
				'archive'       => $this->debug_file_snapshot( $archive_path ),
				'extract_dir'   => $this->debug_directory_snapshot( $extract_dir ),
				'extract_state' => $state,
			)
		);
		if ( empty( $state['validated'] ) ) {
			$extractor = new CMSVC_Extractor( $archive_path );
			$is_valid  = $extractor->is_valid();
			$extractor->close();
			if ( ! $is_valid ) {
				throw new Exception( 'Archive format is invalid.' );
			}

			$state = array(
				'validated'       => true,
				'archive_offset'  => 0,
				'file_offset'     => 0,
				'extracted_files' => 0,
			);
		}

		$extractor     = new CMSVC_Extractor( $archive_path );
		$archive_offset = max( 0, (int) ( $state['archive_offset'] ?? 0 ) );
		$file_offset    = max( 0, (int) ( $state['file_offset'] ?? 0 ) );
		$extracted_files = max( 0, (int) ( $state['extracted_files'] ?? 0 ) );
		$started_at     = microtime( true );

		try {
			while ( microtime( true ) - $started_at < CMSVC_EXPORT_TASK_WINDOW_SECONDS ) {
				$this->assert_job_not_cancelled( $job );
				$entry = $extractor->entry_at_offset( $archive_offset );
				if ( empty( $entry ) ) {
					break;
				}

				$target = $this->import_extract_target( $entry, $extract_dir );
				if ( false === $target ) {
					$archive_offset = (int) $entry['next_offset'];
					$file_offset    = 0;
					$state          = array(
						'validated'       => true,
						'archive_offset'  => $archive_offset,
						'file_offset'     => $file_offset,
						'extracted_files' => $extracted_files,
					);
					$job['extract_state'] = $state;
					$this->save_job( $job );
					continue;
				}

				$result = $extractor->extract_entry_chunk( $entry, $target, $file_offset, CMSVC_IMPORT_EXTRACT_CHUNK_BYTES );
				$file_offset = max( 0, (int) ( $result['source_offset'] ?? 0 ) );
				if ( ! empty( $result['complete'] ) ) {
					$archive_offset = (int) ( $result['next_offset'] ?? $entry['next_offset'] );
					$file_offset    = 0;
					$extracted_files++;
				}

				$state = array(
					'validated'       => true,
					'archive_offset'  => $archive_offset,
					'file_offset'     => $file_offset,
					'extracted_files' => $extracted_files,
				);
				$job['extract_state'] = $state;
				$job                  = $this->mark_job( $job, 'running', 'destination_extract', $this->destination_extract_progress_message( $extracted_files ) );
				$this->save_job( $job );
			}
		} finally {
			$extractor->close();
		}

		$db_path      = $extract_dir . '/database.sql';
		$db_gzip_path = $extract_dir . '/database.sql.gz';
		clearstatcache( true, $db_path );
		clearstatcache( true, $db_gzip_path );
		if ( ! file_exists( $db_path ) && ! file_exists( $db_gzip_path ) ) {
			$job = $this->append_job_debug_log(
				$job,
				'Destination extract finished current pass without a database export artifact.',
				array(
					'extract_state' => $state,
					'summary'       => $this->destination_database_debug_summary( $extract_dir, $db_path, $db_gzip_path ),
				)
			);
			$this->save_job( $job );
			throw new Exception( 'Archive is missing database.sql or database.sql.gz. ' . $this->destination_database_debug_summary( $extract_dir, $db_path, $db_gzip_path ) );
		}

		$next_entry = $this->archive_next_entry_at_offset( $archive_path, $archive_offset );
		$job        = $this->append_job_debug_log(
			$job,
			'Destination extract batch finished current pass.',
			array(
				'extract_state'    => $state,
				'file_offset'      => $file_offset,
				'next_entry'       => is_array( $next_entry )
					? array(
						'filename'    => (string) ( $next_entry['filename'] ?? '' ),
						'next_offset' => (int) ( $next_entry['next_offset'] ?? 0 ),
					)
					: null,
				'database_sql'     => $this->debug_file_snapshot( $db_path ),
				'database_sql_gz'  => $this->debug_file_snapshot( $db_gzip_path ),
				'manifest'         => $this->debug_file_snapshot( $extract_dir . '/manifest.json' ),
				'extract_dir'      => $this->debug_directory_snapshot( $extract_dir ),
			)
		);
		if ( null === $next_entry && 0 === $file_offset ) {
			unset( $job['extract_state'] );
			if ( ! file_exists( $db_path ) && file_exists( $db_gzip_path ) ) {
				$job = $this->append_job_debug_log(
					$job,
					'Destination extract complete; compressed database export detected.',
					array(
						'summary' => $this->destination_database_debug_summary( $extract_dir, $db_path, $db_gzip_path ),
					)
				);
				return $this->mark_job( $job, 'running', 'destination_db_expand', 'Archive extracted. Expanding compressed database export.' );
			}
			$job = $this->append_job_debug_log(
				$job,
				'Destination extract complete; database import can begin.',
				array(
					'summary' => $this->destination_database_debug_summary( $extract_dir, $db_path, $db_gzip_path ),
				)
			);
			return $this->mark_job( $job, 'running', 'destination_db_import', 'Archive extracted. Importing database.' );
		}

		return $this->mark_job( $job, 'running', 'destination_extract', $this->destination_extract_progress_message( $extracted_files ) );
	}

	private function process_destination_database_import_batch( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$extract_dir = $this->work_dir( $job['id'] ) . '/extract';
		$db_path     = $extract_dir . '/database.sql';
		$db_gzip_path = $extract_dir . '/database.sql.gz';
		$state       = is_array( $job['db_import_state'] ?? null ) ? $job['db_import_state'] : array();
		clearstatcache( true, $db_path );
		clearstatcache( true, $db_gzip_path );
		$job = $this->append_job_debug_log(
			$job,
			'Destination database import preflight.',
			array(
				'database_sql'    => $this->debug_file_snapshot( $db_path ),
				'database_sql_gz' => $this->debug_file_snapshot( $db_gzip_path ),
				'extract_dir'     => $this->debug_directory_snapshot( $extract_dir ),
				'db_import_state' => $state,
			)
		);
		if ( ! file_exists( $db_path ) ) {
			if ( file_exists( $db_gzip_path ) ) {
				$job = $this->append_job_debug_log(
					$job,
					'database.sql is missing but database.sql.gz exists; resuming compressed database expansion.',
					array(
						'summary' => $this->destination_database_debug_summary( $extract_dir, $db_path, $db_gzip_path ),
					)
				);
				return $this->mark_job( $job, 'running', 'destination_db_expand', 'database.sql was missing but database.sql.gz is present. Resuming expansion.' );
			}

			$job = $this->append_job_debug_log(
				$job,
				'Destination database import cannot start because no extracted database export was found.',
				array(
					'summary' => $this->destination_database_debug_summary( $extract_dir, $db_path, $db_gzip_path ),
				)
			);
			$this->save_job( $job );
			throw new Exception( 'Database export was not extracted. ' . $this->destination_database_debug_summary( $extract_dir, $db_path, $db_gzip_path ) );
		}

		$source_context = $this->import_source_context( $job, $extract_dir );
		$skip_emails    = ! empty( $job['do_not_replace_emails'] );
		$db_size        = max( 0, (int) filesize( $db_path ) );
		$use_async_runner = $this->should_use_async_database_import_runner( $db_path, $db_size );

		if ( empty( $job['destination_settings_snapshot'] ) ) {
			$job['destination_settings_snapshot'] = $this->settings();
		}

		if ( ! $use_async_runner && $this->can_use_async_database_import_runner() && $db_size > 0 && $db_size < CMSVC_ASYNC_IMPORT_MIN_BYTES ) {
			$job = $this->append_job_debug_log(
				$job,
				'Using inline database import because the extracted SQL file is below the async runner threshold.',
				array(
					'database_sql'        => $this->debug_file_snapshot( $db_path ),
					'async_min_bytes'     => CMSVC_ASYNC_IMPORT_MIN_BYTES,
					'database_sql_bytes'  => $db_size,
				)
			);
		}

		if ( $use_async_runner ) {
			if ( empty( $state['target_context'] ) || ! is_array( $state['target_context'] ) ) {
				$uploads = wp_get_upload_dir();
				$state['target_context'] = array(
					'site_url'    => site_url(),
					'home_url'    => home_url(),
					'abspath'     => ABSPATH,
					'content_dir' => WP_CONTENT_DIR,
					'uploads'     => array(
						'basedir' => $uploads['basedir'] ?? '',
						'baseurl' => $uploads['baseurl'] ?? '',
					),
				);
			}

			if ( empty( $state['async_runner_started'] ) ) {
				$state['async_runner_started'] = true;
				$state['runner_status']        = 'starting';
				$state['file_size']           = $db_size;
				$state['offset']              = 0;
				$state['query_buffer']        = '';
				$state['started']             = false;
				$state['bytes_imported']      = 0;
				$job['db_import_state']       = $state;
				$job['async_runner_active']   = true;
				$job                          = $this->append_job_debug_log(
					$job,
					'Launching detached database import runner.',
					array(
						'database_sql'    => $this->debug_file_snapshot( $db_path ),
						'db_import_state' => $state,
					)
				);
				$job                          = $this->mark_job( $job, 'running', 'destination_db_import', 'Starting detached database import runner.' );
				$this->save_job( $job );
				try {
					$this->launch_async_database_import_runner( $job['id'] );
				} catch ( Exception $e ) {
					$job['async_runner_active'] = false;
					$state['runner_status']     = 'failed';
					$job['db_import_state']     = $state;
					$this->save_job( $job );
					throw $e;
				}
				return $job;
			}

			$latest_jobs = $this->jobs();
			$latest_job  = $latest_jobs[ $job['id'] ] ?? $job;

			if ( 'failed' === ( $latest_job['status'] ?? '' ) ) {
				throw new Exception( (string) ( $latest_job['message'] ?? 'Database import failed.' ) );
			}

			return $latest_job;
		}

		if ( empty( $state['mode'] ) ) {
			$uploads = wp_get_upload_dir();
			$state = array(
				'mode'          => $this->can_use_native_mysql_import() ? 'mysql' : 'php',
				'offset'        => 0,
				'query_buffer'  => '',
				'started'       => false,
				'bytes_imported' => 0,
				'target_context' => array(
					'site_url'   => site_url(),
					'home_url'   => home_url(),
					'abspath'    => ABSPATH,
					'content_dir' => WP_CONTENT_DIR,
					'uploads'    => array(
						'basedir' => $uploads['basedir'] ?? '',
						'baseurl' => $uploads['baseurl'] ?? '',
					),
				),
			);
		}

		$rewrite_context                     = $source_context;
		$rewrite_context['__target_context'] = $state['target_context'] ?? array();

		if ( 'mysql' === $state['mode'] ) {
			$result = $this->import_database_sql_batch_with_mysql_client( $job, $db_path, $rewrite_context, $skip_emails, $state );
		} else {
			$result = $this->import_database_sql_batch_with_php( $job, $db_path, $rewrite_context, $skip_emails, $state );
		}

		$job['db_import_state'] = $result['state'];
		$job                    = $this->mark_job(
			$job,
			'running',
			'destination_db_import',
			$this->destination_database_progress_message( (int) $result['state']['bytes_imported'], (int) $result['state']['file_size'] )
		);
		$job = $this->preserve_destination_agent_state( $job );
		$this->save_job( $job );

		if ( empty( $result['complete'] ) ) {
			return $job;
		}

		unset( $job['db_import_state'] );
		$job = $this->normalize_destination_table_prefix( $job, $source_context );
		if ( $this->can_run_shell_commands() && $this->shell_binary_exists( 'wp' ) ) {
			$job = $this->run_destination_url_search_replace( $job, $source_context, $skip_emails );
		}
		return $this->mark_job( $job, 'running', 'destination_finalize', 'Database imported. Finalizing destination state.' );
	}

	private function process_destination_database_expand_batch( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$extract_dir  = $this->work_dir( $job['id'] ) . '/extract';
		$db_gzip_path = $extract_dir . '/database.sql.gz';
		$db_path      = $extract_dir . '/database.sql';
		$state        = is_array( $job['db_expand_state'] ?? null ) ? $job['db_expand_state'] : array();
		clearstatcache( true, $db_path );
		clearstatcache( true, $db_gzip_path );
		$job = $this->append_job_debug_log(
			$job,
			'Destination database expand preflight.',
			array(
				'database_sql'    => $this->debug_file_snapshot( $db_path ),
				'database_sql_gz' => $this->debug_file_snapshot( $db_gzip_path ),
				'extract_dir'     => $this->debug_directory_snapshot( $extract_dir ),
				'db_expand_state' => $state,
			)
		);

		if ( ! file_exists( $db_gzip_path ) ) {
			if ( file_exists( $db_path ) ) {
				$job = $this->append_job_debug_log(
					$job,
					'Compressed database export is already expanded; continuing with database import.',
					array(
						'summary' => $this->destination_database_debug_summary( $extract_dir, $db_path, $db_gzip_path ),
					)
				);
				return $this->mark_job( $job, 'running', 'destination_db_import', 'Compressed database already expanded. Importing database.' );
			}

			$job = $this->append_job_debug_log(
				$job,
				'Compressed database expansion cannot continue because neither database.sql.gz nor database.sql is present.',
				array(
					'summary' => $this->destination_database_debug_summary( $extract_dir, $db_path, $db_gzip_path ),
				)
			);
			$this->save_job( $job );
			throw new Exception( 'Compressed database export was not extracted. ' . $this->destination_database_debug_summary( $extract_dir, $db_path, $db_gzip_path ) );
		}

		if ( ! function_exists( 'gzopen' ) ) {
			throw new Exception( 'PHP zlib support is required to expand database.sql.gz on the destination.' );
		}

		$compressed_size = max( 0, (int) filesize( $db_gzip_path ) );
		$offset          = max( 0, (int) ( $state['offset'] ?? 0 ) );
		$started_at      = microtime( true );
		$complete        = false;

		$gzip_handle = @gzopen( $db_gzip_path, 'rb' );
		if ( false === $gzip_handle ) {
			throw new Exception( 'Unable to open compressed database export.' );
		}

		$target_handle = @fopen( $db_path, $offset > 0 ? 'c+b' : 'wb' );
		if ( false === $target_handle ) {
			@gzclose( $gzip_handle );
			throw new Exception( 'Unable to expand database export to database.sql.' );
		}

		try {
			if ( $offset > 0 ) {
				if ( -1 === @fseek( $target_handle, $offset, SEEK_SET ) ) {
					throw new Exception( 'Unable to resume expanded database.sql.' );
				}

				if ( 0 !== @gzseek( $gzip_handle, $offset ) ) {
					throw new Exception( 'Unable to resume compressed database expansion.' );
				}
			}

			while ( microtime( true ) - $started_at < CMSVC_EXPORT_TASK_WINDOW_SECONDS && ! gzeof( $gzip_handle ) ) {
				$this->assert_job_not_cancelled( $job );
				$chunk = @gzread( $gzip_handle, CMSVC_GZIP_STREAM_CHUNK_BYTES );
				if ( false === $chunk ) {
					throw new Exception( 'Unable to read compressed database export.' );
				}

				if ( '' === $chunk ) {
					break;
				}

				$written = @fwrite( $target_handle, $chunk );
				if ( false === $written || strlen( $chunk ) !== $written ) {
					throw new Exception( 'Unable to write expanded database export.' );
				}

				$offset += strlen( $chunk );
				$job['db_expand_state'] = array(
					'offset'          => $offset,
					'compressed_size' => $compressed_size,
				);
				$job = $this->mark_job( $job, 'running', 'destination_db_expand', $this->destination_database_expand_progress_message( $offset, $compressed_size ) );
				$this->save_job( $job );
			}

			$complete = gzeof( $gzip_handle );
		} finally {
			@fclose( $target_handle );
			@gzclose( $gzip_handle );
		}

		if ( $complete ) {
			unset( $job['db_expand_state'] );
			wp_delete_file( $db_gzip_path );
			clearstatcache( true, $db_path );
			clearstatcache( true, $db_gzip_path );
			$job = $this->append_job_debug_log(
				$job,
				'Compressed database expansion complete.',
				array(
					'database_sql'    => $this->debug_file_snapshot( $db_path ),
					'database_sql_gz' => $this->debug_file_snapshot( $db_gzip_path ),
					'summary'         => $this->destination_database_debug_summary( $extract_dir, $db_path, $db_gzip_path ),
				)
			);
			return $this->mark_job( $job, 'running', 'destination_db_import', 'Compressed database expanded. Importing database.' );
		}

		return $this->mark_job( $job, 'running', 'destination_db_expand', $this->destination_database_expand_progress_message( $offset, $compressed_size ) );
	}

	public function run_async_database_import_job( $job_id ) {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 );
		}

		$job_id = sanitize_text_field( (string) $job_id );
		if ( '' === $job_id ) {
			throw new Exception( 'Missing import job ID.' );
		}

		$jobs = $this->jobs();
		if ( ! isset( $jobs[ $job_id ] ) ) {
			throw new Exception( 'Import job could not be found.' );
		}

		$job = $jobs[ $job_id ];
		if ( 'destination_db_import' !== ( $job['stage'] ?? '' ) ) {
			return;
		}

		try {
			$this->perform_async_database_import_job( $job );
		} catch ( CMSVC_Cancelled_Exception $e ) {
			$jobs = $this->jobs();
			$job  = $jobs[ $job_id ] ?? $job;
			$job  = $this->finalize_job_cancellation( $job, $e->getMessage() );
			$this->save_job( $job );
			return;
		} catch ( Exception $e ) {
			$jobs = $this->jobs();
			$job  = $jobs[ $job_id ] ?? $job;
			$job  = $this->append_job_debug_log(
				$job,
				'Detached database import runner failed.',
				array(
					'error'   => $e->getMessage(),
					'summary' => $this->destination_database_debug_summary(
						$this->work_dir( $job_id ) . '/extract',
						$this->work_dir( $job_id ) . '/extract/database.sql',
						$this->work_dir( $job_id ) . '/extract/database.sql.gz'
					),
				)
			);
			$state = is_array( $job['db_import_state'] ?? null ) ? $job['db_import_state'] : array();
			$state['runner_status'] = 'failed';
			$job['db_import_state'] = $state;
			$job['async_runner_active'] = false;
			$job = $this->mark_job( $job, 'failed', $job['stage'] ?? 'destination_db_import', $e->getMessage() );
			$this->save_job( $job );
			throw $e;
		}
	}

	public function cli_agent_job( $job_id ) {
		$job_id = sanitize_text_field( (string) $job_id );
		if ( '' === $job_id ) {
			throw new Exception( 'Missing job ID.' );
		}

		$job = $this->job_by_id( $job_id );
		if ( empty( $job ) ) {
			throw new Exception( 'Job not found.' );
		}

		if ( in_array( $job['status'] ?? '', array( 'queued', 'running' ), true ) && empty( $job['cancelled'] ) ) {
			$this->enqueue_export_job( $job_id );
			$job = $this->job_by_id( $job_id );
		}

		return $this->public_job( $job );
	}

	private function perform_async_database_import_job( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$extract_dir     = $this->work_dir( $job['id'] ) . '/extract';
		$db_path         = $extract_dir . '/database.sql';
		$source_context  = $this->import_source_context( $job, $extract_dir );
		$skip_emails     = ! empty( $job['do_not_replace_emails'] );
		$state           = is_array( $job['db_import_state'] ?? null ) ? $job['db_import_state'] : array();
		if ( ! empty( $state['target_context'] ) && is_array( $state['target_context'] ) ) {
			$source_context['__target_context'] = $state['target_context'];
		}
		$stale_offset    = max( 0, (int) ( $state['offset'] ?? 0 ) );
		$stale_bytes     = max( 0, (int) ( $state['bytes_imported'] ?? 0 ) );

		if ( $stale_offset > 0 || $stale_bytes > 0 || ! empty( $state['started'] ) || '' !== (string) ( $state['query_buffer'] ?? '' ) ) {
			$job = $this->append_job_debug_log(
				$job,
				'Resetting stale database import cursor before clearing destination database.',
				array(
					'db_import_state' => $state,
				)
			);
		}

		// The async runner clears all destination tables before importing. Resuming
		// from a saved SQL offset after that would silently skip early rows.
		$state['offset']          = 0;
		$state['query_buffer']    = '';
		$state['started']         = false;
		$state['runner_status']   = 'running';
		$state['file_size']       = max( 0, (int) filesize( $db_path ) );
		$state['bytes_imported']  = 0;
		$job['db_import_state']   = $state;
		$job['async_runner_active'] = true;
		$job = $this->append_job_debug_log(
			$job,
			'Detached database import runner is starting work.',
			array(
				'database_sql'    => $this->debug_file_snapshot( $db_path ),
				'db_import_state' => $state,
			)
		);
		$job = $this->mark_job(
			$job,
			'running',
			'destination_db_import',
			$this->destination_database_progress_message( (int) $state['bytes_imported'], (int) $state['file_size'] )
		);
		$this->save_job( $job );

		$this->clear_destination_database_for_import( $job );
		$this->assert_job_not_cancelled( $job );
		$job = $this->import_database_sql_with_database_client_batches( $job, $db_path );
		$this->assert_job_not_cancelled( $job );
		$job = $this->normalize_destination_table_prefix( $job, $source_context );
		$this->assert_job_not_cancelled( $job );
		$job = $this->run_destination_url_search_replace( $job, $source_context, $skip_emails );
		$job = $this->verify_destination_database_integrity( $job, $source_context, $skip_emails );

		$state = is_array( $job['db_import_state'] ?? null ) ? $job['db_import_state'] : array();
		$state['runner_status'] = 'complete';
		$job['db_import_state'] = $state;
		$job = $this->mark_job( $job, 'running', 'destination_finalize', 'Database imported. Finalizing destination state.' );
		$this->save_job( $job );

		$job = $this->finalize_destination_import( $job );
		unset( $job['db_import_state'] );
		$job['async_runner_active'] = false;
		$this->save_job( $job );
	}

	private function finalize_destination_import( array $job ) {
		$this->assert_job_not_cancelled( $job );

		$source_context = $this->import_source_context( $job, $this->work_dir( $job['id'] ) . '/extract' );

		if ( ! empty( $job['destination_settings_snapshot'] ) && is_array( $job['destination_settings_snapshot'] ) ) {
			update_option( CMSVC_OPTION_SETTINGS, $job['destination_settings_snapshot'], false );
		}
		$job = $this->preserve_destination_agent_state( $job );

		$this->apply_destination_wp_config_overrides( $source_context, $job['id'] );
		$this->assert_job_not_cancelled( $job );
		$job = $this->verify_destination_database_integrity( $job, $source_context, ! empty( $job['do_not_replace_emails'] ) );
		$this->assert_job_not_cancelled( $job );
		$this->finalize_import_state();
		$this->assert_job_not_cancelled( $job );

		$job = $this->prepare_destination_attachment_metadata_regeneration( $job );
		if ( 'destination_media_regenerate' === ( $job['stage'] ?? '' ) ) {
			return $job;
		}

		return $this->complete_destination_import( $job, $source_context );
	}

	private function complete_destination_import( array $job, array $source_context ) {
		$this->run_post_import_actions( $source_context );

		if ( ! empty( $job['cleanup_after_complete'] ) ) {
			$this->cleanup_job_artifacts( $job );
		}

		unset( $job['destination_settings_snapshot'] );
		return $this->mark_job( $job, 'complete', 'destination_complete', 'Migration imported successfully.' );
	}

	private function prepare_destination_attachment_metadata_regeneration( array $job ) {
		$state = is_array( $job['attachment_regen_state'] ?? null ) ? $job['attachment_regen_state'] : array();
		if ( empty( $state ) ) {
			$state = array(
				'last_attachment_id' => 0,
				'processed'          => 0,
				'updated'            => 0,
				'recovered_paths'    => 0,
				'missing_files'      => 0,
				'total'              => $this->destination_attachment_regeneration_candidate_count(),
			);
		}

		if ( empty( $state['total'] ) ) {
			unset( $job['attachment_regen_state'] );
			return $job;
		}

		$job['attachment_regen_state'] = $state;
		return $this->mark_job(
			$job,
			'running',
			'destination_media_regenerate',
			$this->destination_attachment_regenerate_progress_message(
				(int) $state['processed'],
				(int) $state['total'],
				(int) $state['updated'],
				(int) $state['recovered_paths']
			)
		);
	}

	private function process_destination_attachment_metadata_batch( array $job ) {
		global $wpdb;

		$this->assert_job_not_cancelled( $job );

		$state = is_array( $job['attachment_regen_state'] ?? null ) ? $job['attachment_regen_state'] : array();
		if ( empty( $state ) ) {
			$job = $this->prepare_destination_attachment_metadata_regeneration( $job );
			if ( 'destination_media_regenerate' !== ( $job['stage'] ?? '' ) ) {
				$source_context = $this->import_source_context( $job, $this->work_dir( $job['id'] ) . '/extract' );
				return $this->complete_destination_import( $job, $source_context );
			}
			$state = $job['attachment_regen_state'];
		}

		$started_at = microtime( true );
		$complete   = false;

		while ( microtime( true ) - $started_at < CMSVC_EXPORT_TASK_WINDOW_SECONDS ) {
			$this->assert_job_not_cancelled( $job );

			$attachment_ids = $this->next_attachment_regeneration_candidate_batch(
				(int) $state['last_attachment_id'],
				CMSVC_IMPORT_ATTACHMENT_REGEN_BATCH_SIZE
			);

			if ( empty( $attachment_ids ) ) {
				$complete = true;
				break;
			}

			foreach ( $attachment_ids as $attachment_id ) {
				$this->assert_job_not_cancelled( $job );

				$attachment_id               = (int) $attachment_id;
				$state['last_attachment_id'] = $attachment_id;
				$state['processed']          = (int) $state['processed'] + 1;

				$result = $this->repair_attachment_metadata( $attachment_id );
				if ( ! empty( $result['updated'] ) ) {
					$state['updated'] = (int) $state['updated'] + 1;
				}
				if ( ! empty( $result['recovered_path'] ) ) {
					$state['recovered_paths'] = (int) $state['recovered_paths'] + 1;
				}
				if ( ! empty( $result['missing_file'] ) ) {
					$state['missing_files'] = (int) $state['missing_files'] + 1;
				}
			}

			if ( count( $attachment_ids ) < CMSVC_IMPORT_ATTACHMENT_REGEN_BATCH_SIZE ) {
				$complete = true;
				break;
			}
		}

		$job['attachment_regen_state'] = $state;
		$job                           = $this->mark_job(
			$job,
			'running',
			'destination_media_regenerate',
			$this->destination_attachment_regenerate_progress_message(
				(int) $state['processed'],
				(int) $state['total'],
				(int) $state['updated'],
				(int) $state['recovered_paths']
			)
		);
		$this->save_job( $job );

		if ( ! $complete ) {
			return $job;
		}

		unset( $job['attachment_regen_state'] );
		$source_context = $this->import_source_context( $job, $this->work_dir( $job['id'] ) . '/extract' );
		return $this->complete_destination_import( $job, $source_context );
	}

	private function cli_job_id( $prefix, $fingerprint ) {
		return 'cli_' . sanitize_key( $prefix ) . '_' . substr( hash( 'sha256', (string) $fingerprint ), 0, 16 );
	}

	private function upsert_cli_job( $job_id, $stage, array $attributes ) {
		$jobs = $this->jobs();
		$job  = $jobs[ $job_id ] ?? $this->new_job( $job_id, $stage );

		if ( in_array( $job['status'] ?? '', array( 'complete', 'cancelled' ), true ) ) {
			$job = $this->new_job( $job_id, $stage );
		}

		$job['stage']      = $job['stage'] ?? $stage;
		$job['status']     = in_array( $job['status'] ?? '', array( 'running', 'queued' ), true ) ? $job['status'] : 'queued';
		$job['updated_at'] = time();

		foreach ( $attributes as $key => $value ) {
			$job[ $key ] = $value;
		}
		$job['manual_only'] = true;

		$this->save_job( $job );
		return $job;
	}

	private function run_cli_job_until_complete( $job_id ) {
		$retries = 0;

		while ( true ) {
			$jobs = $this->jobs();
			if ( ! isset( $jobs[ $job_id ] ) ) {
				throw new Exception( 'Import job could not be found.' );
			}

			$job = $jobs[ $job_id ];
			if ( 'complete' === ( $job['status'] ?? '' ) ) {
				return;
			}

			if ( 'cancelled' === ( $job['status'] ?? '' ) ) {
				throw new Exception( 'Import job was cancelled.' );
			}

			if ( 'failed' === ( $job['status'] ?? '' ) ) {
				throw new Exception( (string) ( $job['message'] ?? 'Import job failed.' ) );
			}

			if ( ! empty( $job['async_runner_active'] ) ) {
				sleep( 2 );
				continue;
			}

			try {
				$job = $this->run_export_queue_step( $job );
				$this->save_job( $job );
				$retries = 0;
			} catch ( CMSVC_Cancelled_Exception $e ) {
				$job = $this->finalize_job_cancellation( $job, $e->getMessage() );
				$this->save_job( $job );
				throw new Exception( 'Import job was cancelled.' );
			} catch ( Exception $e ) {
				$retries++;
				$job = $this->mark_job( $job, 'running', $job['stage'], 'Retrying after import error: ' . $e->getMessage() );
				$this->save_job( $job );

				if ( $retries >= CMSVC_CLI_RETRY_LIMIT ) {
					$job = $this->mark_job( $job, 'failed', $job['stage'], $e->getMessage() );
					$this->save_job( $job );
					throw $e;
				}

				sleep( CMSVC_CLI_RETRY_DELAY_SECONDS );
			}
		}
	}

	private function export_database( $path, $job_id = '' ) {
		if ( $this->can_use_mysqldump() ) {
			try {
				$this->export_database_with_mysqldump( $path, $job_id );
				return;
			} catch ( CMSVC_Cancelled_Exception $e ) {
				throw $e;
			} catch ( Exception $e ) {
				@unlink( $path );
				$this->debug_job_event_by_id(
					$job_id,
					'mysqldump export failed; falling back to PHP database exporter.',
					array(
						'error' => $e->getMessage(),
					)
				);
			}
		}

		$this->export_database_with_php( $path, $job_id );
	}

	private function export_database_with_mysqldump( $path, $job_id = '' ) {
		$defaults_file = $this->create_mysql_defaults_file();
		$parts         = $this->mysql_connection_parts();
		$tables        = $this->database_tables();

		$command = array(
			'mysqldump',
			'--defaults-extra-file=' . $defaults_file,
			'--single-transaction',
			'--quick',
			'--skip-lock-tables',
			'--no-tablespaces',
			'--default-character-set=utf8mb4',
			'--skip-comments',
			'--result-file=' . $path,
		);

		if ( ! empty( $parts['host'] ) ) {
			$command[] = '--host=' . $parts['host'];
		}
		if ( ! empty( $parts['port'] ) ) {
			$command[] = '--port=' . $parts['port'];
		}
		if ( ! empty( $parts['socket'] ) ) {
			$command[] = '--socket=' . $parts['socket'];
		}

		$command[] = DB_NAME;
		$command   = array_merge( $command, $tables );

		try {
			$this->run_shell_command( $command, null, $job_id );
		} catch ( Exception $e ) {
			@unlink( $defaults_file );
			throw $e;
		}

		@unlink( $defaults_file );

		if ( ! file_exists( $path ) || 0 === filesize( $path ) ) {
			throw new Exception( 'mysqldump did not produce a database export.' );
		}
	}

	private function export_database_with_php( $path, $job_id = '' ) {
		global $wpdb;

		$handle = fopen( $path, 'wb' );
		if ( ! $handle ) {
			throw new Exception( 'Unable to write database export.' );
		}

		fwrite( $handle, "-- Cloud Migration Service database export\nSET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\nSET UNIQUE_CHECKS=0;\n\n" );
		$tables = $wpdb->get_col( 'SHOW TABLES' );

		foreach ( $tables as $table ) {
			$this->assert_job_not_cancelled( $job_id );
			$create = $wpdb->get_row( 'SHOW CREATE TABLE `' . esc_sql( $table ) . '`', ARRAY_N );
			fwrite( $handle, "DROP TABLE IF EXISTS `{$table}`;\n" . $create[1] . ";\n\n" );

			$columns    = $wpdb->get_col( 'SHOW COLUMNS FROM `' . esc_sql( $table ) . '`', 0 );
			$primary    = $this->table_primary_key( $table );
			$batch_size = 500;

			if ( $primary ) {
				$last_value = null;
				do {
					$this->assert_job_not_cancelled( $job_id );
					if ( null === $last_value ) {
						$query = $wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY `{$primary}` ASC LIMIT %d", $batch_size );
					} else {
						$query = $wpdb->prepare( "SELECT * FROM `{$table}` WHERE `{$primary}` > %s ORDER BY `{$primary}` ASC LIMIT %d", $last_value, $batch_size );
					}

					$rows = $wpdb->get_results( $query, ARRAY_A );
					$this->write_sql_insert_batch( $handle, $table, $columns, $rows );
					if ( ! empty( $rows ) ) {
						$last_value = $rows[ count( $rows ) - 1 ][ $primary ];
					}
				} while ( count( $rows ) === $batch_size );
			} else {
				$offset = 0;
				do {
					$this->assert_job_not_cancelled( $job_id );
					$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$table}` LIMIT %d OFFSET %d", $batch_size, $offset ), ARRAY_A );
					$this->write_sql_insert_batch( $handle, $table, $columns, $rows );
					$offset += $batch_size;
				} while ( count( $rows ) === $batch_size );
			}

			fwrite( $handle, "\n" );
		}

		fwrite( $handle, "SET FOREIGN_KEY_CHECKS=1;\nSET UNIQUE_CHECKS=1;\n" );
		fclose( $handle );
	}

	private function write_sql_insert_batch( $handle, $table, array $columns, array $rows ) {
		if ( empty( $rows ) ) {
			return;
		}

		$values_sql = array();
		foreach ( $rows as $row ) {
			$values = array();
			foreach ( $columns as $column ) {
				$value    = $row[ $column ] ?? null;
				$values[] = null === $value ? 'NULL' : "'" . $this->escape_sql_export_value( $value ) . "'";
			}
			$values_sql[] = '(' . implode( ',', $values ) . ')';
		}

		fwrite( $handle, 'INSERT INTO `' . $table . '` (`' . implode( '`,`', $columns ) . '`) VALUES ' . implode( ',', $values_sql ) . ";\n" );
	}

	private function table_primary_key( $table ) {
		global $wpdb;

		$table = esc_sql( $table );
		$index = $wpdb->get_results( "SHOW KEYS FROM `{$table}` WHERE Key_name = 'PRIMARY'", ARRAY_A );
		if ( empty( $index ) ) {
			return '';
		}

		usort(
			$index,
			static function ( $left, $right ) {
				return (int) ( $left['Seq_in_index'] ?? 0 ) <=> (int) ( $right['Seq_in_index'] ?? 0 );
			}
		);

		if ( empty( $index[0]['Column_name'] ) ) {
			return '';
		}

		return (string) $index[0]['Column_name'];
	}

	private function import_source_context( array $job, $extract_dir ) {
		$manifest      = array();
		$manifest_path = trailingslashit( $extract_dir ) . 'manifest.json';

		if ( file_exists( $manifest_path ) ) {
			$manifest = json_decode( (string) file_get_contents( $manifest_path ), true );
			if ( ! is_array( $manifest ) ) {
				$manifest = array();
			}
		}

		return array_merge( $manifest, $job['source_context'] ?? array() );
	}

	private function import_extract_target( array $entry, $extract_dir ) {
		$entry_name = ltrim( wp_normalize_path( $entry['filename'] ?? '' ), '/' );

		if ( 'database.sql' === $entry_name || 'database.sql.gz' === $entry_name || 'manifest.json' === $entry_name ) {
			return $extract_dir . '/' . basename( $entry_name );
		}

		if ( 0 === strpos( $entry_name, 'site/' ) ) {
			$relative = substr( $entry_name, 5 );
			if ( '' === $relative || $this->path_is_protected_for_migration( $relative ) ) {
				return false;
			}

			return trailingslashit( ABSPATH ) . str_replace( '/', DIRECTORY_SEPARATOR, $relative );
		}

		return false;
	}

	private function archive_next_entry_at_offset( $archive_path, $offset ) {
		$extractor = new CMSVC_Extractor( $archive_path );
		try {
			return $extractor->entry_at_offset( $offset );
		} finally {
			$extractor->close();
		}
	}

	private function import_database_sql_batch_with_mysql_client( array $job, $path, array $source_context, $skip_email_domains, array $state ) {
		$batch = $this->read_sql_import_batch(
			$path,
			(int) ( $state['offset'] ?? 0 ),
			(string) ( $state['query_buffer'] ?? '' ),
			$source_context,
			$skip_email_domains,
			CMSVC_IMPORT_SQL_CHUNK_BYTES
		);

		$chunk_path = $this->work_dir( $job['id'] ) . '/db-import-chunk.sql';
		$contents   = '';

		if ( empty( $state['started'] ) ) {
			$contents .= "SET FOREIGN_KEY_CHECKS=0;\nSET UNIQUE_CHECKS=0;\n";
		}

		if ( ! empty( $batch['queries'] ) ) {
			$contents .= implode( "\n", $batch['queries'] ) . "\n";
		}

		if ( ! empty( $batch['complete'] ) ) {
			$contents .= "SET FOREIGN_KEY_CHECKS=1;\nSET UNIQUE_CHECKS=1;\n";
		}

		if ( '' !== $contents ) {
			file_put_contents( $chunk_path, $contents );
			$this->import_sql_file_with_mysql_client( $chunk_path, $job['id'] );
		}

		$state['started']        = true;
		$state['offset']         = (int) $batch['offset'];
		$state['query_buffer']   = (string) $batch['query_buffer'];
		$state['bytes_imported'] = (int) $batch['offset'];
		$state['file_size']      = (int) $batch['file_size'];

		return array(
			'state'    => $state,
			'complete' => ! empty( $batch['complete'] ),
		);
	}

	private function import_database_sql_batch_with_php( array $job, $path, array $source_context, $skip_email_domains, array $state ) {
		global $wpdb;

		$this->assert_job_not_cancelled( $job );

		$batch = $this->read_sql_import_batch(
			$path,
			(int) ( $state['offset'] ?? 0 ),
			(string) ( $state['query_buffer'] ?? '' ),
			$source_context,
			$skip_email_domains,
			CMSVC_IMPORT_SQL_CHUNK_BYTES
		);

		if ( empty( $state['started'] ) ) {
			$wpdb->query( 'SET FOREIGN_KEY_CHECKS=0' );
			$wpdb->query( 'SET UNIQUE_CHECKS=0' );
		}

		foreach ( $batch['queries'] as $query ) {
			$this->assert_job_not_cancelled( $job );
			$wpdb->query( $query );
		}

		$state['started']        = true;
		$state['offset']         = (int) $batch['offset'];
		$state['query_buffer']   = (string) $batch['query_buffer'];
		$state['bytes_imported'] = (int) $batch['offset'];
		$state['file_size']      = (int) $batch['file_size'];

		if ( ! empty( $batch['complete'] ) ) {
			$wpdb->query( 'SET FOREIGN_KEY_CHECKS=1' );
			$wpdb->query( 'SET UNIQUE_CHECKS=1' );
		}

		return array(
			'state'    => $state,
			'complete' => ! empty( $batch['complete'] ),
		);
	}

	private function read_sql_import_batch( $path, $offset, $query_buffer, array $source_context, $skip_email_domains, $max_bytes, $rewrite_queries = true ) {
		$handle = fopen( $path, 'rb' );
		if ( ! $handle ) {
			throw new Exception( 'Unable to read database import.' );
		}

		$offset       = max( 0, (int) $offset );
		$query_buffer = (string) $query_buffer;
		$rewriter = null;
		if ( $rewrite_queries ) {
			$target_context = is_array( $source_context['__target_context'] ?? null ) ? $source_context['__target_context'] : array();
			$target_site    = (string) ( $target_context['site_url'] ?? site_url() );
			$target_home    = (string) ( $target_context['home_url'] ?? home_url() );
			$rewriter       = CMSVC_SQL_Rewriter::build( $source_context, $target_site, $target_home, $skip_email_domains, $target_context );
		}
		$queries      = array();
		$batch_bytes  = 0;
		$file_size    = max( 0, (int) filesize( $path ) );

		if ( $offset > 0 && -1 === fseek( $handle, $offset, SEEK_SET ) ) {
			fclose( $handle );
			throw new Exception( 'Unable to resume database import.' );
		}

		while ( false !== ( $line = fgets( $handle ) ) ) {
			$offset  = (int) ftell( $handle );
			$trimmed = trim( $line );
			if ( '' === $trimmed || 0 === strpos( $trimmed, '--' ) ) {
				continue;
			}

			$query_buffer .= $line;
			if ( ';' !== substr( rtrim( $line ), -1 ) ) {
				continue;
			}

			$query         = $rewriter ? $rewriter->rewrite_query( $query_buffer ) : $query_buffer;
			$queries[]     = $query;
			$batch_bytes  += strlen( $query );
			$query_buffer  = '';

			if ( $batch_bytes >= $max_bytes ) {
				break;
			}
		}

		if ( feof( $handle ) && '' !== trim( $query_buffer ) ) {
			$query         = $rewriter ? $rewriter->rewrite_query( $query_buffer ) : $query_buffer;
			$queries[]     = $query;
			$batch_bytes  += strlen( $query );
			$query_buffer  = '';
		}

		$complete = feof( $handle ) && '' === trim( $query_buffer );
		fclose( $handle );

		return array(
			'queries'      => $queries,
			'offset'       => $offset,
			'query_buffer' => $query_buffer,
			'complete'     => $complete,
			'file_size'    => $file_size,
		);
	}

	private function can_use_async_database_import_runner() {
		return $this->can_run_shell_commands()
			&& $this->shell_binary_exists( 'wp' )
			&& '' !== $this->database_client_binary()
			&& $this->shell_binary_exists( 'sh' );
	}

	private function should_use_async_database_import_runner( $db_path = '', $db_size = null ) {
		if ( ! $this->can_use_async_database_import_runner() ) {
			return false;
		}

		if ( null === $db_size ) {
			$db_size = ( '' !== (string) $db_path && file_exists( $db_path ) ) ? max( 0, (int) filesize( $db_path ) ) : 0;
		}

		return max( 0, (int) $db_size ) >= CMSVC_ASYNC_IMPORT_MIN_BYTES;
	}

	private function launch_async_database_import_runner( $job_id ) {
		$pid = $this->run_detached_shell_command(
			$this->wp_cli_command(
				array(
					'cmsvc',
					'run_async_db_import',
					$job_id,
					'--allow-root',
				),
				true
			),
			ABSPATH
		);

		$jobs = $this->jobs();
		if ( ! isset( $jobs[ $job_id ] ) ) {
			return;
		}

		$job  = $jobs[ $job_id ];
		$state = is_array( $job['db_import_state'] ?? null ) ? $job['db_import_state'] : array();
		$state['runner_pid'] = $pid;
		$job['db_import_state'] = $state;
		$this->save_job( $job );
	}

	private function clear_destination_database_for_import( array $job ) {
		$this->assert_job_not_cancelled( $job );
		$job = $this->mark_job( $job, 'running', 'destination_db_import', 'Clearing destination database before import.' );
		$this->save_job( $job );

		$statements = array( 'SET FOREIGN_KEY_CHECKS=0;' );

		foreach ( $this->database_views() as $view ) {
			$statements[] = 'DROP VIEW IF EXISTS `' . str_replace( '`', '``', $view ) . '`;';
		}

		foreach ( $this->database_base_tables() as $table ) {
			$statements[] = 'DROP TABLE IF EXISTS `' . str_replace( '`', '``', $table ) . '`;';
		}

		$statements[] = 'SET FOREIGN_KEY_CHECKS=1;';
		$this->run_database_client_sql( implode( "\n", $statements ), $job['id'] );
	}

	private function import_database_sql_with_database_client_batches( array $job, $db_path ) {
		$state = is_array( $job['db_import_state'] ?? null ) ? $job['db_import_state'] : array();
		$state['offset']        = max( 0, (int) ( $state['offset'] ?? 0 ) );
		$state['query_buffer']  = (string) ( $state['query_buffer'] ?? '' );
		$state['bytes_imported'] = max( 0, (int) ( $state['bytes_imported'] ?? 0 ) );
		$state['file_size']     = max( 0, (int) ( $state['file_size'] ?? filesize( $db_path ) ) );
		$state['started']       = ! empty( $state['started'] );
		$chunk_path             = $this->work_dir( $job['id'] ) . '/db-import-cli-chunk.sql';

		do {
			$batch = $this->read_sql_import_batch(
				$db_path,
				(int) $state['offset'],
				(string) $state['query_buffer'],
				array(),
				false,
				CMSVC_IMPORT_SQL_CLI_BATCH_BYTES,
				false
			);

			$contents = '';
			$contents .= $this->database_client_import_session_preamble();

			if ( ! empty( $batch['queries'] ) ) {
				$contents .= implode( "\n", $batch['queries'] ) . "\n";
			}

			if ( ! empty( $batch['complete'] ) ) {
				$contents .= $this->database_client_import_session_epilogue();
			}

			if ( '' !== $contents ) {
				file_put_contents( $chunk_path, $contents );
				$this->import_sql_file_with_mysql_client( $chunk_path, $job['id'] );
			}

			$state['started']        = true;
			$state['offset']         = (int) $batch['offset'];
			$state['query_buffer']   = (string) $batch['query_buffer'];
			$state['bytes_imported'] = (int) $batch['offset'];
			$state['file_size']      = (int) $batch['file_size'];
			$state['runner_status']  = 'running';
			$job['db_import_state']  = $state;
			$job = $this->mark_job(
				$job,
				'running',
				'destination_db_import',
				$this->destination_database_progress_message( (int) $state['bytes_imported'], (int) $state['file_size'] )
			);
			$job = $this->preserve_destination_agent_state( $job );
			$this->save_job( $job );
			$this->assert_job_not_cancelled( $job );
		} while ( empty( $batch['complete'] ) );

		return $job;
	}

	private function database_client_import_session_preamble() {
		return "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\nSET UNIQUE_CHECKS=0;\n";
	}

	private function database_client_import_session_epilogue() {
		return "SET FOREIGN_KEY_CHECKS=1;\nSET UNIQUE_CHECKS=1;\n";
	}

	private function normalize_destination_table_prefix( array $job, array $source_context ) {
		global $wpdb;

		$target_prefix = isset( $wpdb->prefix ) ? (string) $wpdb->prefix : 'wp_';
		$source_prefix = isset( $source_context['source_table_prefix'] ) ? (string) $source_context['source_table_prefix'] : '';

		if ( '' === $source_prefix || $source_prefix === $target_prefix ) {
			return $job;
		}

		$job = $this->mark_job(
			$job,
			'running',
			'destination_prefix_normalize',
			sprintf( 'Renaming imported database tables from %s to %s.', $source_prefix, $target_prefix )
		);
		$this->save_job( $job );

		$existing_tables = $this->database_base_tables();
		$tables = array_filter(
			$existing_tables,
			static function ( $table ) use ( $source_prefix ) {
				return 0 === strpos( $table, $source_prefix );
			}
		);

		if ( ! empty( $tables ) ) {
			$statements = array( 'SET FOREIGN_KEY_CHECKS=0;' );
			$existing_lookup = array_fill_keys( $existing_tables, true );

			foreach ( $tables as $table ) {
				$new_table = $target_prefix . substr( $table, strlen( $source_prefix ) );
				if ( isset( $existing_lookup[ $new_table ] ) ) {
					$statements[] = 'DROP TABLE IF EXISTS `' . str_replace( '`', '``', $new_table ) . '`;';
					unset( $existing_lookup[ $new_table ] );
				}
			}

			foreach ( $tables as $table ) {
				$new_table    = $target_prefix . substr( $table, strlen( $source_prefix ) );
				$statements[] = 'RENAME TABLE `' . str_replace( '`', '``', $table ) . '` TO `' . str_replace( '`', '``', $new_table ) . '`;';
			}
			$statements[] = 'SET FOREIGN_KEY_CHECKS=1;';
			$this->run_database_client_sql( implode( "\n", $statements ), $job['id'] );
		}

		if ( $source_prefix !== $target_prefix ) {
			$this->assert_job_not_cancelled( $job );
			$this->run_shell_command(
				$this->wp_cli_command(
					array(
						'search-replace',
						$source_prefix,
						$target_prefix,
						'--all-tables',
						'--report-changed-only',
						'--precise',
						'--allow-root',
					)
				),
				ABSPATH,
				$job['id']
			);
		}

		return $job;
	}

	private function run_destination_url_search_replace( array $job, array $source_context, $skip_email_domains ) {
		$job = $this->mark_job( $job, 'running', 'destination_search_replace', 'Running URL and path search replace on the destination database.' );
		$this->save_job( $job );

		$this->run_search_replace_commands(
			$source_context,
			$skip_email_domains,
			function ( $current, $total ) use ( &$job ) {
				$job = $this->mark_job(
					$job,
					'running',
					'destination_search_replace',
					sprintf( 'Running search replace %d of %d.', $current, $total )
				);
				$this->save_job( $job );
			},
			$job['id']
		);

		return $job;
	}

	private function import_database_sql_with_mysql_client( $path ) {
		$this->import_sql_file_with_mysql_client( $path );
	}

	private function import_database_sql( $path, array $source_context = array(), $skip_email_domains = false ) {
		$state = array(
			'offset'       => 0,
			'query_buffer' => '',
			'started'      => false,
		);

		do {
			$result = $this->import_database_sql_batch_with_php( $this->new_job( 'manual_import', 'destination_db_import' ), $path, $source_context, $skip_email_domains, $state );
			$state  = $result['state'];
		} while ( empty( $result['complete'] ) );
	}

	private function import_sql_file_with_mysql_client( $path, $job_id = '' ) {
		$this->assert_job_not_cancelled( $job_id );

		$defaults_file = $this->create_mysql_defaults_file();
		$parts         = $this->mysql_connection_parts();
		$binary        = $this->database_client_binary();
		if ( '' === $binary ) {
			@unlink( $defaults_file );
			throw new Exception( 'MariaDB/MySQL client is not available on the destination.' );
		}

		$command       = array(
			$binary,
			'--defaults-extra-file=' . $defaults_file,
			'--default-character-set=utf8mb4',
		);

		if ( ! empty( $parts['host'] ) ) {
			$command[] = '--host=' . $parts['host'];
		}
		if ( ! empty( $parts['port'] ) ) {
			$command[] = '--port=' . $parts['port'];
		}
		if ( ! empty( $parts['socket'] ) ) {
			$command[] = '--socket=' . $parts['socket'];
		}

		$command[] = DB_NAME;
		$command[] = '--execute=SOURCE ' . addcslashes( $path, '\\' ) . ';';

		try {
			$this->run_shell_command( $command, null, $job_id );
		} catch ( Exception $e ) {
			@unlink( $defaults_file );
			throw $e;
		}

		@unlink( $defaults_file );
	}

	private function destination_extract_progress_message( $extracted_files ) {
		return sprintf(
			'Extracting archive contents: %d files restored.',
			max( 0, (int) $extracted_files )
		);
	}

	private function destination_database_progress_message( $imported_bytes, $total_bytes ) {
		$total_bytes = max( 1, (int) $total_bytes );
		$percent     = min( 100, round( ( max( 0, (int) $imported_bytes ) / $total_bytes ) * 100, 2 ) );

		return sprintf(
			'Importing database: %s%% (%s / %s MB).',
			number_format_i18n( $percent, 2 ),
			number_format_i18n( max( 0, (int) $imported_bytes ) / 1048576, 2 ),
			number_format_i18n( $total_bytes / 1048576, 2 )
		);
	}

	private function destination_database_expand_progress_message( $expanded_bytes, $compressed_bytes ) {
		return sprintf(
			'Expanding compressed database export: %s MB restored from %s MB gzip.',
			number_format_i18n( max( 0, (int) $expanded_bytes ) / 1048576, 2 ),
			number_format_i18n( max( 0, (int) $compressed_bytes ) / 1048576, 2 )
		);
	}

	private function destination_attachment_regenerate_progress_message( $processed, $total, $updated, $recovered_paths ) {
		return sprintf(
			'Repairing media records: %d of %d candidates processed, %d regenerated, %d paths repaired.',
			max( 0, (int) $processed ),
			max( 0, (int) $total ),
			max( 0, (int) $updated ),
			max( 0, (int) $recovered_paths )
		);
	}

	private function run_search_replace_commands( array $source_context, $skip_email_domains, callable $progress_callback = null, $job_id = '' ) {
		$pairs = $this->search_replace_pairs( $source_context, $skip_email_domains );
		if ( empty( $pairs ) ) {
			return;
		}

		$total   = count( $pairs );
		$current = 0;

		foreach ( $pairs as $pair ) {
			if ( '' !== $job_id ) {
				$this->assert_job_not_cancelled( $job_id );
			}

			$current++;
			if ( $progress_callback ) {
				$progress_callback( $current, $total, $pair );
			}

			$command = $this->wp_cli_command(
				array(
					'search-replace',
					$pair['from'],
					$pair['to'],
					'--all-tables',
					'--report-changed-only',
					'--precise',
					'--allow-root',
				)
			);

			$this->run_shell_command( $command, ABSPATH, $job_id );
		}
	}

	private function search_replace_pairs( array $source_context, $skip_email_domains ) {
		$uploads        = wp_get_upload_dir();
		$target_context = is_array( $source_context['__target_context'] ?? null ) ? $source_context['__target_context'] : array();
		$target_uploads = is_array( $target_context['uploads'] ?? null ) ? $target_context['uploads'] : array();
		$pairs          = array();

		$this->append_search_replace_pair( $pairs, $source_context['source_site_url'] ?? $source_context['source_url'] ?? '', $target_context['site_url'] ?? site_url() );
		$this->append_search_replace_pair( $pairs, $source_context['source_home_url'] ?? $source_context['source_url'] ?? '', $target_context['home_url'] ?? home_url() );
		$this->append_search_replace_pair( $pairs, $source_context['source_abspath'] ?? '', $target_context['abspath'] ?? ABSPATH );
		$this->append_search_replace_pair( $pairs, $source_context['source_content_dir'] ?? '', $target_context['content_dir'] ?? WP_CONTENT_DIR );
		$this->append_search_replace_pair( $pairs, $source_context['source_uploads_dir'] ?? '', $target_uploads['basedir'] ?? $uploads['basedir'] ?? '' );
		$this->append_search_replace_pair( $pairs, $source_context['source_uploads_url'] ?? '', $target_uploads['baseurl'] ?? $uploads['baseurl'] ?? '' );

		if ( ! $skip_email_domains ) {
			$old_host = wp_parse_url( $source_context['source_home_url'] ?? $source_context['source_url'] ?? '', PHP_URL_HOST );
			$new_host = wp_parse_url( home_url(), PHP_URL_HOST );
			if ( $old_host && $new_host ) {
				$this->append_search_replace_pair( $pairs, '@' . $old_host, '@' . str_ireplace( 'www.', '', $new_host ) );
			}
		}

		return $pairs;
	}

	private function append_search_replace_pair( array &$pairs, $from, $to ) {
		$from = (string) $from;
		$to   = (string) $to;

		if ( '' === $from || $from === $to ) {
			return;
		}

		$key = $from . "\n" . $to;
		if ( isset( $pairs[ $key ] ) ) {
			return;
		}

		$pairs[ $key ] = array(
			'from' => $from,
			'to'   => $to,
		);
	}

	private function verify_destination_database_integrity( array $job, array $source_context, $skip_email_domains ) {
		$this->assert_job_not_cancelled( $job );

		if ( ! empty( $job['post_import_verified'] ) ) {
			return $job;
		}

		$count_mismatches = $this->destination_database_count_mismatches( $source_context );
		$remaining_refs   = $this->remaining_source_database_references( $source_context, $skip_email_domains );

		$job = $this->append_job_debug_log(
			$job,
			'Post-import database verification completed.',
			array(
				'count_mismatches'             => $count_mismatches,
				'remaining_source_references'  => $remaining_refs,
			)
		);

		if ( ! empty( $count_mismatches ) || ! empty( $remaining_refs ) ) {
			$this->save_job( $job );

			$messages = array();
			foreach ( array_slice( $count_mismatches, 0, 5 ) as $item ) {
				$messages[] = sprintf(
					'%s expected %d rows, found %d',
					(string) ( $item['destination_table'] ?? $item['source_table'] ?? 'table' ),
					max( 0, (int) ( $item['source_count'] ?? 0 ) ),
					max( 0, (int) ( $item['destination_count'] ?? 0 ) )
				);
			}
			foreach ( array_slice( $remaining_refs, 0, 5 ) as $item ) {
				$messages[] = sprintf(
					'%s.%s still contains source value %s',
					(string) ( $item['table'] ?? 'table' ),
					(string) ( $item['column'] ?? 'column' ),
					(string) ( $item['value'] ?? '' )
				);
			}

			throw new Exception( 'Post-import verification failed: ' . implode( '; ', $messages ) );
		}

		$job['post_import_verified'] = true;
		return $job;
	}

	private function destination_database_count_mismatches( array $source_context ) {
		global $wpdb;

		$source_counts = is_array( $source_context['source_database_counts'] ?? null ) ? $source_context['source_database_counts'] : array();
		$source_counts = $this->sanitize_database_counts( $source_counts );
		if ( empty( $source_counts ) ) {
			return array();
		}

		$source_prefix = (string) ( $source_context['source_table_prefix'] ?? '' );
		$target_prefix = isset( $wpdb->prefix ) ? (string) $wpdb->prefix : 'wp_';
		$mismatches    = array();

		foreach ( $source_counts as $source_table => $source_count ) {
			$destination_table = $this->map_source_table_to_destination( $source_table, $source_prefix, $target_prefix );
			if ( '' === $destination_table ) {
				continue;
			}

			if ( ! $this->database_table_exists( $destination_table ) ) {
				$mismatches[] = array(
					'source_table'      => $source_table,
					'destination_table' => $destination_table,
					'source_count'      => $source_count,
					'destination_count' => 0,
					'missing_table'     => true,
				);
				continue;
			}

			$destination_count = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . $this->escape_database_identifier( $destination_table ) . '`' );
			if ( (int) $source_count !== $destination_count ) {
				$mismatches[] = array(
					'source_table'      => $source_table,
					'destination_table' => $destination_table,
					'source_count'      => (int) $source_count,
					'destination_count' => $destination_count,
				);
			}
		}

		return $mismatches;
	}

	private function remaining_source_database_references( array $source_context, $skip_email_domains ) {
		$values = array();
		foreach ( array( 'source_site_url', 'source_home_url', 'source_uploads_url' ) as $key ) {
			if ( ! empty( $source_context[ $key ] ) ) {
				$values[] = untrailingslashit( (string) $source_context[ $key ] );
				$values[] = trailingslashit( (string) $source_context[ $key ] );
			}
		}

		if ( ! $skip_email_domains ) {
			$old_host = wp_parse_url( $source_context['source_home_url'] ?? $source_context['source_url'] ?? '', PHP_URL_HOST );
			if ( $old_host ) {
				$values[] = '@' . $old_host;
			}
		}

		$values = array_values( array_unique( array_filter( array_map( 'strval', $values ) ) ) );
		if ( empty( $values ) ) {
			return array();
		}

		$checks = $this->source_reference_verification_columns();
		$found  = array();
		foreach ( $values as $value ) {
			foreach ( $checks as $table => $columns ) {
				foreach ( $columns as $column ) {
					if ( $this->database_column_contains_value( $table, $column, $value ) ) {
						$found[] = array(
							'table'  => $table,
							'column' => $column,
							'value'  => $value,
						);

						if ( count( $found ) >= 20 ) {
							return $found;
						}
					}
				}
			}
		}

		return $found;
	}

	private function source_reference_verification_columns() {
		global $wpdb;

		return array(
			$wpdb->posts            => array( 'post_content', 'post_excerpt' ),
			$wpdb->postmeta         => array( 'meta_value' ),
			$wpdb->comments         => array( 'comment_content', 'comment_author_url' ),
			$wpdb->commentmeta      => array( 'meta_value' ),
			$wpdb->termmeta         => array( 'meta_value' ),
			$wpdb->usermeta         => array( 'meta_value' ),
		);
	}

	private function database_column_contains_value( $table, $column, $value ) {
		global $wpdb;

		$table  = (string) $table;
		$column = (string) $column;
		$value  = (string) $value;
		if ( '' === $table || '' === $column || '' === $value || ! $this->database_table_exists( $table ) ) {
			return false;
		}

		$columns = $wpdb->get_col( 'SHOW COLUMNS FROM `' . $this->escape_database_identifier( $table ) . '`', 0 );
		if ( ! in_array( $column, array_map( 'strval', (array) $columns ), true ) ) {
			return false;
		}

		$match = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT 1 FROM `' . $this->escape_database_identifier( $table ) . '` WHERE `' . $this->escape_database_identifier( $column ) . '` LIKE %s LIMIT 1',
				'%' . $wpdb->esc_like( $value ) . '%'
			)
		);

		return null !== $match;
	}

	private function database_verification_counts( $prefix = '' ) {
		global $wpdb;

		$prefix = '' !== (string) $prefix ? (string) $prefix : (string) $wpdb->prefix;
		$counts = array();

		foreach ( $this->database_verification_table_suffixes() as $suffix ) {
			$table = $prefix . $suffix;
			if ( ! $this->database_table_exists( $table ) ) {
				continue;
			}

			$counts[ $table ] = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . $this->escape_database_identifier( $table ) . '`' );
		}

		return $counts;
	}

	private function database_verification_table_suffixes() {
		return array(
			'posts',
			'postmeta',
			'terms',
			'term_taxonomy',
			'term_relationships',
			'termmeta',
			'comments',
			'commentmeta',
			'users',
			'usermeta',
		);
	}

	private function sanitize_database_counts( array $counts ) {
		$sanitized = array();
		foreach ( $counts as $table => $count ) {
			$table = sanitize_text_field( (string) $table );
			if ( '' === $table || ! preg_match( '/^[A-Za-z0-9_]+$/', $table ) ) {
				continue;
			}

			$sanitized[ $table ] = max( 0, (int) $count );
		}

		return $sanitized;
	}

	private function map_source_table_to_destination( $source_table, $source_prefix, $target_prefix ) {
		$source_table  = (string) $source_table;
		$source_prefix = (string) $source_prefix;
		$target_prefix = (string) $target_prefix;

		if ( '' !== $source_prefix && 0 === strpos( $source_table, $source_prefix ) ) {
			$suffix = substr( $source_table, strlen( $source_prefix ) );
			if ( in_array( $suffix, $this->database_verification_table_suffixes(), true ) ) {
				return $target_prefix . $suffix;
			}
		}

		foreach ( $this->database_verification_table_suffixes() as $suffix ) {
			if ( $source_table === $target_prefix . $suffix ) {
				return $source_table;
			}
		}

		return '';
	}

	private function database_table_exists( $table ) {
		global $wpdb;

		$table = (string) $table;
		if ( '' === $table || ! preg_match( '/^[A-Za-z0-9_]+$/', $table ) ) {
			return false;
		}

		return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;
	}

	private function escape_database_identifier( $identifier ) {
		return str_replace( '`', '``', (string) $identifier );
	}

	private function escape_sql_export_value( $value ) {
		global $wpdb;

		$value = $wpdb->_real_escape( $value );
		if ( method_exists( $wpdb, 'remove_placeholder_escape' ) ) {
			$value = $wpdb->remove_placeholder_escape( $value );
		}

		return $value;
	}

	private function destination_attachment_regeneration_candidate_count() {
		global $wpdb;

		return max(
			0,
			(int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(DISTINCT p.ID)
					FROM {$wpdb->posts} p
					LEFT JOIN {$wpdb->postmeta} attached_file
						ON attached_file.post_id = p.ID
						AND attached_file.meta_key = %s
					LEFT JOIN {$wpdb->postmeta} attachment_meta
						ON attachment_meta.post_id = p.ID
						AND attachment_meta.meta_key = %s
					WHERE p.post_type = %s
						AND (
							attached_file.meta_id IS NULL
							OR attached_file.meta_value = ''
							OR attachment_meta.meta_id IS NULL
							OR attachment_meta.meta_value = ''
						)",
					'_wp_attached_file',
					'_wp_attachment_metadata',
					'attachment'
				)
			)
		);
	}

	private function next_attachment_regeneration_candidate_batch( $after_id, $limit ) {
		global $wpdb;

		$rows = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT p.ID
				FROM {$wpdb->posts} p
				LEFT JOIN {$wpdb->postmeta} attached_file
					ON attached_file.post_id = p.ID
					AND attached_file.meta_key = %s
				LEFT JOIN {$wpdb->postmeta} attachment_meta
					ON attachment_meta.post_id = p.ID
					AND attachment_meta.meta_key = %s
				WHERE p.post_type = %s
					AND p.ID > %d
					AND (
						attached_file.meta_id IS NULL
						OR attached_file.meta_value = ''
						OR attachment_meta.meta_id IS NULL
						OR attachment_meta.meta_value = ''
					)
				ORDER BY p.ID ASC
				LIMIT %d",
				'_wp_attached_file',
				'_wp_attachment_metadata',
				'attachment',
				max( 0, (int) $after_id ),
				max( 1, (int) $limit )
			)
		);

		return array_map( 'intval', array_values( array_filter( (array) $rows, 'is_numeric' ) ) );
	}

	private function repair_attachment_metadata( $attachment_id ) {
		$file = $this->resolve_attachment_file_for_regeneration( $attachment_id, $recovered_path );
		if ( '' === $file || ! file_exists( $file ) ) {
			return array(
				'updated'        => false,
				'recovered_path' => ! empty( $recovered_path ),
				'missing_file'   => true,
			);
		}

		if ( ! $this->attachment_metadata_needs_regeneration( $attachment_id, $file, ! empty( $recovered_path ) ) ) {
			return array(
				'updated'        => false,
				'recovered_path' => ! empty( $recovered_path ),
				'missing_file'   => false,
			);
		}

		if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}

		$metadata = wp_generate_attachment_metadata( $attachment_id, $file );
		if ( is_wp_error( $metadata ) || ! is_array( $metadata ) || empty( $metadata ) ) {
			return array(
				'updated'        => false,
				'recovered_path' => ! empty( $recovered_path ),
				'missing_file'   => false,
			);
		}

		wp_update_attachment_metadata( $attachment_id, $metadata );

		return array(
			'updated'        => true,
			'recovered_path' => ! empty( $recovered_path ),
			'missing_file'   => false,
		);
	}

	private function attachment_metadata_needs_regeneration( $attachment_id, $file, $recovered_path ) {
		if ( ! wp_attachment_is_image( $attachment_id ) ) {
			return false;
		}

		if ( $recovered_path ) {
			return true;
		}

		$metadata = wp_get_attachment_metadata( $attachment_id );
		if ( ! is_array( $metadata ) || empty( $metadata ) ) {
			return true;
		}

		$metadata_file = isset( $metadata['file'] ) ? wp_normalize_path( (string) $metadata['file'] ) : '';
		if ( '' === $metadata_file ) {
			return true;
		}

		$expected_relative = $this->relative_attachment_file_path_from_absolute( $file );
		if ( '' !== $expected_relative && $metadata_file !== wp_normalize_path( $expected_relative ) ) {
			return true;
		}

		return empty( $metadata['width'] ) || empty( $metadata['height'] );
	}

	private function resolve_attachment_file_for_regeneration( $attachment_id, &$recovered_path = false ) {
		$recovered_path = false;

		$attached_file = get_attached_file( $attachment_id, true );
		if ( is_string( $attached_file ) && '' !== $attached_file && file_exists( $attached_file ) ) {
			return $attached_file;
		}

		$relative = (string) get_post_meta( $attachment_id, '_wp_attached_file', true );
		if ( '' !== $relative ) {
			$candidate = $this->absolute_attachment_file_path( $relative );
			if ( '' !== $candidate && file_exists( $candidate ) ) {
				return $candidate;
			}
		}

		$relative = $this->recover_attachment_relative_path_from_guid( $attachment_id );
		if ( '' === $relative ) {
			return '';
		}

		$candidate = $this->absolute_attachment_file_path( $relative );
		if ( '' === $candidate || ! file_exists( $candidate ) ) {
			return '';
		}

		update_post_meta( $attachment_id, '_wp_attached_file', $relative );
		$recovered_path = true;
		return $candidate;
	}

	private function recover_attachment_relative_path_from_guid( $attachment_id ) {
		$guid    = (string) get_post_field( 'guid', $attachment_id );
		$uploads = wp_get_upload_dir();
		$baseurl = (string) ( $uploads['baseurl'] ?? '' );

		if ( '' === $guid || '' === $baseurl ) {
			return '';
		}

		$guid_path = wp_parse_url( $guid, PHP_URL_PATH );
		$base_path = wp_parse_url( $baseurl, PHP_URL_PATH );
		if ( ! is_string( $guid_path ) || ! is_string( $base_path ) ) {
			return '';
		}

		$base_path = untrailingslashit( $base_path );
		if ( '' === $base_path || 0 !== strpos( $guid_path, $base_path . '/' ) ) {
			return '';
		}

		return ltrim( str_replace( '\\', '/', rawurldecode( substr( $guid_path, strlen( $base_path ) + 1 ) ) ), '/' );
	}

	private function absolute_attachment_file_path( $relative_path ) {
		$relative_path = trim( (string) $relative_path );
		if ( '' === $relative_path ) {
			return '';
		}

		if ( preg_match( '#^[A-Za-z]:[\\\\/]#', $relative_path ) || 0 === strpos( $relative_path, '/' ) ) {
			return $relative_path;
		}

		$uploads = wp_get_upload_dir();
		$basedir = (string) ( $uploads['basedir'] ?? '' );
		if ( '' === $basedir ) {
			return '';
		}

		return trailingslashit( $basedir ) . ltrim( str_replace( array( '\\', '/' ), DIRECTORY_SEPARATOR, $relative_path ), DIRECTORY_SEPARATOR );
	}

	private function relative_attachment_file_path_from_absolute( $absolute_path ) {
		$absolute_path = wp_normalize_path( (string) $absolute_path );
		if ( '' === $absolute_path ) {
			return '';
		}

		$uploads = wp_get_upload_dir();
		$basedir = wp_normalize_path( (string) ( $uploads['basedir'] ?? '' ) );
		if ( '' === $basedir ) {
			return '';
		}

		$prefix = trailingslashit( $basedir );
		if ( 0 !== strpos( $absolute_path, $prefix ) ) {
			return '';
		}

		return ltrim( substr( $absolute_path, strlen( $prefix ) ), '/' );
	}

	private function preserve_destination_agent_state( array $job ) {
		$settings_restored = false;
		if ( ! empty( $job['destination_settings_snapshot'] ) && is_array( $job['destination_settings_snapshot'] ) ) {
			if ( get_option( CMSVC_OPTION_SETTINGS ) !== $job['destination_settings_snapshot'] ) {
				update_option( CMSVC_OPTION_SETTINGS, $job['destination_settings_snapshot'], false );
				$settings_restored = true;
			}
		} elseif ( ! is_array( get_option( CMSVC_OPTION_SETTINGS ) ) ) {
			update_option( CMSVC_OPTION_SETTINGS, self::default_settings(), false );
			$settings_restored = true;
		}

		$activation_restored = $this->ensure_current_plugin_active_option();

		if ( $settings_restored || $activation_restored || empty( $job['destination_agent_state_preserved'] ) ) {
			$job = $this->append_job_debug_log(
				$job,
				'Destination agent state preserved after database import.',
				array(
					'settings_restored'   => $settings_restored,
					'activation_restored' => $activation_restored,
					'plugin'              => plugin_basename( __FILE__ ),
				)
			);
		}

		$job['destination_agent_state_preserved'] = true;
		return $job;
	}

	private function ensure_current_plugin_active_option() {
		$plugin_file = plugin_basename( __FILE__ );
		if ( '' === $plugin_file ) {
			return false;
		}

		$active_plugins = get_option( 'active_plugins', array() );
		if ( ! is_array( $active_plugins ) ) {
			$active_plugins = array();
		}

		$active_plugins = array_values(
			array_unique(
				array_filter(
					array_map( 'strval', $active_plugins )
				)
			)
		);

		if ( in_array( $plugin_file, $active_plugins, true ) ) {
			return false;
		}

		$active_plugins[] = $plugin_file;
		sort( $active_plugins, SORT_STRING );
		update_option( 'active_plugins', $active_plugins );

		return true;
	}

	private function finalize_import_state() {
		global $wp_rewrite;

		wp_cache_flush();

		delete_post_meta_by_key( '_elementor_css' );
		delete_post_meta_by_key( '_elementor_element_cache' );
		delete_post_meta_by_key( '_elementor_page_assets' );

		delete_option( '_elementor_global_css' );
		delete_option( '_elementor_assets_data' );
		delete_option( 'elementor-custom-breakpoints-files' );
		delete_option( 'rewrite_rules' );

		if ( $wp_rewrite instanceof WP_Rewrite ) {
			$wp_rewrite->init();
			$wp_rewrite->set_permalink_structure( (string) get_option( 'permalink_structure', '' ) );
			$wp_rewrite->flush_rules( false );
		} else {
			flush_rewrite_rules( false );
		}
	}

	private function run_post_import_actions( array $source_context ) {
		/**
		 * Fires after the destination import is complete and the destination wp-config
		 * overrides have been applied.
		 *
		 * This is the extension point for site-specific post-migration tasks such as
		 * regenerating builder signatures or clearing plugin caches.
		 */
		do_action( 'cmsvc_after_import', $source_context );
	}

	private function apply_destination_wp_config_overrides( array $source_context, $job_id = '' ) {
		$this->assert_job_not_cancelled( $job_id );

		$defines = $source_context['source_wp_config_defines'] ?? array();
		if ( ! is_array( $defines ) || empty( $defines ) ) {
			return;
		}

		$wp_config_path = $this->locate_wp_config_path();
		if ( '' === $wp_config_path || ! file_exists( $wp_config_path ) || ! is_readable( $wp_config_path ) || ! is_writable( $wp_config_path ) ) {
			return;
		}

		$contents = file_get_contents( $wp_config_path );
		if ( false === $contents ) {
			return;
		}

		$updated = false;
		foreach ( array( 'WP_CONTENT_DIR', 'WP_CONTENT_URL', 'UPLOADS' ) as $name ) {
			if ( empty( $defines[ $name ] ) || ! is_string( $defines[ $name ] ) ) {
				continue;
			}

			$contents = $this->upsert_wp_config_define( $contents, $name, $defines[ $name ], $updated );
		}

		if ( ! $updated ) {
			return;
		}

		file_put_contents( $wp_config_path, $contents );
		$this->refresh_destination_paths_after_wp_config_update( $job_id );
	}

	private function refresh_destination_paths_after_wp_config_update( $job_id = '' ) {
		$this->assert_job_not_cancelled( $job_id );

		if ( ! $this->can_run_shell_commands() || ! $this->shell_binary_exists( 'wp' ) ) {
			return;
		}

		$current_uploads = wp_get_upload_dir();
		$current         = array(
			'content_dir'  => WP_CONTENT_DIR,
			'content_url'  => defined( 'WP_CONTENT_URL' ) ? WP_CONTENT_URL : '',
			'uploads_dir'  => $current_uploads['basedir'] ?? '',
			'uploads_url'  => $current_uploads['baseurl'] ?? '',
		);
		$fresh           = $this->destination_runtime_context_from_wp_cli();

		if ( empty( $fresh ) ) {
			return;
		}

		$pairs = array();
		$this->append_search_replace_pair( $pairs, $current['content_dir'], $fresh['content_dir'] ?? '' );
		$this->append_search_replace_pair( $pairs, $current['content_url'], $fresh['content_url'] ?? '' );
		$this->append_search_replace_pair( $pairs, $current['uploads_dir'], $fresh['uploads_dir'] ?? '' );
		$this->append_search_replace_pair( $pairs, $current['uploads_url'], $fresh['uploads_url'] ?? '' );

		if ( empty( $pairs ) ) {
			return;
		}

		foreach ( $pairs as $pair ) {
			$this->assert_job_not_cancelled( $job_id );
			$command = $this->wp_cli_command(
				array(
					'search-replace',
					$pair['from'],
					$pair['to'],
					'--all-tables',
					'--report-changed-only',
					'--precise',
					'--allow-root',
				)
			);

			$this->run_shell_command( $command, ABSPATH, $job_id );
		}
	}

	private function destination_runtime_context_from_wp_cli() {
		$json = $this->run_shell_command(
			$this->wp_cli_command(
				array(
					'eval',
					'echo wp_json_encode(array('
					. '\'content_dir\' => WP_CONTENT_DIR,'
					. '\'content_url\' => defined(\'WP_CONTENT_URL\') ? WP_CONTENT_URL : \'\','
					. '\'uploads_dir\' => wp_get_upload_dir()[\'basedir\'] ?? \'\','
					. '\'uploads_url\' => wp_get_upload_dir()[\'baseurl\'] ?? \'\','
					. '));',
					'--allow-root',
				)
			),
			ABSPATH
		);

		$data = json_decode( (string) $json, true );
		return is_array( $data ) ? $data : array();
	}

	private function wp_cli_command( array $args, $keep_current_plugin_loaded = false ) {
		$command = array( 'wp' );

		if ( $keep_current_plugin_loaded ) {
			$skip_plugins = $this->wp_cli_skip_plugins_except_current();
			if ( '' !== $skip_plugins ) {
				$command[] = '--skip-plugins=' . $skip_plugins;
			}
		} else {
			$command[] = '--skip-plugins';
		}

		$command[] = '--skip-themes';

		return array_merge( $command, $args );
	}

	private function wp_cli_skip_plugins_except_current() {
		if ( ! defined( 'WP_PLUGIN_DIR' ) || ! is_dir( WP_PLUGIN_DIR ) ) {
			return '';
		}

		$current_plugin_dir = basename( dirname( __FILE__ ) );
		$entries            = @scandir( WP_PLUGIN_DIR );
		if ( false === $entries ) {
			return '';
		}

		$skip = array();
		foreach ( $entries as $entry ) {
			if ( '.' === $entry || '..' === $entry || $current_plugin_dir === $entry ) {
				continue;
			}

			$full_path = WP_PLUGIN_DIR . '/' . $entry;
			if ( is_dir( $full_path ) || preg_match( '/\.php$/i', $entry ) ) {
				$skip[] = $entry;
			}
		}

		sort( $skip, SORT_STRING );
		return implode( ',', $skip );
	}

	private function supported_wp_config_defines() {
		$wp_config_path = $this->locate_wp_config_path();
		if ( '' === $wp_config_path || ! file_exists( $wp_config_path ) || ! is_readable( $wp_config_path ) ) {
			return array();
		}

		$contents = file_get_contents( $wp_config_path );
		if ( false === $contents ) {
			return array();
		}

		return $this->extract_wp_config_defines( $contents, array( 'WP_CONTENT_DIR', 'WP_CONTENT_URL', 'UPLOADS' ) );
	}

	private function locate_wp_config_path() {
		$candidates = array(
			trailingslashit( ABSPATH ) . 'wp-config.php',
			dirname( untrailingslashit( ABSPATH ) ) . '/wp-config.php',
		);

		foreach ( $candidates as $candidate ) {
			if ( file_exists( $candidate ) ) {
				return wp_normalize_path( $candidate );
			}
		}

		return '';
	}

	private function extract_wp_config_defines( $contents, array $names ) {
		$wanted  = array_fill_keys( $names, true );
		$results = array();
		$tokens  = token_get_all( $contents );
		$count   = count( $tokens );

		for ( $index = 0; $index < $count; $index++ ) {
			$token = $tokens[ $index ];
			if ( ! is_array( $token ) || T_STRING !== $token[0] || 'define' !== strtolower( $token[1] ) ) {
				continue;
			}

			$index = $this->skip_non_code_tokens( $tokens, $index + 1, $count );
			if ( $index >= $count || '(' !== $this->token_text( $tokens[ $index ] ) ) {
				continue;
			}

			$index = $this->skip_non_code_tokens( $tokens, $index + 1, $count );
			if ( $index >= $count || ! is_array( $tokens[ $index ] ) || T_CONSTANT_ENCAPSED_STRING !== $tokens[ $index ][0] ) {
				continue;
			}

			$name = trim( $tokens[ $index ][1], '\'"' );
			if ( ! isset( $wanted[ $name ] ) || isset( $results[ $name ] ) ) {
				continue;
			}

			$index = $this->skip_non_code_tokens( $tokens, $index + 1, $count );
			if ( $index >= $count || ',' !== $this->token_text( $tokens[ $index ] ) ) {
				continue;
			}

			$expression = '';
			$depth      = 0;
			for ( $index = $index + 1; $index < $count; $index++ ) {
				$text = $this->token_text( $tokens[ $index ] );

				if ( '(' === $text ) {
					$depth++;
				} elseif ( ')' === $text ) {
					if ( 0 === $depth ) {
						break;
					}
					$depth--;
				}

				$expression .= $text;
			}

			$expression = trim( $expression );
			if ( '' !== $expression ) {
				$results[ $name ] = $expression;
			}
		}

		return $results;
	}

	private function skip_non_code_tokens( array $tokens, $index, $count ) {
		while ( $index < $count ) {
			$token = $tokens[ $index ];
			if ( is_array( $token ) && in_array( $token[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) {
				$index++;
				continue;
			}

			break;
		}

		return $index;
	}

	private function token_text( $token ) {
		return is_array( $token ) ? $token[1] : $token;
	}

	private function upsert_wp_config_define( $contents, $name, $expression, &$updated ) {
		$define_line = "define( '" . $name . "', " . trim( $expression ) . ' );';
		$pattern     = '/^[ \t]*define\s*\(\s*([\'"])' . preg_quote( $name, '/' ) . '\1\s*,.*?\)\s*;\s*$/mi';

		if ( preg_match( $pattern, $contents ) ) {
			$replaced = preg_replace( $pattern, $define_line, $contents, 1 );
			if ( is_string( $replaced ) && $replaced !== $contents ) {
				$updated  = true;
				$contents = $replaced;
			}

			return $contents;
		}

		$markers = array(
			"/* That's all, stop editing! Happy publishing. */",
			"require_once ABSPATH . 'wp-settings.php';",
			'require_once ABSPATH . "wp-settings.php";',
		);

		foreach ( $markers as $marker ) {
			$position = strpos( $contents, $marker );
			if ( false === $position ) {
				continue;
			}

			$updated = true;
			return substr( $contents, 0, $position ) . $define_line . "\n" . substr( $contents, $position );
		}

		$updated = true;
		return rtrim( $contents ) . "\n" . $define_line . "\n";
	}

	private function add_directory_to_archive( CMSVC_Compressor $archive, $source, $target, array $excluded_roots ) {
		$source               = wp_normalize_path( $source );
		$excluded_roots       = array_map( 'wp_normalize_path', $excluded_roots );
		$excluded_root_globs  = $this->settings_excluded_paths();
		$excluded_extensions  = $this->settings_excluded_extensions();
		$directory_iterator   = new RecursiveDirectoryIterator(
			$source,
			FilesystemIterator::SKIP_DOTS | FilesystemIterator::CURRENT_AS_FILEINFO | FilesystemIterator::KEY_AS_PATHNAME
		);
		$filter = new RecursiveCallbackFilterIterator(
			$directory_iterator,
			function ( $current ) use ( $source, $excluded_roots, $excluded_root_globs, $excluded_extensions ) {
				$path = wp_normalize_path( $current->getPathname() );

				if ( 'wp-config.php' === basename( $path ) ) {
					return false;
				}

				foreach ( $excluded_roots as $excluded ) {
					if ( 0 === strpos( $path, $excluded ) ) {
						return false;
					}
				}

				$relative = ltrim( str_replace( $source, '', $path ), '/' );
				if ( '' !== $relative && $this->path_should_be_skipped_for_migration( $relative, $excluded_root_globs, $excluded_extensions ) ) {
					return false;
				}

				// Skip unreadable directories and files instead of aborting the whole export.
				if ( ! $current->isReadable() ) {
					return false;
				}

				return true;
			}
		);
		$files = new RecursiveIteratorIterator(
			$filter,
			RecursiveIteratorIterator::SELF_FIRST,
			RecursiveIteratorIterator::CATCH_GET_CHILD
		);

		foreach ( $files as $file ) {
			$path = wp_normalize_path( $file->getPathname() );

			if ( 'wp-config.php' === basename( $path ) ) {
				continue;
			}

			foreach ( $excluded_roots as $excluded ) {
				if ( 0 === strpos( $path, $excluded ) ) {
					continue 2;
				}
			}

			$relative = ltrim( str_replace( $source, '', $path ), '/' );
			if ( '' === $relative ) {
				continue;
			}

			if ( $this->path_should_be_skipped_for_migration( $relative, $excluded_root_globs, $excluded_extensions ) ) {
				continue;
			}

			if ( ! $file->isDir() ) {
				$archive->add_file( $path, trailingslashit( $target ) . $relative );
			}
		}
	}

	private function path_should_be_skipped_for_migration( $relative, array $excluded_paths, array $excluded_extensions ) {
		$normalized = trim( wp_normalize_path( $relative ), '/' );
		if ( '' === $normalized ) {
			return false;
		}

		return $this->path_is_protected_for_migration( $normalized ) || $this->path_matches_exclusions( $normalized, $excluded_paths, $excluded_extensions );
	}

	private function path_is_protected_for_migration( $relative ) {
		$normalized = trim( wp_normalize_path( $relative ), '/' );
		if ( '' === $normalized ) {
			return false;
		}

		$basename = strtolower( basename( $normalized ) );
		if ( 'wp-config.php' === $basename || '.user.ini' === $basename ) {
			return true;
		}

		if ( preg_match( '/^php(?:[0-9]+(?:\.[0-9]+)*)?\.ini$/i', $basename ) ) {
			return true;
		}

		return $this->path_matches_exclusions( $normalized, array( 'wp-content/object-cache.php' ), array() );
	}

	private function path_matches_exclusions( $relative, array $excluded_paths, array $excluded_extensions ) {
		$normalized = wp_normalize_path( $relative );

		foreach ( $excluded_paths as $pattern ) {
			$pattern = wp_normalize_path( $pattern );
			if ( '' === $pattern ) {
				continue;
			}

			if ( false !== strpos( $pattern, '*' ) ) {
				$regex = '#^' . str_replace( '\*', '.*', preg_quote( trim( $pattern, '/' ), '#' ) ) . '$#i';
				if ( preg_match( $regex, trim( $normalized, '/' ) ) ) {
					return true;
				}
			} elseif ( 0 === strpos( trim( $normalized, '/' ), trim( $pattern, '/' ) ) ) {
				return true;
			}
		}

		$extension = strtolower( pathinfo( $normalized, PATHINFO_EXTENSION ) );
		if ( $extension && in_array( $extension, $excluded_extensions, true ) ) {
			return true;
		}

		return false;
	}

	private function settings_excluded_paths() {
		$settings = $this->settings();
		$lines    = preg_split( '/\r?\n/', (string) $settings['exclude_paths'] );
		$paths    = array();

		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( '' !== $line ) {
				$paths[] = ltrim( $line, '/' );
			}
		}

		$base_work_dir = wp_normalize_path( $this->base_work_dir() );
		$root          = wp_normalize_path( ABSPATH );
		if ( 0 === strpos( $base_work_dir, $root ) ) {
			$paths[] = ltrim( substr( $base_work_dir, strlen( $root ) ), '/' );
		}

		$paths[] = 'wp-content/uploads/cmsvc';

		return array_values( array_unique( $paths ) );
	}

	private function settings_excluded_extensions() {
		$settings   = $this->settings();
		$extensions = array_map( 'trim', explode( ',', (string) $settings['exclude_file_types'] ) );
		$extensions = array_filter( $extensions );
		$extensions = array_map( 'strtolower', $extensions );
		$extensions[] = 'wpress';

		return array_values( array_unique( $extensions ) );
	}

	private function settings() {
		$stored   = get_option( CMSVC_OPTION_SETTINGS, array() );
		$stored   = is_array( $stored ) ? $stored : array();
		$settings = wp_parse_args( $stored, self::default_settings() );

		if ( empty( $stored['site_key'] ) ) {
			$settings['site_key'] = wp_generate_password( 32, false, false );
			update_option( CMSVC_OPTION_SETTINGS, $settings, false );
		}

		return $settings;
	}

	public function site_worker_key( array $settings = array() ) {
		$settings = empty( $settings ) ? $this->settings() : $settings;
		$payload  = array(
			'v'        => 1,
			'url'      => home_url(),
			'site_url' => site_url(),
			'version'  => CMSVC_VERSION,
			'key'      => (string) ( $settings['site_key'] ?? '' ),
		);

		return 'cmsvc_v1_' . $this->base64url_encode( wp_json_encode( $payload ) );
	}

	private function decode_site_worker_key( $value ) {
		$value = trim( (string) $value );
		if ( 0 !== strpos( $value, 'cmsvc_v1_' ) ) {
			return array();
		}

		$json = $this->base64url_decode( substr( $value, strlen( 'cmsvc_v1_' ) ) );
		if ( '' === $json ) {
			return array();
		}

		$payload = json_decode( $json, true );
		return is_array( $payload ) ? $payload : array();
	}

	private function base64url_encode( $value ) {
		return rtrim( strtr( base64_encode( (string) $value ), '+/', '-_' ), '=' );
	}

	private function base64url_decode( $value ) {
		$value = strtr( (string) $value, '-_', '+/' );
		$pad   = strlen( $value ) % 4;
		if ( $pad ) {
			$value .= str_repeat( '=', 4 - $pad );
		}

		$decoded = base64_decode( $value, true );
		return false === $decoded ? '' : $decoded;
	}

	private function install_plugin_from_zip_url( $zip_url ) {
		$filter_added = false;
		if ( ! current_user_can( 'install_plugins' ) && ! defined( 'WP_CLI' ) ) {
			// Agent key authorization already happened; this only keeps WordPress' filesystem APIs happy on locked-down installs.
			add_filter( 'filesystem_method', array( $this, 'direct_filesystem_method' ) );
			$filter_added = true;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

		$skin     = new Automatic_Upgrader_Skin();
		$upgrader = new Plugin_Upgrader( $skin );
		try {
			$result = $upgrader->install(
				$zip_url,
				array(
					'overwrite_package' => true,
					'clear_update_cache' => true,
				)
			);
		} finally {
			if ( $filter_added ) {
				remove_filter( 'filesystem_method', array( $this, 'direct_filesystem_method' ) );
			}
		}

		if ( is_wp_error( $result ) ) {
			throw new Exception( $result->get_error_message() );
		}

		if ( false === $result ) {
			$message = '';
			if ( is_wp_error( $skin->result ?? null ) ) {
				$message = $skin->result->get_error_message();
			}
			throw new Exception( $message ? $message : 'Plugin update failed.' );
		}

		$plugin_file = plugin_basename( __FILE__ );
		if ( ! is_plugin_active( $plugin_file ) ) {
			$activated = activate_plugin( $plugin_file );
			if ( is_wp_error( $activated ) ) {
				throw new Exception( $activated->get_error_message() );
			}
		}

		return array(
			'plugin' => $plugin_file,
			'active' => is_plugin_active( $plugin_file ),
		);
	}

	public function direct_filesystem_method() {
		return 'direct';
	}

	private function jobs() {
		$jobs = get_option( CMSVC_OPTION_JOBS, array() );
		return is_array( $jobs ) ? $jobs : array();
	}

	private function rest_agent_request_key( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		$key    = (string) $request->get_header( 'x-cmsvc-key' );
		if ( '' === $key && is_array( $params ) && isset( $params['site_key'] ) ) {
			$key = (string) $params['site_key'];
		}

		$decoded = $this->decode_site_worker_key( $key );
		if ( ! empty( $decoded['key'] ) ) {
			return sanitize_text_field( (string) $decoded['key'] );
		}

		return sanitize_text_field( $key );
	}

	private function rest_agent_requested_job_id( WP_REST_Request $request ) {
		$id = sanitize_text_field( (string) $request->get_param( 'id' ) );
		if ( '' !== $id ) {
			return $id;
		}

		$params = $request->get_json_params();
		if ( is_array( $params ) && ! empty( $params['job_id'] ) ) {
			return sanitize_text_field( (string) $params['job_id'] );
		}

		return '';
	}

	private function rest_agent_authorize( WP_REST_Request $request ) {
		$settings = $this->settings();
		$key      = $this->rest_agent_request_key( $request );

		if ( ! empty( $settings['site_key'] ) && '' !== $key && hash_equals( (string) $settings['site_key'], $key ) ) {
			return true;
		}

		$job_id = $this->rest_agent_requested_job_id( $request );
		if ( '' !== $job_id ) {
			$job = $this->job_by_id( $job_id );
			if ( ! empty( $job ) ) {
				$job_auth_key = isset( $job['auth_site_key'] ) ? (string) $job['auth_site_key'] : '';
				if ( '' !== $job_auth_key && '' !== $key && hash_equals( $job_auth_key, $key ) ) {
					return true;
				}
			}
		}

		return new WP_Error( 'cmsvc_forbidden', 'Invalid site key.', array( 'status' => 403 ) );
	}

	private function public_job( array $job ) {
		if ( isset( $job['source_transfer']['site_key'] ) ) {
			unset( $job['source_transfer']['site_key'] );
		}
		unset( $job['file_list_path'] );
		unset( $job['auth_site_key'] );
		if ( ! empty( $job['debug_log'] ) && is_array( $job['debug_log'] ) ) {
			$job['debug_log'] = $this->sanitize_job_debug_log( $job['debug_log'] );
		}
		unset( $job['debug_log_seq'] );
		return $job;
	}

	private function append_job_debug_log( array $job, $message, array $context = array() ) {
		$entries = is_array( $job['debug_log'] ?? null ) ? $job['debug_log'] : array();
		$next_seq = max( 0, (int) ( $job['debug_log_seq'] ?? 0 ) ) + 1;
		$entry = array(
			'seq'     => $next_seq,
			'at'      => gmdate( 'c' ),
			'message' => sanitize_text_field( (string) $message ),
		);

		if ( ! empty( $context ) ) {
			$entry['context'] = $this->sanitize_job_debug_context( $context );
		}

		$entries[] = $entry;
		if ( count( $entries ) > 100 ) {
			$entries = array_slice( $entries, -100 );
		}

		$job['debug_log']     = array_values( $entries );
		$job['debug_log_seq'] = $next_seq;
		return $job;
	}

	private function debug_job_event_by_id( $job_id, $message, array $context = array() ) {
		$job_id = sanitize_text_field( (string) $job_id );
		if ( '' === $job_id ) {
			return;
		}

		$job = $this->job_by_id( $job_id );
		if ( empty( $job ) || ! is_array( $job ) ) {
			return;
		}

		$job = $this->append_job_debug_log( $job, $message, $context );
		$this->save_job( $job );
	}

	private function sanitize_job_debug_log( array $entries ) {
		$sanitized = array();

		foreach ( array_slice( $entries, -100 ) as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}

			$item = array(
				'seq'     => max( 0, (int) ( $entry['seq'] ?? 0 ) ),
				'at'      => sanitize_text_field( (string) ( $entry['at'] ?? '' ) ),
				'message' => sanitize_text_field( (string) ( $entry['message'] ?? '' ) ),
			);

			if ( array_key_exists( 'context', $entry ) ) {
				$item['context'] = $this->sanitize_job_debug_context( $entry['context'] );
			}

			$sanitized[] = $item;
		}

		return $sanitized;
	}

	private function sanitize_job_debug_context( $value, $depth = 0 ) {
		if ( $depth >= 4 ) {
			return '[depth-limit]';
		}

		if ( null === $value || is_bool( $value ) || is_int( $value ) || is_float( $value ) ) {
			return $value;
		}

		if ( is_string( $value ) ) {
			$value = wp_strip_all_tags( $value );
			if ( strlen( $value ) > 500 ) {
				$value = substr( $value, 0, 500 ) . '...';
			}
			return $value;
		}

		if ( is_array( $value ) ) {
			$sanitized = array();
			$count     = 0;
			foreach ( $value as $key => $item ) {
				$count++;
				if ( $count > 20 ) {
					$sanitized['__truncated__'] = true;
					break;
				}

				$sanitized_key               = is_string( $key ) ? sanitize_key( $key ) : $key;
				$sanitized[ $sanitized_key ] = $this->sanitize_job_debug_context( $item, $depth + 1 );
			}
			return $sanitized;
		}

		return sanitize_text_field( (string) $value );
	}

	private function debug_file_snapshot( $path ) {
		$path = wp_normalize_path( (string) $path );
		if ( '' === $path ) {
			return array(
				'path'   => '',
				'exists' => false,
			);
		}

		clearstatcache( true, $path );
		$exists = file_exists( $path );
		$data   = array(
			'path'   => $path,
			'exists' => $exists,
		);

		if ( ! $exists ) {
			return $data;
		}

		$data['type'] = is_dir( $path ) ? 'dir' : 'file';
		if ( is_file( $path ) ) {
			$data['size'] = max( 0, (int) filesize( $path ) );
		}

		$mtime = @filemtime( $path );
		if ( false !== $mtime ) {
			$data['mtime'] = gmdate( 'c', (int) $mtime );
		}

		return $data;
	}

	private function debug_directory_snapshot( $path, $limit = 12 ) {
		$path    = wp_normalize_path( (string) $path );
		$result  = $this->debug_file_snapshot( $path );
		$limit   = max( 1, (int) $limit );

		if ( empty( $result['exists'] ) || ! is_dir( $path ) ) {
			return $result;
		}

		$entries = @scandir( $path );
		if ( ! is_array( $entries ) ) {
			$result['entries'] = array();
			return $result;
		}

		$entries = array_values(
			array_filter(
				$entries,
				static function ( $item ) {
					return '.' !== $item && '..' !== $item;
				}
			)
		);
		sort( $entries, SORT_NATURAL | SORT_FLAG_CASE );
		$result['entries'] = array_slice( $entries, 0, $limit );
		if ( count( $entries ) > $limit ) {
			$result['entries_more'] = count( $entries ) - $limit;
		}

		return $result;
	}

	private function destination_database_debug_summary( $extract_dir, $db_path, $db_gzip_path ) {
		$manifest  = $this->debug_file_snapshot( trailingslashit( $extract_dir ) . 'manifest.json' );
		$db        = $this->debug_file_snapshot( $db_path );
		$db_gzip   = $this->debug_file_snapshot( $db_gzip_path );
		$directory = $this->debug_directory_snapshot( $extract_dir, 8 );

		$db_size      = isset( $db['size'] ) ? (string) $db['size'] : 'n/a';
		$db_gzip_size = isset( $db_gzip['size'] ) ? (string) $db_gzip['size'] : 'n/a';
		$entries      = ! empty( $directory['entries'] ) ? implode( ', ', $directory['entries'] ) : '(none)';

		return sprintf(
			'database.sql exists=%s size=%s; database.sql.gz exists=%s size=%s; manifest.json exists=%s; extract entries=%s',
			! empty( $db['exists'] ) ? 'yes' : 'no',
			$db_size,
			! empty( $db_gzip['exists'] ) ? 'yes' : 'no',
			$db_gzip_size,
			! empty( $manifest['exists'] ) ? 'yes' : 'no',
			$entries
		);
	}

	private function public_jobs() {
		$jobs = $this->jobs();
		foreach ( $jobs as $id => $job ) {
			$jobs[ $id ] = $this->public_job( $job );
		}
		return $jobs;
	}

	private function save_jobs( array $jobs ) {
		update_option( CMSVC_OPTION_JOBS, $jobs, false );
		foreach ( $jobs as $job ) {
			if ( is_array( $job ) && ! empty( $job['id'] ) ) {
				$this->save_job_snapshot( $job );
			}
		}
	}

	private function save_job( array $job ) {
		$jobs   = $this->jobs();
		$job_id = sanitize_text_field( (string) ( $job['id'] ?? '' ) );
		if ( '' === $job_id ) {
			return;
		}

		$existing_job = isset( $jobs[ $job_id ] ) && is_array( $jobs[ $job_id ] ) ? $jobs[ $job_id ] : array();
		if ( $this->should_keep_existing_job_state( $existing_job, $job ) ) {
			$job = $existing_job;
		}

		$jobs[ $job_id ] = $job;
		$this->save_jobs( $jobs );
	}

	private function should_keep_existing_job_state( array $existing_job, array $incoming_job ) {
		if ( empty( $existing_job ) ) {
			return false;
		}

		if ( ! empty( $existing_job['cancelled'] ) && empty( $incoming_job['cancelled'] ) ) {
			return true;
		}

		if ( $this->job_is_terminal( $existing_job ) && ! $this->job_is_terminal( $incoming_job ) ) {
			return true;
		}

		return false;
	}

	private function job_is_terminal( array $job ) {
		return in_array( (string) ( $job['status'] ?? '' ), array( 'complete', 'cancelled', 'failed' ), true );
	}

	private function job_by_id( $job_id ) {
		$job_id = sanitize_text_field( (string) $job_id );
		if ( '' === $job_id ) {
			return array();
		}

		$jobs = $this->jobs();
		if ( isset( $jobs[ $job_id ] ) && is_array( $jobs[ $job_id ] ) ) {
			return $jobs[ $job_id ];
		}

		return $this->load_job_snapshot( $job_id );
	}

	private function new_job( $id, $stage ) {
		return array(
			'id'         => $id,
			'status'     => 'queued',
			'stage'      => $stage,
			'message'    => '',
			'created_at' => time(),
			'updated_at' => time(),
			'cancelled'  => false,
		);
	}

	private function cancel_job_by_id( $job_id, $message ) {
		$job_id = sanitize_text_field( (string) $job_id );
		if ( '' === $job_id ) {
			return array();
		}

		$jobs = $this->jobs();
		if ( ! isset( $jobs[ $job_id ] ) || ! is_array( $jobs[ $job_id ] ) ) {
			return array();
		}

		$job = $this->request_job_cancellation( $jobs[ $job_id ], $message );
		$this->save_job( $job );

		return $job;
	}

	private function request_job_cancellation( array $job, $message = 'Cancelled by user.' ) {
		$job_id              = sanitize_text_field( (string) ( $job['id'] ?? '' ) );
		$has_processing_task = '' !== $job_id ? $this->export_queue()->count_tasks_for_job( $job_id, array( 'processing' ) ) > 0 : false;

		$job['cancelled']           = true;
		$job['cancel_message']      = sanitize_text_field( (string) $message );
		$job['cleanup_after_cancel'] = true;
		$job['cancelled_at']        = time();
		$this->clear_export_queue_job( $job_id );

		if (
			! in_array( $job['status'] ?? '', array( 'queued', 'running' ), true )
			|| 'queued' === ( $job['status'] ?? '' )
			|| ( ! $has_processing_task && empty( $job['async_runner_active'] ) )
		) {
			return $this->finalize_job_cancellation( $job );
		}

		$job['updated_at'] = time();
		$job['message']    = $job['cancel_message'];
		return $job;
	}

	private function finalize_job_cancellation( array $job, $message = '' ) {
		$cancel_message = '' !== (string) $message
			? sanitize_text_field( (string) $message )
			: sanitize_text_field( (string) ( $job['cancel_message'] ?? 'Cancelled by user.' ) );

		$this->clear_export_queue_job( $job['id'] ?? '' );

		if ( ! empty( $job['cleanup_after_cancel'] ) ) {
			$this->cleanup_job_artifacts( $job );
		}

		$job['cancelled']           = true;
		$job['cancel_message']      = $cancel_message;
		$job['async_runner_active'] = false;
		return $this->mark_job( $job, 'cancelled', 'cancelled', $cancel_message );
	}

	private function assert_job_not_cancelled( $job_or_id ) {
		$job_id = is_array( $job_or_id ) ? sanitize_text_field( (string) ( $job_or_id['id'] ?? '' ) ) : sanitize_text_field( (string) $job_or_id );
		if ( '' === $job_id ) {
			return;
		}

		$job = $this->job_by_id( $job_id );
		if ( empty( $job ) || empty( $job['cancelled'] ) ) {
			return;
		}

		throw new CMSVC_Cancelled_Exception( (string) ( $job['cancel_message'] ?? 'Cancelled by user.' ) );
	}

	private function mark_job( array $job, $status, $stage, $message ) {
		$job['status']     = $status;
		$job['stage']      = $stage;
		$job['message']    = $message;
		$job['updated_at'] = time();
		return $job;
	}

	private function base_work_dir() {
		$upload = wp_upload_dir();
		return trailingslashit( $upload['basedir'] ) . 'cmsvc';
	}

	private function work_dir( $job_id ) {
		return trailingslashit( $this->base_work_dir() ) . sanitize_file_name( $job_id );
	}

	private function archive_path_for_job( $job_id ) {
		return trailingslashit( $this->work_dir( $job_id ) ) . sanitize_file_name( $job_id ) . '.wpress';
	}

	private function archive_is_complete( $path ) {
		if ( empty( $path ) || ! file_exists( $path ) ) {
			return false;
		}

		try {
			$extractor = new CMSVC_Extractor( $path );
			$is_valid  = $extractor->is_valid();
			$extractor->close();
			return $is_valid;
		} catch ( Exception $e ) {
			return false;
		}
	}

	private function export_queue() {
		return new CMSVC_Queue( CMSVC_EXPORT_QUEUE_GROUP, CMSVC_EXPORT_QUEUE_ACTION, CMSVC_EXPORT_TASK_MAX_RETRIES, 1 );
	}

	private function clear_export_queue_job( $job_id ) {
		$job_id = sanitize_text_field( (string) $job_id );
		if ( '' === $job_id ) {
			return;
		}

		$this->export_queue()->delete_tasks_for_job( $job_id );
	}

	private function enqueue_export_job( $job_id, $force = false ) {
		$queue = $this->export_queue();
		if ( ! $force && $queue->get_pending_count() > 0 ) {
			$queue->start_queue();
			return;
		}

		$queue->add_task(
			array(
				'job_id' => $job_id,
				'tick'   => wp_generate_uuid4(),
			)
		);
		$queue->start_queue();
	}

	private function queue_worker( $throttled = false ) {
		if ( $throttled ) {
			$kick_lock = 'cmsvc_kick_lock';
			if ( get_transient( $kick_lock ) ) {
				return;
			}

			set_transient( $kick_lock, 1, 15 );
		}

		if ( ! wp_next_scheduled( CMSVC_KICK_HOOK ) ) {
			wp_schedule_single_event( time() + 5, CMSVC_KICK_HOOK );
		}

		if ( function_exists( 'spawn_cron' ) ) {
			spawn_cron();
		}
	}

	private function cleanup_job_artifacts( array $job ) {
		if ( ! empty( $job['archive_path'] ) && file_exists( $job['archive_path'] ) ) {
			wp_delete_file( $job['archive_path'] );
		}

		$dir = $this->work_dir( $job['id'] ?? '' );
		if ( is_dir( $dir ) ) {
			$this->delete_directory_recursive( $dir );
		}
	}

	private function cleanup_job_artifact_status( array $job ) {
		$archive_path = (string) ( $job['archive_path'] ?? '' );
		$work_dir     = $this->work_dir( $job['id'] ?? '' );

		return array(
			'archive_exists' => '' !== $archive_path && file_exists( $archive_path ),
			'work_dir_exists' => '' !== $work_dir && is_dir( $work_dir ),
		);
	}

	private function save_job_snapshot( array $job ) {
		$path = $this->job_snapshot_path( $job['id'] ?? '' );
		if ( '' === $path ) {
			return;
		}

		if ( ! $this->should_persist_job_snapshot( $job ) ) {
			$this->delete_job_snapshot( $job['id'] ?? '' );
			$this->cleanup_legacy_job_snapshot_directory( $job['id'] ?? '' );
			return;
		}

		wp_mkdir_p( dirname( $path ) );
		file_put_contents( $path, wp_json_encode( $job ) );
		$this->cleanup_legacy_job_snapshot_directory( $job['id'] ?? '' );
	}

	private function load_job_snapshot( $job_id ) {
		$path = $this->job_snapshot_path( $job_id );
		if ( '' === $path || ! file_exists( $path ) ) {
			return array();
		}

		$job = json_decode( (string) file_get_contents( $path ), true );
		return is_array( $job ) ? $job : array();
	}

	private function job_snapshot_path( $job_id ) {
		$job_id = sanitize_file_name( (string) $job_id );
		if ( '' === $job_id ) {
			return '';
		}

		return trailingslashit( $this->job_snapshot_dir() ) . $job_id . '.json';
	}

	private function job_snapshot_dir() {
		return trailingslashit( $this->base_work_dir() ) . '_job-state';
	}

	private function should_persist_job_snapshot( array $job ) {
		return in_array( (string) ( $job['status'] ?? '' ), array( 'queued', 'running' ), true );
	}

	private function delete_job_snapshot( $job_id ) {
		$path = $this->job_snapshot_path( $job_id );
		if ( '' === $path || ! file_exists( $path ) ) {
			return;
		}

		@unlink( $path );
		$directory = dirname( $path );
		if ( is_dir( $directory ) ) {
			$items = array_values(
				array_filter(
					(array) scandir( $directory ),
					static function ( $item ) {
						return '.' !== $item && '..' !== $item;
					}
				)
			);

			if ( empty( $items ) ) {
				@rmdir( $directory );
			}
		}
	}

	private function cleanup_legacy_job_snapshot_directory( $job_id ) {
		$job_id     = sanitize_file_name( (string) $job_id );
		$legacy_dir = '' !== $job_id ? $this->work_dir( $job_id ) : '';
		if ( '' === $legacy_dir || ! is_dir( $legacy_dir ) ) {
			return;
		}

		$items = array_values(
			array_filter(
				(array) scandir( $legacy_dir ),
				static function ( $item ) {
					return '.' !== $item && '..' !== $item;
				}
			)
		);

		if ( 1 !== count( $items ) || 'job-state.json' !== $items[0] ) {
			return;
		}

		$legacy_snapshot = trailingslashit( $legacy_dir ) . 'job-state.json';
		if ( file_exists( $legacy_snapshot ) ) {
			@unlink( $legacy_snapshot );
		}
		@rmdir( $legacy_dir );
	}

	private function delete_directory_recursive( $directory ) {
		$directory = wp_normalize_path( $directory );
		$base      = wp_normalize_path( $this->base_work_dir() );

		if ( '' === $directory || 0 !== strpos( $directory, $base ) ) {
			return;
		}

		$items = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $directory, FilesystemIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ( $items as $item ) {
			if ( $item->isDir() ) {
				@rmdir( $item->getPathname() );
			} else {
				@unlink( $item->getPathname() );
			}
		}

		@rmdir( $directory );
	}

	private function database_tables() {
		global $wpdb;
		$tables = $wpdb->get_col( 'SHOW TABLES' );
		return array_values( array_filter( array_map( 'strval', (array) $tables ) ) );
	}

	private function database_base_tables() {
		return $this->database_entities_by_type( 'BASE TABLE' );
	}

	private function database_views() {
		return $this->database_entities_by_type( 'VIEW' );
	}

	private function database_entities_by_type( $type ) {
		global $wpdb;

		$type   = strtoupper( (string) $type );
		$rows   = $wpdb->get_results( $wpdb->prepare( 'SHOW FULL TABLES WHERE Table_type = %s', $type ), ARRAY_N );
		$names  = array();

		foreach ( (array) $rows as $row ) {
			if ( isset( $row[0] ) && '' !== (string) $row[0] ) {
				$names[] = (string) $row[0];
			}
		}

		return array_values( array_unique( $names ) );
	}

	private function mysql_connection_parts() {
		$host   = DB_HOST;
		$parts  = array(
			'host'   => '',
			'port'   => '',
			'socket' => '',
		);

		if ( false !== strpos( $host, ':/' ) ) {
			list( $parts['host'], $parts['socket'] ) = explode( ':', $host, 2 );
			return $parts;
		}

		if ( preg_match( '/^(.+?):([0-9]+)$/', $host, $matches ) ) {
			$parts['host'] = $matches[1];
			$parts['port'] = $matches[2];
			return $parts;
		}

		$parts['host'] = $host;
		return $parts;
	}

	private function create_mysql_defaults_file() {
		$dir  = $this->work_dir( 'mysql-auth' );
		$file = trailingslashit( $dir ) . 'client.cnf';

		wp_mkdir_p( $dir );

		$contents = "[client]\nuser=" . DB_USER . "\npassword=\"" . addcslashes( DB_PASSWORD, "\\\"\n\r" ) . "\"\n";
		file_put_contents( $file, $contents );
		@chmod( $file, 0600 );

		return $file;
	}

	private function can_use_mysqldump() {
		return $this->can_run_shell_commands() && $this->shell_binary_exists( 'mysqldump' );
	}

	private function can_use_native_mysql_import() {
		return $this->can_run_shell_commands() && '' !== $this->database_client_binary() && $this->shell_binary_exists( 'wp' );
	}

	private function can_run_shell_commands() {
		if ( ! function_exists( 'proc_open' ) ) {
			return false;
		}

		$disabled = array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) );
		return ! in_array( 'proc_open', $disabled, true );
	}

	private function shell_binary_exists( $binary ) {
		if ( ! $this->can_run_shell_commands() ) {
			return false;
		}

		try {
			$this->run_shell_command(
				array(
					'sh',
					'-lc',
					'command -v ' . escapeshellarg( $binary ),
				)
			);
			return true;
		} catch ( Exception $e ) {
			return false;
		}
	}

	private function database_client_binary() {
		if ( $this->shell_binary_exists( 'mariadb' ) ) {
			return 'mariadb';
		}

		if ( $this->shell_binary_exists( 'mysql' ) ) {
			return 'mysql';
		}

		return '';
	}

	private function run_database_client_sql( $sql, $job_id = '' ) {
		$path = $this->work_dir( 'mysql-auth' ) . '/db-client-command.sql';
		wp_mkdir_p( dirname( $path ) );
		file_put_contents( $path, (string) $sql );
		$this->import_sql_file_with_mysql_client( $path, $job_id );
	}

	private function run_detached_shell_command( array $parts, $cwd = null ) {
		$command = implode( ' ', array_map( 'escapeshellarg', $parts ) );
		$cwd     = $cwd ?: ABSPATH;
		$pid     = $this->run_shell_command(
			array(
				'sh',
				'-lc',
				'cd ' . escapeshellarg( $cwd ) . ' && nohup ' . $command . ' >/dev/null 2>&1 & echo $!',
			),
			$cwd
		);

		return trim( (string) $pid );
	}

	private function run_shell_command( array $parts, $cwd = null, $job_id = '' ) {
		$escaped = array_map( 'escapeshellarg', $parts );
		$command = implode( ' ', $escaped );

		$descriptors = array(
			0 => array( 'pipe', 'r' ),
			1 => array( 'pipe', 'w' ),
			2 => array( 'pipe', 'w' ),
		);

		$process = proc_open( $command, $descriptors, $pipes, $cwd ?: ABSPATH );
		if ( ! is_resource( $process ) ) {
			throw new Exception( 'Unable to start shell command.' );
		}

		fclose( $pipes[0] );
		stream_set_blocking( $pipes[1], false );
		stream_set_blocking( $pipes[2], false );

		$stdout                = '';
		$stderr                = '';
		$cancelled_message     = '';
		$termination_attempted = false;

		do {
			$stdout .= stream_get_contents( $pipes[1] );
			$stderr .= stream_get_contents( $pipes[2] );

			if ( '' !== $job_id && '' === $cancelled_message ) {
				try {
					$this->assert_job_not_cancelled( $job_id );
				} catch ( CMSVC_Cancelled_Exception $e ) {
					$cancelled_message = $e->getMessage();
				}
			}

			$status = proc_get_status( $process );
			if ( '' !== $cancelled_message && ! $termination_attempted && ! empty( $status['running'] ) ) {
				$termination_attempted = true;
				@proc_terminate( $process );
			}

			if ( empty( $status['running'] ) ) {
				break;
			}

			usleep( 250000 );
		} while ( true );

		$stdout .= stream_get_contents( $pipes[1] );
		$stderr .= stream_get_contents( $pipes[2] );
		fclose( $pipes[1] );
		fclose( $pipes[2] );

		$code = proc_close( $process );
		if ( '' !== $cancelled_message ) {
			if ( '' !== $job_id ) {
				$this->debug_job_event_by_id(
					$job_id,
					'Shell command cancelled after a job cancellation request.',
					array(
						'command' => implode( ' ', $parts ),
					)
				);
			}
			throw new CMSVC_Cancelled_Exception( $cancelled_message );
		}

		if ( 0 !== $code ) {
			if ( '' !== $job_id ) {
				$this->debug_job_event_by_id(
					$job_id,
					'Shell command failed.',
					array(
						'command' => implode( ' ', $parts ),
						'code'    => $code,
						'stdout'  => trim( $stdout ),
						'stderr'  => trim( $stderr ),
					)
				);
			}
			throw new Exception( trim( $stderr ?: $stdout ?: 'Shell command failed.' ) );
		}

		return trim( $stdout );
	}
}

add_filter(
	'cron_schedules',
	function ( $schedules ) {
		if ( ! isset( $schedules['minute'] ) ) {
			$schedules['minute'] = array(
				'interval' => 60,
				'display'  => 'Every Minute',
			);
		}
		return $schedules;
	}
);

register_activation_hook( __FILE__, array( 'CMSVC_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'CMSVC_Plugin', 'deactivate' ) );
CMSVC_Plugin::instance();

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	class CMSVC_CLI_Command {
		/**
		 * Imports a Cloud Migration Service archive from local disk.
		 *
		 * ## OPTIONS
		 *
		 * <archive>
		 * : Absolute path to the archive ZIP on this server.
		 *
		 * --source-url=<url>
		 * : Source site URL to replace during import.
		 *
		 * [--source-site-url=<url>]
		 * : Source site_url override.
		 *
		 * [--source-home-url=<url>]
		 * : Source home_url override.
		 *
		 * [--source-abspath=<path>]
		 * : Source ABSPATH override.
		 *
		 * [--source-content-dir=<path>]
		 * : Source WP_CONTENT_DIR override.
		 *
		 * [--source-uploads-dir=<path>]
		 * : Source uploads directory override.
		 *
		 * [--source-uploads-url=<url>]
		 * : Source uploads URL override.
		 *
		 * [--source-table-prefix=<prefix>]
		 * : Source database table prefix override.
		 *
		 * [--skip-email-domains=<1|0>]
		 * : Keep standalone email domains unchanged. Default: 1.
		 */
		public function import( $args, $assoc_args ) {
			$archive_path = isset( $args[0] ) ? (string) $args[0] : '';
			if ( '' === $archive_path || ! file_exists( $archive_path ) ) {
				WP_CLI::error( 'Archive file not found.' );
			}

			$source_context = $this->source_context_from_assoc_args( $assoc_args );
			if ( empty( $source_context['source_url'] ) ) {
				WP_CLI::error( 'Missing --source-url.' );
			}

			$skip_emails = ! isset( $assoc_args['skip-email-domains'] ) || '0' !== (string) $assoc_args['skip-email-domains'];

			try {
				CMSVC_Plugin::instance()->import_archive_from_cli( $archive_path, $source_context, $skip_emails );
				WP_CLI::success( 'Cloud Migration Service archive imported.' );
			} catch ( Exception $e ) {
				WP_CLI::error( $e->getMessage() );
			}
		}

		/**
		 * Prints the destination site's agent info for the SSH worker.
		 */
		public function agent_info() {
			WP_CLI::line(
				wp_json_encode(
					array(
						'home_url' => home_url(),
						'site_url' => site_url(),
						'site_key' => CMSVC_Plugin::instance()->site_worker_key(),
						'version'  => CMSVC_VERSION,
					)
				)
			);
		}

		/**
		 * Prints a public migration job payload for the SSH worker.
		 *
		 * ## OPTIONS
		 *
		 * <job-id>
		 * : The Cloud Migration Service job ID.
		 */
		public function agent_job( $args ) {
			$job_id = isset( $args[0] ) ? (string) $args[0] : '';
			if ( '' === $job_id ) {
				WP_CLI::error( 'Missing job ID.' );
			}

			try {
				WP_CLI::line( wp_json_encode( CMSVC_Plugin::instance()->cli_agent_job( $job_id ) ) );
			} catch ( Exception $e ) {
				WP_CLI::error( $e->getMessage() );
			}
		}

		/**
		 * Runs the detached destination database import for a queued job.
		 *
		 * ## OPTIONS
		 *
		 * <job-id>
		 * : The Cloud Migration Service job ID.
		 */
		public function run_async_db_import( $args ) {
			$job_id = isset( $args[0] ) ? (string) $args[0] : '';
			if ( '' === $job_id ) {
				WP_CLI::error( 'Missing job ID.' );
			}

			try {
				CMSVC_Plugin::instance()->run_async_database_import_job( $job_id );
				WP_CLI::success( 'Detached database import completed.' );
			} catch ( Exception $e ) {
				WP_CLI::error( $e->getMessage() );
			}
		}

		private function source_context_from_assoc_args( array $assoc_args ) {
			$source_url = isset( $assoc_args['source-url'] ) ? (string) $assoc_args['source-url'] : '';

			return array(
				'source_url'         => $source_url,
				'source_site_url'    => isset( $assoc_args['source-site-url'] ) ? (string) $assoc_args['source-site-url'] : $source_url,
				'source_home_url'    => isset( $assoc_args['source-home-url'] ) ? (string) $assoc_args['source-home-url'] : $source_url,
				'source_abspath'     => isset( $assoc_args['source-abspath'] ) ? (string) $assoc_args['source-abspath'] : '',
				'source_content_dir' => isset( $assoc_args['source-content-dir'] ) ? (string) $assoc_args['source-content-dir'] : '',
				'source_uploads_dir' => isset( $assoc_args['source-uploads-dir'] ) ? (string) $assoc_args['source-uploads-dir'] : '',
				'source_uploads_url' => isset( $assoc_args['source-uploads-url'] ) ? (string) $assoc_args['source-uploads-url'] : '',
				'source_table_prefix' => isset( $assoc_args['source-table-prefix'] ) ? (string) $assoc_args['source-table-prefix'] : '',
			);
		}
	}

	WP_CLI::add_command( 'cmsvc', 'CMSVC_CLI_Command' );
}
