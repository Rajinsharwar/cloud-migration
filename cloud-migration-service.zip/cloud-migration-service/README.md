# Cloud Migration Service

SSH-first WordPress migration helper for the Node worker in this repository.

## Install

Upload the `cloud-migration-service` folder to `wp-content/plugins/` on both the source and destination WordPress sites, then activate **Cloud Migration Service**.

## What The Plugin Does Now

- Exposes a source export API for the Node worker.
- Creates a site archive and uploads it directly to Cloudflare R2.
- Provides WP-CLI commands for fast destination imports.
- Keeps a small admin page for the worker key, exclusions, and job visibility.

This plugin no longer handles destination migration over WordPress REST or plugin-to-plugin transfer.

## Worker Setup

1. Install and activate the plugin on both sites.
2. Copy each site's worker key from **Tools > Cloud Migration**.
3. Start the Node worker from `migration-worker`.
4. Point the worker at the source site and the destination server over SSH.

## WP-CLI Commands

Import from an archive already on disk:

```bash
wp cmsvc import /path/to/archive.wpress --source-url=https://source.example.com
```

Import directly from Cloudflare R2:

```bash
wp cmsvc import_r2 cmsvc-worker/job.wpress \
  --source-url=https://source.example.com \
  --r2-account-id=... \
  --r2-access-key=... \
  --r2-secret-key=... \
  --r2-bucket=...
```

## Performance Notes

- Source exports prefer `mysqldump` when available.
- Destination imports prefer the native `mysql` client plus `wp search-replace`.
- Exclusion rules help avoid wasting time on caches, backups, and temporary files.
- The Node worker no longer acts as the archive relay.
