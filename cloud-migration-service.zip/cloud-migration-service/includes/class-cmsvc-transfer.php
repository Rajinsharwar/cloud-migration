<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class CMSVC_Archiver {
	const HEADER_SIZE = 4377;
	const READ_CHUNK_SIZE = 512000;

	protected $file_name;
	protected $file_handle;
	protected $block_format = array(
		'a255',
		'a14',
		'a12',
		'a4088',
		'a8',
	);

	public function __construct( $file_name, $write = false ) {
		$this->file_name = $file_name;
		$mode            = $write ? 'cb' : 'rb';
		$handle          = @fopen( $file_name, $mode );
		if ( false === $handle ) {
			throw new Exception( sprintf( 'Unable to open archive file: %s', $file_name ) );
		}

		$this->file_handle = $handle;
		if ( $write && -1 === @fseek( $this->file_handle, 0, SEEK_END ) ) {
			throw new Exception( sprintf( 'Unable to seek archive file: %s', $file_name ) );
		}
	}

	public function close( $complete = false ) {
		if ( $complete ) {
			$this->append_eof();
		}

		if ( false === @fclose( $this->file_handle ) ) {
			throw new Exception( sprintf( 'Unable to close archive file: %s', $this->file_name ) );
		}
	}

	public function set_file_pointer( $offset ) {
		if ( -1 === @fseek( $this->file_handle, $offset, SEEK_SET ) ) {
			throw new Exception( sprintf( 'Unable to seek archive offset %d in %s', $offset, $this->file_name ) );
		}
	}

	public function get_file_pointer() {
		$offset = @ftell( $this->file_handle );
		if ( false === $offset ) {
			throw new Exception( sprintf( 'Unable to read archive offset for %s', $this->file_name ) );
		}

		return $offset;
	}

	public function is_valid() {
		$offset = @ftell( $this->file_handle );
		if ( false === $offset ) {
			return false;
		}

		if ( -1 === @fseek( $this->file_handle, -static::HEADER_SIZE, SEEK_END ) ) {
			return false;
		}

		$block = @fread( $this->file_handle, static::HEADER_SIZE );
		@fseek( $this->file_handle, $offset, SEEK_SET );

		return false !== $block && $this->is_eof_block( $block );
	}

	protected function append_eof() {
		if ( -1 === @fseek( $this->file_handle, 0, SEEK_END ) ) {
			throw new Exception( sprintf( 'Unable to seek end of archive: %s', $this->file_name ) );
		}

		$block = pack( 'a255a14a4100a8', '', '', '', '' );
		$bytes = @fwrite( $this->file_handle, $block );
		if ( false === $bytes || strlen( $block ) !== $bytes ) {
			throw new Exception( sprintf( 'Unable to write end of archive: %s', $this->file_name ) );
		}
	}

	protected function is_eof_block( $block ) {
		return pack( 'a255a14a4100a8', '', '', '', '' ) === $block;
	}
}

final class CMSVC_Compressor extends CMSVC_Archiver {
	public function __construct( $file_name ) {
		parent::__construct( $file_name, true );
	}

	public function add_file( $file_name, $archive_name ) {
		$result = $this->add_file_chunk( $file_name, $archive_name, 0, PHP_INT_MAX );
		return false === $result ? false : null;
	}

	public function add_file_chunk( $file_name, $archive_name, $source_offset = 0, $max_bytes = null ) {
		$file_name    = wp_normalize_path( $file_name );
		$archive_name = ltrim( wp_normalize_path( $archive_name ), '/' );
		$source_offset = max( 0, (int) $source_offset );
		$max_bytes     = null === $max_bytes ? PHP_INT_MAX : max( 1, (int) $max_bytes );

		$handle = @fopen( $file_name, 'rb' );
		if ( false === $handle ) {
			return false;
		}

		$stat = @fstat( $handle );
		if ( false === $stat ) {
			@fclose( $handle );
			return false;
		}

		if ( 0 === $source_offset ) {
			$directory = trim( str_replace( '\\', '/', dirname( $archive_name ) ), '/' );
			if ( '' === $directory ) {
				$directory = '.';
			}

			$block = pack(
				implode( '', $this->block_format ),
				basename( $archive_name ),
				(string) $stat['size'],
				(string) $stat['mtime'],
				$directory,
				''
			);

			$bytes = @fwrite( $this->file_handle, $block );
			if ( false === $bytes || strlen( $block ) !== $bytes ) {
				@fclose( $handle );
				throw new Exception( sprintf( 'Unable to write archive header for %s', $archive_name ) );
			}
		} elseif ( -1 === @fseek( $handle, $source_offset, SEEK_SET ) ) {
			@fclose( $handle );
			throw new Exception( sprintf( 'Unable to seek source file %s', $file_name ) );
		}

		$written_from_source = $source_offset;
		$written_this_call   = 0;

		while ( ! feof( $handle ) && $written_this_call < $max_bytes ) {
			$remaining_limit = $max_bytes - $written_this_call;
			$chunk_size      = min( static::READ_CHUNK_SIZE, $remaining_limit );
			$chunk           = @fread( $handle, $chunk_size );
			if ( false === $chunk ) {
				@fclose( $handle );
				throw new Exception( sprintf( 'Unable to stream file into archive: %s', $file_name ) );
			}

			if ( '' === $chunk ) {
				break;
			}

			$written = @fwrite( $this->file_handle, $chunk );
			if ( false === $written || strlen( $chunk ) !== $written ) {
				@fclose( $handle );
				throw new Exception( sprintf( 'Unable to write file contents into archive: %s', $archive_name ) );
			}

			$chunk_length          = strlen( $chunk );
			$written_from_source += $chunk_length;
			$written_this_call   += $chunk_length;
		}

		@fclose( $handle );

		return array(
			'complete'       => $written_from_source >= (int) $stat['size'],
			'source_offset'  => $written_from_source,
			'archive_offset' => $this->get_file_pointer(),
			'size'           => (int) $stat['size'],
		);
	}
}

final class CMSVC_Extractor extends CMSVC_Archiver {
	public function __construct( $file_name ) {
		parent::__construct( $file_name, false );
	}

	public function entry_at_offset( $offset ) {
		$offset = max( 0, (int) $offset );
		$this->set_file_pointer( $offset );

		$block = @fread( $this->file_handle, static::HEADER_SIZE );
		if ( false === $block || '' === $block ) {
			return null;
		}

		if ( $this->is_eof_block( $block ) ) {
			return null;
		}

		$entry = $this->parse_block( $block );
		if ( empty( $entry ) ) {
			throw new Exception( 'Archive entry header could not be parsed.' );
		}

		$entry['header_offset'] = $offset;
		$entry['data_offset']   = $offset + static::HEADER_SIZE;
		$entry['next_offset']   = $entry['data_offset'] + $entry['size'];

		return $entry;
	}

	public function extract_with_callback( callable $mapper ) {
		$this->set_file_pointer( 0 );

		while ( ( $block = @fread( $this->file_handle, static::HEADER_SIZE ) ) ) {
			if ( $this->is_eof_block( $block ) ) {
				break;
			}

			$entry = $this->parse_block( $block );
			if ( empty( $entry ) ) {
				throw new Exception( 'Archive entry header could not be parsed.' );
			}

			$target = $mapper( $entry );
			if ( false === $target ) {
				if ( -1 === @fseek( $this->file_handle, $entry['size'], SEEK_CUR ) ) {
					throw new Exception( sprintf( 'Unable to skip archive entry %s', $entry['filename'] ) );
				}
				continue;
			}

			$this->extract_entry_to( $entry, $target );
		}
	}

	public function extract_entry_chunk( array $entry, $target, $source_offset = 0, $max_bytes = null ) {
		$source_offset = max( 0, (int) $source_offset );
		$max_bytes     = null === $max_bytes ? PHP_INT_MAX : max( 1, (int) $max_bytes );
		$entry_size    = max( 0, (int) ( $entry['size'] ?? 0 ) );
		$data_offset   = max( 0, (int) ( $entry['data_offset'] ?? 0 ) );

		if ( $source_offset >= $entry_size ) {
			return array(
				'complete'      => true,
				'source_offset' => $entry_size,
				'written'       => 0,
				'next_offset'   => max( $data_offset + $entry_size, (int) ( $entry['next_offset'] ?? 0 ) ),
			);
		}

		$directory = dirname( $target );
		if ( ! is_dir( $directory ) ) {
			wp_mkdir_p( $directory );
		}

		$handle = @fopen( $target, $source_offset > 0 ? 'c+b' : 'wb' );
		if ( false === $handle ) {
			throw new Exception( sprintf( 'Unable to write extracted file: %s', $target ) );
		}

		if ( $source_offset > 0 ) {
			if ( -1 === @fseek( $handle, $source_offset, SEEK_SET ) ) {
				@fclose( $handle );
				throw new Exception( sprintf( 'Unable to resume extracted file: %s', $target ) );
			}
		}

		$this->set_file_pointer( $data_offset + $source_offset );

		$remaining      = $entry_size - $source_offset;
		$written_total  = 0;
		$remaining_quota = $max_bytes;

		while ( $remaining > 0 && $remaining_quota > 0 ) {
			$chunk_size = min( $remaining, static::READ_CHUNK_SIZE, $remaining_quota );
			$chunk      = @fread( $this->file_handle, $chunk_size );
			if ( false === $chunk ) {
				@fclose( $handle );
				throw new Exception( sprintf( 'Unable to read archive entry: %s', $entry['filename'] ) );
			}

			if ( '' === $chunk ) {
				break;
			}

			$written = @fwrite( $handle, $chunk );
			if ( false === $written || strlen( $chunk ) !== $written ) {
				@fclose( $handle );
				throw new Exception( sprintf( 'Unable to write extracted contents: %s', $target ) );
			}

			$chunk_length    = strlen( $chunk );
			$remaining      -= $chunk_length;
			$written_total  += $chunk_length;
			$remaining_quota -= $chunk_length;
		}

		@fclose( $handle );

		$new_offset = $source_offset + $written_total;
		$complete   = $new_offset >= $entry_size;
		if ( $complete ) {
			@touch( $target, (int) ( $entry['mtime'] ?? time() ) );
			@chmod( $target, defined( 'FS_CHMOD_FILE' ) ? FS_CHMOD_FILE : 0644 );
		}

		return array(
			'complete'      => $complete,
			'source_offset' => $new_offset,
			'written'       => $written_total,
			'next_offset'   => max( $data_offset + $entry_size, (int) ( $entry['next_offset'] ?? 0 ) ),
		);
	}

	private function parse_block( $block ) {
		$data = unpack(
			$this->block_format[0] . 'filename/' .
			$this->block_format[1] . 'size/' .
			$this->block_format[2] . 'mtime/' .
			$this->block_format[3] . 'path/' .
			$this->block_format[4] . 'crc32',
			$block
		);

		if ( ! is_array( $data ) ) {
			return array();
		}

		$filename = trim( $data['filename'] );
		$path     = trim( $data['path'] );
		$path     = '.' === $path ? '' : str_replace( '/', DIRECTORY_SEPARATOR, $path );

		return array(
			'filename' => '' === $path ? $filename : $path . DIRECTORY_SEPARATOR . $filename,
			'size'     => (int) trim( $data['size'] ),
			'mtime'    => (int) trim( $data['mtime'] ),
		);
	}

	private function extract_entry_to( array $entry, $target ) {
		$directory = dirname( $target );
		if ( ! is_dir( $directory ) ) {
			wp_mkdir_p( $directory );
		}

		$handle = @fopen( $target, 'wb' );
		if ( false === $handle ) {
			throw new Exception( sprintf( 'Unable to write extracted file: %s', $target ) );
		}

		$remaining = $entry['size'];
		while ( $remaining > 0 ) {
			$chunk_size = min( $remaining, static::READ_CHUNK_SIZE );
			$chunk      = @fread( $this->file_handle, $chunk_size );
			if ( false === $chunk ) {
				@fclose( $handle );
				throw new Exception( sprintf( 'Unable to read archive entry: %s', $entry['filename'] ) );
			}

			$written = @fwrite( $handle, $chunk );
			if ( false === $written || strlen( $chunk ) !== $written ) {
				@fclose( $handle );
				throw new Exception( sprintf( 'Unable to write extracted contents: %s', $target ) );
			}

			$remaining -= strlen( $chunk );
		}

		@fclose( $handle );
		@touch( $target, $entry['mtime'] );
		@chmod( $target, defined( 'FS_CHMOD_FILE' ) ? FS_CHMOD_FILE : 0644 );
	}
}

final class CMSVC_SQL_Rewriter {
	public static function build( array $manifest, $target_site_url, $target_home_url, $skip_email_domains, array $target_context = array() ) {
		$old_values     = array();
		$new_values     = array();
		$old_raw_values = array();
		$new_raw_values = array();
		$target_abspath = $target_context['abspath'] ?? ABSPATH;
		$target_content = $target_context['content_dir'] ?? WP_CONTENT_DIR;
		$target_uploads = $target_context['uploads'] ?? wp_get_upload_dir();

		self::add_url_replacements( $old_values, $new_values, $old_raw_values, $new_raw_values, $manifest['source_site_url'] ?? '', $target_site_url, $skip_email_domains );
		self::add_url_replacements( $old_values, $new_values, $old_raw_values, $new_raw_values, $manifest['source_home_url'] ?? '', $target_home_url, $skip_email_domains );

		if ( empty( $manifest['source_site_url'] ) && ! empty( $manifest['source_url'] ) ) {
			self::add_url_replacements( $old_values, $new_values, $old_raw_values, $new_raw_values, $manifest['source_url'], $target_site_url, $skip_email_domains );
		}

		if ( empty( $manifest['source_home_url'] ) && ! empty( $manifest['source_url'] ) ) {
			self::add_url_replacements( $old_values, $new_values, $old_raw_values, $new_raw_values, $manifest['source_url'], $target_home_url, $skip_email_domains );
		}

		self::add_path_replacements( $old_values, $new_values, $manifest['source_abspath'] ?? '', $target_abspath );
		self::add_path_replacements( $old_values, $new_values, $manifest['source_content_dir'] ?? '', $target_content );
		self::add_path_replacements( $old_values, $new_values, $manifest['source_uploads_dir'] ?? '', $target_uploads['basedir'] ?? '' );
		self::add_url_variants( $old_values, $new_values, $manifest['source_uploads_url'] ?? '', $target_uploads['baseurl'] ?? '' );

		return new self( $old_values, $new_values, $old_raw_values, $new_raw_values );
	}

	private $old_values;
	private $new_values;
	private $old_raw_values;
	private $new_raw_values;
	private $minimum_length;

	private function __construct( array $old_values, array $new_values, array $old_raw_values, array $new_raw_values ) {
		$pairs = array();
		for ( $i = 0; $i < count( $old_values ); $i++ ) {
			if ( '' === (string) $old_values[ $i ] ) {
				continue;
			}
			$pairs[ $old_values[ $i ] ] = $new_values[ $i ];
		}

		$raw_pairs = array();
		for ( $i = 0; $i < count( $old_raw_values ); $i++ ) {
			if ( '' === (string) $old_raw_values[ $i ] ) {
				continue;
			}
			$raw_pairs[ $old_raw_values[ $i ] ] = $new_raw_values[ $i ];
		}

		$this->old_values     = array_keys( $pairs );
		$this->new_values     = array_values( $pairs );
		$this->old_raw_values = array_keys( $raw_pairs );
		$this->new_raw_values = array_values( $raw_pairs );
		$this->minimum_length = empty( $this->old_values ) ? 1 : min( array_map( 'strlen', $this->old_values ) );
	}

	public function rewrite_query( $query ) {
		if ( '' === trim( $query ) ) {
			return $query;
		}

		if ( ! empty( $this->old_raw_values ) ) {
			$query = strtr( $query, array_combine( $this->old_raw_values, $this->new_raw_values ) );
		}

		foreach ( $this->old_values as $old_value ) {
			if ( false !== strpos( $query, self::escape_mysql( $old_value ) ) ) {
				return preg_replace_callback( "/'(.*?)(?<!\\\\)'/S", array( $this, 'rewrite_mysql_string' ), $query );
			}
		}

		return $query;
	}

	private function rewrite_mysql_string( $matches ) {
		$value = self::unescape_mysql( $matches[1] );
		if ( strlen( $value ) >= $this->minimum_length ) {
			$value = self::replace_serialized_values( $value, $this->old_values, $this->new_values );
		}

		return "'" . self::escape_mysql( $value ) . "'";
	}

	private static function add_path_replacements( array &$old_values, array &$new_values, $old_path, $new_path ) {
		if ( empty( $old_path ) || empty( $new_path ) ) {
			return;
		}

		self::add_unique_pair( $old_values, $new_values, $old_path, $new_path );
		self::add_unique_pair( $old_values, $new_values, urlencode( $old_path ), urlencode( $new_path ) );
		self::add_unique_pair( $old_values, $new_values, rawurlencode( $old_path ), rawurlencode( $new_path ) );
		self::add_unique_pair( $old_values, $new_values, addcslashes( $old_path, '/' ), addcslashes( $new_path, '/' ) );
	}

	private static function add_url_variants( array &$old_values, array &$new_values, $old_url, $new_url ) {
		if ( empty( $old_url ) || empty( $new_url ) ) {
			return;
		}

		$old_url = untrailingslashit( $old_url );
		$new_url = untrailingslashit( $new_url );

		self::add_unique_pair( $old_values, $new_values, $old_url, $new_url );
		self::add_unique_pair( $old_values, $new_values, urlencode( $old_url ), urlencode( $new_url ) );
		self::add_unique_pair( $old_values, $new_values, rawurlencode( $old_url ), rawurlencode( $new_url ) );
		self::add_unique_pair( $old_values, $new_values, addcslashes( $old_url, '/' ), addcslashes( $new_url, '/' ) );
	}

	private static function add_url_replacements( array &$old_values, array &$new_values, array &$old_raw_values, array &$new_raw_values, $old_url, $new_url, $skip_email_domains ) {
		if ( empty( $old_url ) || empty( $new_url ) ) {
			return;
		}

		self::add_url_variants( $old_values, $new_values, $old_url, $new_url );

		$old_domain = parse_url( $old_url, PHP_URL_HOST );
		$new_domain = parse_url( $new_url, PHP_URL_HOST );
		$old_path   = (string) parse_url( $old_url, PHP_URL_PATH );
		$new_path   = (string) parse_url( $new_url, PHP_URL_PATH );

		if ( $old_domain && $new_domain ) {
			self::add_unique_pair( $old_values, $new_values, "='{$old_domain}" . untrailingslashit( $old_path ), "='{$new_domain}" . untrailingslashit( $new_path ) );
			self::add_unique_pair( $old_values, $new_values, '="' . $old_domain . untrailingslashit( $old_path ), '="' . $new_domain . untrailingslashit( $new_path ) );
			self::add_unique_pair(
				$old_raw_values,
				$new_raw_values,
				sprintf( "'%s','%s'", $old_domain, trailingslashit( $old_path ) ),
				sprintf( "'%s','%s'", $new_domain, trailingslashit( $new_path ) )
			);

			if ( ! $skip_email_domains ) {
				self::add_unique_pair( $old_values, $new_values, '@' . $old_domain, '@' . str_ireplace( 'www.', '', $new_domain ) );
			}
		}
	}

	private static function add_unique_pair( array &$old_values, array &$new_values, $old_value, $new_value ) {
		if ( '' === (string) $old_value || in_array( $old_value, $old_values, true ) ) {
			return;
		}

		$old_values[] = $old_value;
		$new_values[] = $new_value;
	}

	private static function replace_serialized_values( $data, array $search, array $replace ) {
		if ( empty( $search ) ) {
			return $data;
		}

		$position = 0;
		$result   = self::parse_serialized_values( $data, $position, $search, $replace );
		if ( $position !== strlen( $data ) ) {
			return strtr( $data, array_combine( $search, $replace ) );
		}

		return $result;
	}

	private static function parse_serialized_values( $data, &$position, array $search, array $replace ) {
		$length = strlen( $data );
		if ( $position >= $length ) {
			return '';
		}

		$type = $data[ $position ];
		$position++;

		switch ( $type ) {
			case 's':
				return self::parse_serialized_string( $data, $position, $search, $replace );
			case 'i':
			case 'd':
			case 'b':
				return self::parse_until_semicolon( $type, $data, $position );
			case 'N':
				if ( ! isset( $data[ $position ] ) || ';' !== $data[ $position ] ) {
					$position--;
					return '';
				}
				$position++;
				return 'N;';
			case 'a':
				return self::parse_serialized_collection( 'a', $data, $position, $search, $replace );
			case 'O':
				return self::parse_serialized_object( $data, $position, $search, $replace );
			case 'R':
			case 'r':
				return self::parse_until_semicolon( $type, $data, $position );
			default:
				$position--;
				return '';
		}
	}

	private static function parse_serialized_string( $data, &$position, array $search, array $replace ) {
		if ( ! isset( $data[ $position ] ) || ':' !== $data[ $position ] ) {
			$position--;
			return '';
		}

		$position++;
		$length_end = strpos( $data, ':', $position );
		if ( false === $length_end ) {
			$position--;
			return '';
		}

		$string_length = (int) substr( $data, $position, $length_end - $position );
		$position      = $length_end + 1;
		if ( ! isset( $data[ $position ] ) || '"' !== $data[ $position ] ) {
			$position--;
			return '';
		}

		$position++;
		$string   = substr( $data, $position, $string_length );
		$position += $string_length;

		if ( ! isset( $data[ $position ], $data[ $position + 1 ] ) || '"' !== $data[ $position ] || ';' !== $data[ $position + 1 ] ) {
			$position--;
			return '';
		}

		$position += 2;
		if ( 1 === $string_length ) {
			return 's:' . $string_length . ':"' . $string . '";';
		}

		$inner_position = 0;
		$parsed         = self::parse_serialized_values( $string, $inner_position, $search, $replace );
		if ( $inner_position === strlen( $string ) ) {
			$new_string = $parsed;
		} else {
			$new_string = strtr( $string, array_combine( $search, $replace ) );
		}

		return 's:' . strlen( $new_string ) . ':"' . $new_string . '";';
	}

	private static function parse_serialized_collection( $type, $data, &$position, array $search, array $replace ) {
		if ( ! isset( $data[ $position ] ) || ':' !== $data[ $position ] ) {
			$position--;
			return '';
		}

		$position++;
		$length_end = strpos( $data, ':', $position );
		if ( false === $length_end ) {
			$position--;
			return '';
		}

		$count    = (int) substr( $data, $position, $length_end - $position );
		$position = $length_end + 1;
		if ( ! isset( $data[ $position ] ) || '{' !== $data[ $position ] ) {
			$position--;
			return '';
		}

		$position++;
		$result = $type . ':' . $count . ':{';
		for ( $i = 0; $i < $count * 2; $i++ ) {
			$element = self::parse_serialized_values( $data, $position, $search, $replace );
			if ( '' === $element ) {
				$position--;
				return '';
			}
			$result .= $element;
		}

		if ( ! isset( $data[ $position ] ) || '}' !== $data[ $position ] ) {
			$position--;
			return '';
		}

		$position++;
		return $result . '}';
	}

	private static function parse_serialized_object( $data, &$position, array $search, array $replace ) {
		if ( ! isset( $data[ $position ] ) || ':' !== $data[ $position ] ) {
			$position--;
			return '';
		}

		$position++;
		$class_length_end = strpos( $data, ':', $position );
		if ( false === $class_length_end ) {
			$position--;
			return '';
		}

		$class_length = (int) substr( $data, $position, $class_length_end - $position );
		$position     = $class_length_end + 1;
		if ( ! isset( $data[ $position ] ) || '"' !== $data[ $position ] ) {
			$position--;
			return '';
		}

		$position++;
		$class_name = substr( $data, $position, $class_length );
		$position  += $class_length;

		if ( ! isset( $data[ $position ], $data[ $position + 1 ] ) || '"' !== $data[ $position ] || ':' !== $data[ $position + 1 ] ) {
			$position--;
			return '';
		}

		$position += 2;
		$property_length_end = strpos( $data, ':', $position );
		if ( false === $property_length_end ) {
			$position--;
			return '';
		}

		$property_count = (int) substr( $data, $position, $property_length_end - $position );
		$position       = $property_length_end + 1;
		if ( ! isset( $data[ $position ] ) || '{' !== $data[ $position ] ) {
			$position--;
			return '';
		}

		$position++;
		$result = 'O:' . strlen( $class_name ) . ':"' . $class_name . '":' . $property_count . ':{';
		for ( $i = 0; $i < $property_count * 2; $i++ ) {
			$element = self::parse_serialized_values( $data, $position, $search, $replace );
			if ( '' === $element ) {
				$position--;
				return '';
			}
			$result .= $element;
		}

		if ( ! isset( $data[ $position ] ) || '}' !== $data[ $position ] ) {
			$position--;
			return '';
		}

		$position++;
		return $result . '}';
	}

	private static function parse_until_semicolon( $type, $data, &$position ) {
		if ( ! isset( $data[ $position ] ) || ':' !== $data[ $position ] ) {
			$position--;
			return '';
		}

		$position++;
		$end = strpos( $data, ';', $position );
		if ( false === $end ) {
			$position--;
			return '';
		}

		$value    = substr( $data, $position, $end - $position );
		$position = $end + 1;

		return $type . ':' . $value . ';';
	}

	private static function escape_mysql( $data ) {
		return strtr(
			$data,
			array_combine(
				array( "\x00", "\n", "\r", '\\', "'", '"', "\x1a" ),
				array( '\\0', '\\n', '\\r', '\\\\', "\\'", '\\"', '\\Z' )
			)
		);
	}

	private static function unescape_mysql( $data ) {
		return strtr(
			$data,
			array_combine(
				array( '\\0', '\\n', '\\r', '\\\\', "\\'", '\\"', '\\Z' ),
				array( "\x00", "\n", "\r", '\\', "'", '"', "\x1a" )
			)
		);
	}
}
